"""shared.py — общее состояние бота, доступное из API и из бота."""
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

# Event для lifecycle бота: Stop=clear, Start=set
_bot_lifecycle = threading.Event()
_operation_lock = threading.Lock()
state_lock = threading.Lock()

def get_lifecycle_event():
    return _bot_lifecycle


def qfloat(v) -> float:
    """Конвертирует цену: None/0, int/float, dataclass {units,nano}, dict {units,nano} → float."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    if hasattr(v, 'units') and hasattr(v, 'nano'):
        return int(v.units or 0) + int(v.nano or 0) / 1_000_000_000
    if isinstance(v, dict):
        return int(v.get("units", 0) or 0) + int(v.get("nano", 0) or 0) / 1_000_000_000
    return 0.0


def log_trade(action, figi, ticker, quantity, price, pnl=None):
    """Логирование сделки в файл."""
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / f"trades_{datetime.now().strftime('%d%m%Y')}.log"
    date_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    pnl_str = f" | P/L: {pnl:.2f} RUB" if pnl is not None else ""
    line = f"{date_str} | {action} | {ticker} | {quantity} контрактов @ {price:.4f}{pnl_str}\n"
    try:
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass


@dataclass
class Position:
    """Текущая торговая позиция."""
    side: str = 'NONE'              # NONE / LONG / SHORT
    entry_price: float = 0.0
    lot: int = 0
    entry_bar: int = 0
    entry_time: Optional[datetime] = None
    peak_price: float = 0.0
    trailing_active: bool = False

    def is_open(self) -> bool:
        return self.side != 'NONE'

    def reset(self):
        self.side = 'NONE'
        self.entry_price = 0.0
        self.lot = 0
        self.entry_bar = 0
        self.entry_time = None
        self.peak_price = 0.0
        self.trailing_active = False


@dataclass
class BotState:
    """Глобальное состояние, разделяемое между ботом и API."""
    running: bool = False           # бот работает
    position: Position = field(default_factory=Position)
    daily_pnl: float = 0.0         # P/L за сегодня, RUB
    last_trade_time: Optional[datetime] = None
    last_trade_pnl: Optional[float] = None
    last_error: Optional[str] = None
    raw_candles: list = field(default_factory=list)  # последние свечи
    start_time: Optional[datetime] = None
    server_start_time: Optional[datetime] = None     # время старта сервера
    trade_count: int = 0
    best_trade: float = 0.0
    win_count: int = 0
    loss_count: int = 0
    worst_trade: float = 0.0
    total_pnl: float = 0.0      # все сделки из логов
    current_figi: str = ""
    force_close: bool = False         # сигнал принудительного закрытия
    manual_entry_side: str = ""       # MANUAL_LONG / MANUAL_SHORT — принудительный вход
    portfolio_balance: float = 0.0    # баланс RUB
    portfolio_blocked: float = 0.0    # заблокировано под ГО
    stream_connected: bool = True     # статус MarketDataStream
    current_price: float = 0.0        # цена последней свечи
    tick_size: float = 1.0            # min_price_increment
    tick_value: float = 1.0           # min_price_increment_amount
    basic_asset_size: float = 0.0     # номинал контракта (CCM6=10, CRM6=1000)
    last_sl_time: Optional[datetime] = None
    last_exit_time: Optional[datetime] = None
    mode: str = "sandbox"           # "sandbox" | "real"
    total_cash: float = 0.0         # Реальный RUB на счете (total_amount_currencies)
    available_cash: float = 0.0     # RUB - ГО (liquid_portfolio)
    circuit_breaker: bool = False   # True = торговля остановлена риск-менеджером
    # Текущие индикаторы (обновляются каждую итерацию)
    ind_ema: float = 0.0
    ind_ema_slow: float = 0.0
    ind_rsi: float = 0.0
    ind_adx: float = 0.0
    ind_momentum: float = 0.0
    ind_volume_mult: float = 0.0  # объём / avg_volume
    ind_percentile_high: float = 0.0
    ind_percentile_low: float = 0.0

    def record_trade(self, pnl: float):
        """Записать закрытую сделку в статистику. Потокобезопасно."""
        with state_lock:
            self.last_trade_pnl = pnl
            self.last_trade_time = datetime.now()
            self.trade_count += 1
            if pnl > 0:
                self.win_count += 1
            else:
                self.loss_count += 1
            if self.trade_count == 1:
                self.best_trade = pnl
                self.worst_trade = pnl
            else:
                if pnl > self.best_trade:
                    self.best_trade = pnl
                if pnl < self.worst_trade:
                    self.worst_trade = pnl
            self.daily_pnl += pnl
            self.last_error = None

    def record_error(self, error: str):
        with state_lock:
            self.last_error = error

    def to_dict(self) -> dict:
        with state_lock:
            out = {
                "running": self.running,
                "position": {
                    "side": self.position.side,
                    "entry_price": self.position.entry_price,
                    "lot": self.position.lot,
                    "entry_bar": self.position.entry_bar,
                    "entry_time": (
                        self.position.entry_time.isoformat()
                        if self.position.entry_time else None
                    ),
                    "peak_price": self.position.peak_price,
                    "trailing": self.position.trailing_active,
                    "cur_price": self.current_price if self.current_price else self.position.peak_price,
                    "ema": self.ind_ema if self.ind_ema else None,
                    "ema_slow": self.ind_ema_slow if self.ind_ema_slow else None,
                    "rsi": self.ind_rsi if self.ind_rsi else None,
                    "adx": self.ind_adx if self.ind_adx else None,
                    "momentum": self.ind_momentum if self.ind_momentum else None,
                    "volume_mult": self.ind_volume_mult if self.ind_volume_mult else None,
                    "percentile_high": self.ind_percentile_high if self.ind_percentile_high else None,
                    "percentile_low": self.ind_percentile_low if self.ind_percentile_low else None,
                },
                "daily_pnl": self.daily_pnl,
                "last_trade_time": (
                    self.last_trade_time.isoformat()
                    if self.last_trade_time else None
                ),
                "last_trade_pnl": self.last_trade_pnl,
                "last_error": self.last_error,
                "trade_count": self.trade_count,
                "win_count": self.win_count,
                "loss_count": self.loss_count,
                "winrate": (
                    round(self.win_count / self.trade_count * 100, 1)
                    if self.trade_count > 0 else 0.0
                ),
                "total_pnl": self.total_pnl,
                "uptime_sec": (
                    round((datetime.now() - self.start_time).total_seconds())
                    if self.start_time else 0
                ),
                "server_uptime_sec": (
                    round((datetime.now() - self.server_start_time).total_seconds())
                    if self.server_start_time else 0
                ),
                "mode": self.mode,
                "total_cash": self.total_cash,
                "available_cash": self.available_cash,
                "circuit_breaker": self.circuit_breaker,
                "portfolio_balance": self.portfolio_balance,
                "portfolio_blocked": self.portfolio_blocked,
                "stream_connected": self.stream_connected,
                "tick_size": self.tick_size,
                "tick_value": self.tick_value,
                "basic_asset_size": self.basic_asset_size,
            }
        return out


MAX_RECONNECT_WINDOW = 21600  # 6 часов — таймаут для отказа от реконнекта


async def get_session_start(client, ticker: str, class_code: str = "SPBFUT") -> Optional[datetime]:
    """Вернуть UTC datetime начала текущей торговой сессии через API.
    Ищет сегодня, потом -1, -2... -7 дней.
    Возвращает None, если ничего не найдено."""
    try:
        instr = await client.instruments.future_by(id_type=2, class_code=class_code, id=ticker)
        exchange = instr.instrument.exchange
        now_utc = datetime.now(timezone.utc)
        for days_back in range(8):
            day = now_utc - timedelta(days=days_back)
            day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            try:
                sched = await client.instruments.trading_schedules(exchange=exchange, from_=day_start, to=day_end)
                for ts in sched.exchanges:
                    for d in ts.days:
                        if d.is_trading_day and d.start_time:
                            return d.start_time
            except Exception:
                continue
    except Exception:
        pass
    return None


def acquire_operation_lock() -> bool:
    """Попытаться захватить lock операций. True = успешно, False = уже занято."""
    return _operation_lock.acquire(blocking=False)

def release_operation_lock():
    _operation_lock.release()


# Глобальный singleton — импортировать как `from shared import state`
state = BotState()