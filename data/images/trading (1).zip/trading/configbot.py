"""
Конфигурация фьючерсного бота (CCM6)
=== ТОКЕНЫ см. .env ===
"""
from dotenv import load_dotenv
import os

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

# === РЕЖИМ ===
SANDBOX = True           # True = песочница, False = реальный счёт
ACCOUNT_ID = ""           # ID счёта (пусто = TINKOFF_ACCOUNT_ID из .env, иначе первый счёт из списка)

# === DEBUG ===
DEBUG = True              # Детальный вывод индикаторов

# === ИНСТРУМЕНТ ===
TICKER = os.getenv("BOT_TICKER") or "CCM6"   # Тикер фьючерса (MOEX Clearing)

# === ИНТЕРВАЛ СВЕЧЕЙ ===
CANDLE_INTERVAL = "5m"    # 5-минутные свечи

# === СТРАТЕГИЯ ===
EMA_FAST = 9             # Быстрая EMA
EMA_SLOW = 21            # Медленная EMA
RSI_PERIOD = 14          # Период RSI
RSI_OVERBOUGHT = 70      # RSI перекупленность
RSI_OVERSOLD = 30        # RSI перепроданность
VOLUME_MULTIPLIER = 1.2  # Множитель объёма для spike
MOMENTUM_PERIOD = 6      # Momentum (в барах 5-мин = ~30 мин)

# === ФИЛЬТРЫ ВХОДА ===
MOMENTUM_MIN = 0.005     # Минимум momentum (% от цены) для входа
VOLUME_ABS_MIN = 60      # Мин. абсолютный объём (контрактов)
ADX_MIN = 30             # Мин. ADX (сила тренда)
MIN_BETWEEN_SL = 1800    # Пауза после SL перед новым входом (сек, 30 мин)
MIN_COOLDOWN_SEC = 600   # Пауза после ЛЮБОГО выхода (сек, 10 мин)
MIN_SIGNAL_STREAK = 3    # Сколько свечей подряд сигнал должен держаться до входа

RSI_OVERBOUGHT_FILTER = 55  # Запрет LONG если RSI выше этого

# === ПЕРЕОПРЕДЕЛЕНИЯ ПО ТИКЕРАМ ===
# Каждый тикер указывает свои параметры явно.
# Параметр не указанный для тикера = берётся из глобального умолчания.
TICKER_PARAMS = {
    "CRM6": {
        "ADX_MIN": 20,
        "STOP_LOSS_PCT": 0.4,
        "TAKE_PROFIT_PCT": 0.6,
        "TRAILING_ACTIVATE": 0.4,
        "TRAILING_DISTANCE": 0.15,
        "VOLUME_MULTIPLIER": 1.1,
        "RSI_OVERBOUGHT_FILTER": 60,
        "MOMENTUM_PERIOD": 3,
        "COMMISSION_PCT": 0.00462,
        "MIN_BETWEEN_SL": 1800,
    },
    "CCM6": {
        "STOP_LOSS_PCT": 1.2,
        "TAKE_PROFIT_PCT": 1.5,
        "TRAILING_ACTIVATE": 0.8,
        "TRAILING_DISTANCE": 0.4,
        "VOLUME_MULTIPLIER": 1.2,
        "ADX_MIN": 30,
        "RSI_OVERBOUGHT_FILTER": 55,
        "MOMENTUM_PERIOD": 6,
        "COMMISSION_PCT": 0.01320,
        "MIN_BETWEEN_SL": 1800,
        "MOMENTUM_MIN": 0.005,
        "VOLUME_ABS_MIN": 60,
        "MIN_COOLDOWN_SEC": 600,
    },
}

# === ПРОЦЕНТИЛЬНЫЙ ФИЛЬТР ===
PERCENTILE_DAYS = 5        # Окно истории (дней) для расчёта процентилей
PERCENTILE_FILTER = 100    # LONG блокируется выше этого процентиля.
                           # SHORT блокируется ниже (100-PERCENTILE_FILTER)-го.
                           # 100 = фильтр выключен (min/max цена)

# === РИСК-МЕНЕДЖМЕНТ ===
RISK_PERCENT = 1.0       # Риск на сделку (% от депозита)
STOP_LOSS_PCT = 1.2      # Стоп-лосс (%)
TAKE_PROFIT_PCT = 1.5    # Тейк-профит (%)

# === TRAILING STOP ===
TRAILING_ACTIVATE = 0.8   # Активация trailing при росте (%)
TRAILING_DISTANCE = 0.4   # Дистанция trailing (% от пика)

# === СЕРВЕР ===
SERVER_PORT = 5000        # Порт дашборда

# === ВРЕМЯ ===
TIME_FILTER_HOUR = 19    # Запрет входа после этого часа (МСК)
PRELOAD_HOURS = 0        # 0 = загрузить свечи с начала торговой сессии (через API trading_schedules)
                         # >0 = загрузить последние N часов (например, 6 = 6ч ~= 360 свечей 1мин)

# === РЕАЛЬНАЯ ТОРГОВЛЯ ===
MAX_DAILY_LOSS_PCT = 3.0        # Стоп торговли на день при просадке > 3%
MAX_CONSECUTIVE_LOSSES = 2      # Circuit breaker после N убытков подряд
PRICE_DEVIATION_MAX_PCT = 5.0   # Макс. отклонение цены для sanity check
MIN_CASH_BUFFER_PCT = 50        # Буфер ГО при входе (% сверху)
CIRCUIT_BREAKER_COOLDOWN = 3600 # Сброс circuit breaker через N секунд