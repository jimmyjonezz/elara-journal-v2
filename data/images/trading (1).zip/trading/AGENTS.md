# AGENTS.md — CCM6 Trading Bot

## Быстрый старт

| Команда | Назначение |
|---------|-----------|
| `python bot --ticker TICKER` | Запуск бота без дашборда |
| `python server.py --ticker TICKER` | Запуск сервера + бот (sandbox, порт 5000) |
| `python server.py --ticker TICKER --mode real` | Запуск сервера + реальная торговля |
| `python backtest.py --ticker TICKER` | Бэктест (c 1-мин свечами) |
| `python backtest.py --ticker TICKER --days 14 --interval 1` | Бэктест с кастомным периодом |
| `python run_briefing.py` | Генерация аналитического брифинга |

Зависимости устанавливаются вручную: `pip install fastapi uvicorn aiohttp python-dotenv`.

## Архитектура

- Один процесс: `server.py` (FastAPI :5000 + бот в daemon-потоке, `--mode sandbox|real`)
- Lifecycle бота: `threading.Event` в `shared.py`. `/api/bot/stop` → `.clear()`, `/api/bot/start` → `.set()`
- Общее состояние: singleton `shared.state` класса `BotState` (dataclass)

## Конфигурация

- **configbot.py** — параметры стратегии, режим (песочница/реал), риск-менеджмент, `SERVER_PORT = 5000`
- **.env** — токены (не коммитить)
- `SANDBOX = True` — работа через `client.sandbox.sandbox_pay_in()` + `client.orders.post_order()`
- `SANDBOX = False` → используется `TINKOFF_TOKEN` (реальные ордера не реализованы)
- `PRELOAD_HOURS = 0` — загрузка свечей с начала сессии через `trading_schedules` API, fallback 48h

## Tinkoff API (gRPC через SDK t-tech-investments)

- SDK: `pip install t-tech-investments --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple`
- Контекстный менеджер: `async with AsyncClient(token, target=..., app_name=...) as client:`
- `client` на самом деле `AsyncServices` из `t_tech.invest.async_services`
- Ордера: `client.orders.post_order(figi=..., quantity=..., direction=..., account_id=..., order_type=..., order_id=..., instrument_id=...)` — **только keyword-only**
- Свечи истории: `client.get_all_candles(figi=..., from_=..., to=..., interval=1)` → async iterable `HistoricCandle` (есть `is_complete`)
- Свечи стрима: `client.create_market_data_stream()` → `MarketDataStream`, `md.candle` → `Candle` (НЕТ `is_complete`)
- Статус торгов: `client.market_data.get_trading_status(figi=...)` → `TradingStatus` (поля: `trading_status`, `market_order_available_flag`, `limit_order_available_flag`, НЕТ `api_trade_available_flag`)
- Sandbox pay-in: `client.sandbox.sandbox_pay_in(account_id=..., amount=MoneyValue(currency="rub", units=..., nano=0))`
- Конвертация цен: `qfloat(q) = q.units + q.nano / 1e9` — работает для `Quotation` и `MoneyValue`
- MarketDataStream: `stream.candles.waiting_close().subscribe([CandleInstrument(...)])` + `stream.info.subscribe([InfoInstrument(...)])`

## Дашборд

- Порт задаётся в `configbot.py` (`SERVER_PORT`, по умолчанию 5000)
- HTML-дашборд: `templates/index.html` (TradingView Lightweight Charts)
- SSE: `/api/events` — push-обновления состояния
- Кнопки: Start / Stop / Close Pos / Open Long / Open Short

## Брифинг (briefing.py)

- Использует gRPC SDK (`AsyncClient`) для свечей, aiohttp только для `/api/status` бота
- Принимает опциональный `client` параметр от `bot.py` для переиспользования соединения
- Шаблонный анализ (RSI, MACD, Bollinger) — без LLM
- Результаты: `briefings/briefing_{YYYY-MM-DD}.json`
- Триггеры: level break (BB), price move >1.2%, ручной `python run_briefing.py`

## Логи и данные

- Сделки: `logs/trades_{DDMMYYYY}.log` — парсится по шаблону `P/L:\s*([+-]?[\d.]+)`
- Портфель: `logs/portfolio_{DDMMYYYY}.log`
- Статистика при старте загружается из логов (`load_stats_from_logs`)

## Рынок

- Статус определяется динамически: `trading_status` из стрима (`NORMAL_TRADING` || `market_order_available_flag` || `limit_order_available_flag`) + возраст последней свечи ≤ 10 мин как fallback
- Клиринг (14:00–14:03 МСК) — трейдинг-статус уходит из NORMAL_TRADING, бот не входит

## Смена тикера

- `python server.py --ticker CRM6` — сервер с CNY-6.26
- `python backtest.py --ticker CRM6` — бэктест CNY-6.26 (кеш в `history/`, инкрементальные индикаторы)
- `python bot.py --ticker CRM6` — бот напрямую
- Параметры стратегии переопределяются автоматически через `TICKER_PARAMS` в `configbot.py`

## Бэктест

- **Кеш**: `history/{ticker}_{interval}_{from}_{to}.json` — создаётся при первом API-запросе, при повторном запуске грузится локально
- **Инкрементальные индикаторы**: `IncEMA`, `IncRSI`, `IncADX` в `backtest.py` — O(n) вместо O(n²), ~секунда на 10k свечей
- **Датакласс `CachedCandle`**: обёртка для закешированных свечей с теми же аттрибутами (`.time`, `.open`, `.high`, `.low`, `.close`, `.volume`)
- **14-дневный backtest CCM6 (15–29 May 2026) streak=3 + cooldown=10min**: +270 RUB (+0.67%), PF 1.63, WinRate 75%, Sharpe 7.95, Max DD 0.27%

## Стратегия (ключевые параметры)

- EMA fast/slow = 9/21, RSI(14) oversold 30, overbought 70
- ADX ≥ 22, momentum ≥ 0.005%, объём ≥ 1.2× от avg (минимум 60 контрактов)
- Запрет входа после 19:00 МСК
- RSI_OVERBOUGHT_FILTER = 55 — запрет LONG при RSI выше 55
- MIN_SIGNAL_STREAK = 2 — сигнал должен держаться 2 свечи подряд до входа
- SL 1.2%, TP 1.5%, Trailing: активация при +0.8%, дистанция 0.4%
- MIN_SIGNAL_STREAK = 3 — сигнал должен держаться 3 свечи подряд до входа (снижает частоту, повышает качество)
- MIN_COOLDOWN_SEC = 600 — пауза 10 мин после ЛЮБОГО выхода (не только SL)
- PRELOAD_HOURS = 0 — загрузка свечей с начала торговой сессии (через API trading_schedules, fallback 48h)

## Termux (Android)

- **Скрипт**: `bash termux_start.sh help` — смотреть команды
- **Установка**: `bash termux_start.sh install` — ставит tmux, rust, protobuf, pip пакеты
- **Запуск с tmux**: `bash termux_start.sh tmux` — бот в tmux-сессии, не умирает при закрытии Termux
- **Wake lock**: автоматически захватывается и отпускается при выходе
- **Дашборд**: `http://localhost:5000/` в браузере Android
- **Для фоновой работы**: отключить battery optimization для Termux (Настройки → Батарея → Исключения)

## Чего нет

- **Тесты**: отсутствуют
- **Линтер/форматтер/typecheck**: отсутствуют
- **Менеджер пакетов**: отсутствует (`requirements.txt`, `pyproject.toml`)
- **Git**: не репозиторий (папка `.git` есть, но git.exe недоступен в PATH)
