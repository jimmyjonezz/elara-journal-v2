#!/usr/bin/env python3
"""
briefing.py — генерирует аналитический брифинг.
Использует gRPC SDK для свечей, aiohttp только для статуса бота.
"""
import asyncio
import json
import os, sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

BASE_DIR = Path(__file__).parent
BRIEFINGS_DIR = BASE_DIR / "briefings"
BRIEFINGS_DIR.mkdir(exist_ok=True)

from shared import qfloat, get_session_start
from configbot import SERVER_PORT, TICKER as CFG_TICKER, PRELOAD_HOURS
BOT_URL = f"http://127.0.0.1:{SERVER_PORT}"

def load_env():
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if '=' in line and not line.startswith('#'):
                k, v = line.strip().split('=', 1)
                os.environ.setdefault(k, v)

load_env()

TICKER = os.getenv("BOT_TICKER") or CFG_TICKER or "CCM6"


# ─── Indicators ───────────────────────────────────────────────
def calc_rsi(closes: list, period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gain = sum(max(d, 0) for d in deltas[-period:]) / period
    loss = sum(abs(min(d, 0)) for d in deltas[-period:]) / period
    if loss == 0:
        return 100.0
    rs = gain / loss
    return 100 - (100 / (1 + rs))

def calc_atr(candles: list, period: int = 14) -> float:
    if len(candles) < period + 1:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        h, l, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
        tr = max(h - l, abs(h - pc), abs(l - pc))
        trs.append(tr)
    return sum(trs[-period:]) / period

def calc_bollinger(closes: list, period: int = 20, std_mult: float = 2.0):
    if len(closes) < period:
        return None, None, None
    import statistics
    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - std_mult * std, mean, mean + std_mult * std

def calc_macd(closes: list, fast: int = 12, slow: int = 26, signal: int = 9):
    if len(closes) < slow + signal:
        return 0.0, 0.0, 0.0
    def ema(data, n):
        k = 2 / (n + 1)
        ema_val = sum(data[:n]) / n
        for v in data[n:]:
            ema_val = v * k + ema_val * (1 - k)
        return ema_val
    e_fast = ema(closes, fast)
    e_slow = ema(closes, slow)
    macd_line = e_fast - e_slow
    return macd_line, 0.0, macd_line


# ─── Bot state via HTTP ────────────────────────────────────────
async def get_bot_status() -> dict:
    try:
        import aiohttp
        async with aiohttp.ClientSession() as sess:
            async with sess.get(
                f"{BOT_URL}/api/status", timeout=aiohttp.ClientTimeout(total=5)
            ) as r:
                if r.status == 200:
                    return await r.json()
    except Exception:
        pass
    return {}


def build_analysis_template(price, rsi_val, bb, macd_val, atr_val, position, balance) -> dict:
    if rsi_val > 70:
        rsi_sent = "перекуплен"
    elif rsi_val < 30:
        rsi_sent = "перепродан"
    else:
        rsi_sent = "нейтральная зона"
    macd_sent = "бычий" if macd_val > 0 else "медвежий"
    if bb:
        bb_l, bb_m, bb_u = bb
        if price < bb_l:
            bb_pos = "ниже нижней полосы (сильный сигнал на покупку)"
        elif price > bb_u:
            bb_pos = "выше верхней полосы (сильный сигнал на продажу)"
        elif price > bb_m:
            bb_pos = "в верхней половине полос"
        else:
            bb_pos = "в нижней половине полос"
    else:
        bb_pos = "данные BB недоступны"
    sentiment = "bullish" if rsi_val < 50 else "bearish" if rsi_val > 65 else "neutral"
    summary = (
        f"COCOA (CCM6) торгуется на {price:.4f}. "
        f"RSI(14)={rsi_val:.0f} ({rsi_sent}), MACD={macd_sent} ({macd_val:.4f}). "
        f"Bollinger: {bb_pos}. "
        f"{'Позиция SHORT открыта.' if position == 'SHORT' else 'Позиция NONE.'}"
    )
    support = round(bb[0], 4) if bb else 0
    resistance = round(bb[2], 4) if bb else 0
    pivot = round(bb[1], 4) if bb else round(price, 4)
    signals = []
    if rsi_val < 30:
        signals.append(f"RSI перепродан ({rsi_val:.0f}) — сигнал на покупку")
    elif rsi_val > 70:
        signals.append(f"RSI перекуплен ({rsi_val:.0f}) — сигнал на продажу")
    if macd_val > 0:
        signals.append("MACD в положительной зоне — бычий момент")
    elif macd_val < 0:
        signals.append("MACD в отрицательной зоне — медвежий момент")
    warnings = []
    if position != 'NONE':
        warnings.append(f"Позиция {position} открыта")
    if balance < 10000:
        warnings.append(f"Низкий баланс ({balance:.0f} RUB)")
    return {
        "sentiment": sentiment,
        "summary": summary,
        "key_levels": {"support": support, "resistance": resistance, "pivot": pivot},
        "signals": signals or ["нет четких сигналов"],
        "warnings": warnings or [],
        "recommendation": "wait" if sentiment == "neutral" else ("long" if sentiment == "bullish" else "short"),
    }


# ─── File storage (single overwrite) ──────────────────────────
def today_file() -> Path:
    today = datetime.now().strftime("%Y-%m-%d")
    return BRIEFINGS_DIR / f"briefing_{today}.json"

def write_briefing(entry: dict):
    path = today_file()
    path.parent.mkdir(exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(entry, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


# ─── Core briefing logic (extracted, receives AsyncServices) ──
async def _do_briefing(svc) -> None:
    instr = await svc.instruments.future_by(
        id_type=2, class_code="SPBFUT", id=TICKER
    )
    figi = instr.instrument.figi

    now_utc = datetime.now(timezone.utc)
    if PRELOAD_HOURS > 0:
        from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
    else:
        session_start = await get_session_start(svc, TICKER)
        if session_start is None:
            from_utc = now_utc - timedelta(hours=48)
        else:
            from_utc = session_start - timedelta(minutes=1)
    closes = []
    candles = []
    async for c in svc.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
        closes.append(qfloat(c.close))
        candles.append({
            "time": c.time,
            "open": qfloat(c.open),
            "high": qfloat(c.high),
            "low": qfloat(c.low),
            "close": qfloat(c.close),
            "volume": c.volume or 0,
        })

    if not closes and PRELOAD_HOURS == 0:
        print("[briefing] No candles from session start, fallback to 48h", flush=True)
        from_utc = now_utc - timedelta(hours=48)
        closes = []
        candles = []
        async for c in svc.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
            closes.append(qfloat(c.close))
            candles.append({
                "time": c.time,
                "open": qfloat(c.open),
                "high": qfloat(c.high),
                "low": qfloat(c.low),
                "close": qfloat(c.close),
                "volume": c.volume or 0,
            })

    if not closes:
        print("[briefing] No candles, skip.")
        return

    rsi_val = calc_rsi(closes)
    atr_val = calc_atr(candles)
    bb = calc_bollinger(closes)
    macd_val, _, _ = calc_macd(closes)
    status = await get_bot_status()

    price = closes[-1] if closes else 0
    pos = status.get("position", {}).get("side", "NONE")
    bal = status.get("portfolio_balance", 0)
    analysis = build_analysis_template(price, rsi_val, bb, macd_val, atr_val, pos, bal)

    msk_tz = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk_tz)
    entry = {
        "ts": now_msk.isoformat(),
        "price": round(price, 4),
        "rsi": round(rsi_val, 1),
        "atr": round(atr_val, 4),
        "bb_lower": round(bb[0], 4) if bb else 0,
        "bb_upper": round(bb[2], 4) if bb else 0,
        "macd": round(macd_val, 4),
        "position": pos,
        "balance": bal,
        "analysis": analysis,
    }
    write_briefing(entry)
    print(f"[briefing] sentiment={analysis.get('sentiment','?')} price={entry['price']}")


# ─── Main ─────────────────────────────────────────────────────
async def main(client: Optional['AsyncClient'] = None):
    """
    Генерирует брифинг.
    Если client передан (из bot.py) — использует его gRPC-соединение (AsyncServices).
    Если None — создаёт своё (standalone, run_briefing.py).
    """
    try:
        token = os.getenv("TINKOFF_SANDBOX_TOKEN") or os.getenv("TINKOFF_TOKEN")
        if not token:
            print("[briefing] No token, skip.")
            return

        if client is not None:
            await _do_briefing(client)
        else:
            from t_tech.invest import AsyncClient
            from t_tech.invest.constants import INVEST_GRPC_API_SANDBOX, INVEST_GRPC_API
            target = INVEST_GRPC_API_SANDBOX if os.getenv("TINKOFF_SANDBOX_TOKEN") else INVEST_GRPC_API
            async with AsyncClient(token, target=target, app_name="Briefing") as svc:
                await _do_briefing(svc)

    except Exception as e:
        print(f"[briefing] Error: {e}")
        import traceback
        traceback.print_exc()


# ─── Standalone entry point ─────────────────────────────────
if __name__ == "__main__":
    asyncio.run(main())
