"""bot_api.py — FastAPI REST API + SSE для dashboard."""
import os
import asyncio
import json
import re
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import FastAPI, Request, Body
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

from shared import state, acquire_operation_lock, release_operation_lock, qfloat, log_trade
from configbot import TICKER, SERVER_PORT

app = FastAPI(title="CCM6 Trading Bot API")
app.add_middleware(
    CORSMiddleware, allow_origins=[f"http://127.0.0.1:{SERVER_PORT}", f"http://localhost:{SERVER_PORT}"],
    allow_methods=["*"], allow_headers=["*"]
)

LOG_DIR = os.path.dirname(os.path.abspath(__file__)) or "."


# ============================================================
# HELPERS
# ============================================================

def parse_trades_log(date_str: str) -> list:
    """Читает trades_{date}.log и возвращает список сделок."""
    filename = os.path.join(LOG_DIR, "logs", f"trades_{date_str.replace('.', '')}.log")
    trades = []
    if os.path.exists(filename):
        with open(filename, "rb") as f:
            raw = f.read()
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError:
            text = raw.decode("utf-8", errors="replace")
        for line in text.splitlines():
                parts = line.strip().split(" | ")
                if len(parts) < 4:
                    continue
                # 06.05.2026 22:08:46 | OPEN LONG | CCM6 | 1 контрактов @ 316.2000
                # 06.05.2026 22:26:30 | CLOSE (SL) | CCM6 | 1 контрактов @ 316.9000 | P/L: +1.00 RUB
                try:
                    trade = {
                        "time": parts[0],
                        "action": parts[1],
                        "ticker": parts[2],
                        "contracts_str": parts[3],
                        "pnl": None,
                        "reason": None,
                    }
                    if len(parts) >= 5:
                        pnl_part = parts[4]
                        m = re.search(r"P/L:\s*([+-]?[\d.]+)", pnl_part)
                        if m:
                            trade["pnl"] = float(m.group(1))
                        reason_m = re.search(r"(TP|SL|TRAIL|CLOSE)", parts[1])
                        if reason_m:
                            trade["reason"] = reason_m.group(1)
                    # Извлекаем цену
                    price_m = re.search(r"@\s*([\d.]+)", parts[3])
                    if price_m:
                        trade["price"] = float(price_m.group(1))
                    # Направление из action
                    if "LONG" in parts[1]:
                        trade["direction"] = "LONG"
                    elif "SHORT" in parts[1]:
                        trade["direction"] = "SHORT"
                    trades.append(trade)
                except Exception:
                    continue
    return trades


def compute_stats(trades: list) -> dict:
    """Считает статистику из списка сделок."""
    closed = [t for t in trades if t.get("pnl") is not None]
    wins = [t for t in closed if t["pnl"] > 0]
    losses = [t for t in closed if t["pnl"] < 0]
    pnls = [t["pnl"] for t in closed]
    total = sum(pnls) if pnls else 0.0

    return {
        "total_trades": len(closed),
        "wins": len(wins),
        "losses": len(losses),
        "winrate": round(len(wins) / len(closed) * 100, 1) if closed else 0.0,
        "total_pnl": round(total, 2),
        "avg_pnl": round(total / len(closed), 2) if closed else 0.0,
        "best_trade": max(pnls) if pnls else 0.0,
        "worst_trade": min(pnls) if pnls else 0.0,
    }


def _cget(c, key):
    """Get attr from dataclass or dict."""
    if isinstance(c, dict):
        return c.get(key)
    return getattr(c, key, None)

def candles_to_chart(candles: list) -> list:
    """Конвертирует свечи Tinkoff в формат TradingView (time = Unix seconds)."""
    result = []
    for c in candles:
        try:
            raw_time = _cget(c, "time")
            if isinstance(raw_time, (int, float)):
                ts = int(raw_time)
            elif hasattr(raw_time, 'timestamp'):
                ts = int(raw_time.timestamp())
            else:
                t = datetime.fromisoformat(str(raw_time).replace("Z", "+00:00"))
                ts = int(t.timestamp())
            result.append({
                "time": ts,
                "open": qfloat(_cget(c, "open")),
                "high": qfloat(_cget(c, "high")),
                "low": qfloat(_cget(c, "low")),
                "close": qfloat(_cget(c, "close")),
                "volume": _cget(c, "volume") or 0,
            })
        except Exception:
            continue
    return result


# ============================================================
# HTML DASHBOARD
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    with open(os.path.join(LOG_DIR, "templates", "index.html"), encoding="utf-8") as f:
        html = f.read()
    # Inject initial data
    state_data = json.dumps(state.to_dict(), default=str)
    scripts = [
        f'<script>window.__INITIAL__ = {state_data};</script>',
        f'<script>window.__TICKER__ = "{TICKER}";</script>',
    ]
    inject = '\n'.join(scripts)
    html = html.replace('<head>', f'<head>\n{inject}', 1)
    return html


# ============================================================
# REST API
# ============================================================

@app.get("/api/status")
async def status():
    return state.to_dict()


@app.get("/api/portfolio")
async def portfolio():
    """Возвращает последнюю запись из portfolio.jsonl"""
    jsonl_path = os.path.join(LOG_DIR, "logs", "portfolio.jsonl")
    entry = {}
    if os.path.exists(jsonl_path):
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entry = json.loads(line)
                    except:
                        pass
    return entry


@app.get("/api/trades")
async def trades(date: Optional[str] = None, period: Optional[str] = None):
    """period='yesterday' или до 09:00 MSK → вчерашний день."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    if period == "yesterday" or (date is None and now_msk.hour < 9):
        yesterday = now_msk - timedelta(days=1)
        date = yesterday.strftime("%d.%m.%Y")
    elif date is None:
        date = now_msk.strftime("%d.%m.%Y")
    return parse_trades_log(date)


@app.get("/api/candles")
async def candles():
    raw = state.raw_candles or []
    return candles_to_chart(raw[-1000:])  # последние 1000 свечей (~16.7ч, покрывает сессию)


@app.get("/api/stats")
async def stats(date: Optional[str] = None, period: Optional[str] = None):
    """period='yesterday' или до 09:00 MSK → вчерашний день."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    if period == "yesterday" or (date is None and now_msk.hour < 9):
        yesterday = now_msk - timedelta(days=1)
        date = yesterday.strftime("%d.%m.%Y")
    elif date is None:
        date = now_msk.strftime("%d.%m.%Y")
    trades_list = parse_trades_log(date)
    return compute_stats(trades_list)


@app.get("/api/yesterday")
async def yesterday():
    """Всё для вчерашнего дня: trades + stats. Для dashboard до 09:00."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    yesterday_dt = now_msk - timedelta(days=1)
    date_str = yesterday_dt.strftime("%d.%m.%Y")

    trades = parse_trades_log(date_str)
    stats_ = compute_stats(trades)

    # Портьель из JSONL
    jsonl_path = os.path.join(LOG_DIR, "logs", "portfolio.jsonl")
    pf_entry = {}
    if os.path.exists(jsonl_path):
        with open(jsonl_path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        pf_entry = json.loads(line)
                    except:
                        pass

    return {
        "date": date_str,
        "trades": trades,
        "stats": stats_,
        "portfolio": pf_entry,
        "is_yesterday": True,
    }


@app.get("/api/logs")
async def logs(lines: int = 50):
    """Последние N строк bot.log"""
    log_path = os.path.join(LOG_DIR, "bot.log")
    if os.path.exists(log_path):
        with open(log_path, encoding="utf-8") as f:
            all_lines = f.readlines()
        return {"lines": "".join(all_lines[-lines:])}
    return {"lines": ""}


# ============================================================
# REST API
# ============================================================

@app.post("/api/bot/stop")
async def bot_stop():
    """Останавливает бота: очищает lifecycle Event."""
    if not acquire_operation_lock():
        return {"ok": False, "message": "Операция уже выполняется"}
    try:
        from shared import get_lifecycle_event
        state.running = False
        get_lifecycle_event().clear()
        return {"ok": True, "message": "Бот остановлен"}
    finally:
        release_operation_lock()


@app.post("/api/bot/start")
async def bot_start():
    """Запускает бота: устанавливает lifecycle Event."""
    if not acquire_operation_lock():
        return {"ok": False, "message": "Операция уже выполняется"}
    try:
        from shared import get_lifecycle_event
        if state.running:
            return {"ok": False, "message": "Бот уже запущен"}
        state.running = True
        state.start_time = __import__("datetime").datetime.now()
        get_lifecycle_event().set()
        return {"ok": True, "message": "Бот запущен"}
    finally:
        release_operation_lock()


@app.post("/api/bot/close")
async def bot_close():
    """Принудительное закрытие текущей позиции.
    Не сбрасывает position — bot.py обработает force_close и сбросит сам."""
    if not acquire_operation_lock():
        return {"ok": False, "message": "Операция уже выполняется"}
    try:
        if not state.position.is_open():
            return {"ok": False, "message": "Нет открытой позиции"}
        if state.force_close:
            return {"ok": False, "message": "Закрытие уже выполняется"}
        state.force_close = True
        return {"ok": True, "message": "Закрытие инициировано"}
    finally:
        release_operation_lock()


@app.post("/api/bot/open")
async def bot_open(body: dict = Body(default={}), dir: str = "long"):
    """Принудительное открытие позиции (10 лотов). dir=long|short."""
    if not acquire_operation_lock():
        return {"ok": False, "message": "Операция уже выполняется"}
    try:
        if state.position.is_open():
            return {"ok": False, "message": f"Позиция уже открыта: {state.position.side}"}
        side = (body.get("side") or dir).upper()
        if side not in ("LONG", "SHORT"):
            return {"ok": False, "message": "dir должен быть: long или short"}

        if not state.raw_candles:
            return {"ok": False, "message": "Нет данных свечей — невозможно открыть"}

        state.manual_entry_side = side
        return {"ok": True, "message": f"Инициировано открытие {side}"}
    finally:
        release_operation_lock()


# ============================================================
# SSE (Server-Sent Events) — push-обновления в браузер
# ============================================================

@app.get("/api/briefing-history")
async def briefing_history(date: str = None):
    """GET /api/briefing-history?date=YYYY-MM-DD → entry from that day's briefing file."""
    import re
    from pathlib import Path
    base = Path(__file__).parent
    if not date or not re.match(r"^\d{4}-\d{2}-\d{2}$", date):
        date = datetime.now().strftime("%Y-%m-%d")
    path = base / "briefings" / f"briefing_{date}.json"
    if not path.exists():
        return []
    try:
        entry = json.loads(path.read_text(encoding="utf-8"))
        return [entry]
    except Exception:
        return []


@app.get("/api/briefing")
async def get_briefing():
    """GET /api/briefing → latest entry from today's briefing."""
    from pathlib import Path
    base = Path(__file__).parent
    today = datetime.now().strftime("%Y-%m-%d")
    path = base / "briefings" / f"briefing_{today}.json"
    if not path.exists():
        return {"briefing": None, "ts": None}
    try:
        entry = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"briefing": None, "ts": None}
    return {
        "briefing": entry.get("analysis", {}),
        "ts": entry.get("ts", ""),
        "price": entry.get("price"),
        "rsi": entry.get("rsi"),
        "position": entry.get("position"),
        "balance": entry.get("balance"),
    }


@app.get("/api/events")
async def events():
    async def generate():
        last_json = "{}"
        while True:
            current = json.dumps(state.to_dict())
            if current != last_json:
                last_json = current
                yield f"data: {current}\n\n"
            await asyncio.sleep(2)

    return StreamingResponse(generate(), media_type="text/event-stream")