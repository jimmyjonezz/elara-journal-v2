"""
real_trader.py — Торговля на реальные деньги.
Изолирована от bot.py. Импортирует только чистые функции (индикаторы, хелперы).
"""
import sys
import os
import re
import json
import asyncio
import uuid
from datetime import datetime, timezone, timedelta
import time
from pathlib import Path
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
sys.stdout.reconfigure(encoding='utf-8')

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from configbot import (
    ACCOUNT_ID, TICKER, DEBUG,
    EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    VOLUME_MULTIPLIER, MOMENTUM_PERIOD,
    RISK_PERCENT, STOP_LOSS_PCT, TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE, TRAILING_DISTANCE, TIME_FILTER_HOUR, PRELOAD_HOURS,
    MOMENTUM_MIN, VOLUME_ABS_MIN, ADX_MIN, MIN_BETWEEN_SL,
    MIN_SIGNAL_STREAK, RSI_OVERBOUGHT_FILTER, SERVER_PORT,
    PERCENTILE_DAYS, PERCENTILE_FILTER,
    MAX_DAILY_LOSS_PCT, MAX_CONSECUTIVE_LOSSES,
    PRICE_DEVIATION_MAX_PCT, MIN_CASH_BUFFER_PCT,
    CIRCUIT_BREAKER_COOLDOWN,
)
from shared import state, Position, get_lifecycle_event, qfloat, log_trade, get_session_start
from apiclient import post_order_with_retry, orders_lim, portfolio_lim, margin_lim

COMMISSION_PCT = 0

def apply_ticker_overrides():
    import configbot as _cb
    for _k, _v in _cb.TICKER_PARAMS.get(_cb.TICKER, {}).items():
        if _k in globals():
            globals()[_k] = _v

from t_tech.invest import (
    AsyncClient, CandleInstrument, InfoInstrument, SubscriptionInterval,
    OrderDirection, OrderType, MoneyValue,
    SecurityTradingStatus,
)
from t_tech.invest.constants import INVEST_GRPC_API

from bot import (
    cell_mk, price_to_float,
    compute_indicators, analyze_signal,
    calc_pnl, calc_commission, pnl_pct_for,
    load_stats_from_logs, log_portfolio,
    detect_market_from_candles,
)

import briefing as _briefing
BRIEFING_COOLDOWN = 300

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)


# ═══════════════════════════════════════════════════════════════
# RISK MANAGER
# ═══════════════════════════════════════════════════════════════

class RiskManager:
    """Проверки риск-менеджмента перед входом в позицию."""

    def __init__(self):
        self.consecutive_losses = 0
        self.daily_loss_hit = False
        self.circuit_breaker_until = 0.0

    def record_result(self, pnl: float):
        if pnl < 0:
            self.consecutive_losses += 1
        else:
            self.consecutive_losses = 0
        if self.consecutive_losses >= MAX_CONSECUTIVE_LOSSES and self.circuit_breaker_until == 0:
            self.circuit_breaker_until = time.time() + CIRCUIT_BREAKER_COOLDOWN
            state.circuit_breaker = True
            print(f"[RISK] Circuit breaker activated ({CIRCUIT_BREAKER_COOLDOWN}s)", flush=True)

    def check_entry(self, price: float, prev_price: float) -> Optional[str]:
        if self.daily_loss_hit:
            return "Daily loss limit hit"
        now = time.time()
        if self.circuit_breaker_until > now:
            remaining = int(self.circuit_breaker_until - now)
            return f"Circuit breaker active ({remaining}s left)"
        if self.circuit_breaker_until != 0 and now >= self.circuit_breaker_until:
            self.circuit_breaker_until = 0
            state.circuit_breaker = False
            print("[RISK] Circuit breaker reset", flush=True)
        if prev_price and price > 0:
            deviation = abs(price - prev_price) / prev_price * 100
            if deviation > PRICE_DEVIATION_MAX_PCT:
                return f"Price deviation {deviation:.1f}% > max {PRICE_DEVIATION_MAX_PCT}%"
        return None

    def check_daily_loss(self, current_daily_pnl: float, total_cash: float):
        if total_cash <= 0:
            return False
        if current_daily_pnl <= -(MAX_DAILY_LOSS_PCT / 100.0) * total_cash:
            self.daily_loss_hit = True
            print(f"[RISK] Daily loss limit {MAX_DAILY_LOSS_PCT}% hit ({current_daily_pnl:.0f} RUB)", flush=True)
            return True
        return False


# ═══════════════════════════════════════════════════════════════
# PORTFOLIO MANAGER
# ═══════════════════════════════════════════════════════════════

class PortfolioManager:
    """Актуальная информация о балансе и заблокированных средствах."""

    def __init__(self):
        self.total_cash = 0.0
        self.available_cash = 0.0
        self.blocked = 0.0
        self._last_refresh = 0.0

    async def refresh(self, client, account_id: str):
        now = time.time()
        if now - self._last_refresh < 1.0:
            return
        self._last_refresh = now
        try:
            await margin_lim.acquire()
            margin = await client.users.get_margin_attributes(account_id=account_id)
            self.blocked = qfloat(margin.guarantee_for_futures) if qfloat(margin.guarantee_for_futures) > 0 else 0.0

            await portfolio_lim.acquire()
            pf = await client.operations.get_portfolio(account_id=account_id)
            self.total_cash = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())

            self.available_cash = self.total_cash - self.blocked  # liquid_portfolio includes position value; use cash - GO instead

            state.total_cash = self.total_cash
            state.available_cash = self.available_cash
            state.portfolio_balance = self.total_cash
            state.portfolio_blocked = self.blocked
        except Exception as e:
            print(f"[PORTFOLIO] refresh error: {e}", flush=True)

    def margin_ok(self, price: float, lot: int, asset_size: float) -> bool:
        estimated_go = price * lot * asset_size
        needed = estimated_go * (1.0 + MIN_CASH_BUFFER_PCT / 100.0)
        return self.available_cash >= needed

    def can_close_short(self, price: float, lot: int, asset_size: float) -> bool:
        cost = price * lot * asset_size
        return self.total_cash >= cost


# ═══════════════════════════════════════════════════════════════
# EXECUTOR
# ═══════════════════════════════════════════════════════════════

class RealExecutor:
    """Размещение рыночных ордеров с верификацией исполнения."""

    def __init__(self, client, figi, uid, account_id):
        self.client = client
        self.figi = figi
        self.uid = uid
        self.account_id = account_id

    async def market_order(self, direction, quantity) -> dict:
        result = {"success": False, "order_id": "", "filled": 0, "fill_price": None, "error": None}
        try:
            resp = await post_order_with_retry(
                self.client, figi=self.figi, uid=self.uid, quantity=quantity,
                direction=direction, account_id=self.account_id,
                order_type=OrderType.ORDER_TYPE_MARKET,
            )
            result["order_id"] = getattr(resp, 'order_id', '')
            filled = resp.lots_executed or 0
            result["filled"] = filled
            result["success"] = filled == quantity
            if resp.executed_order_price:
                result["fill_price"] = qfloat(resp.executed_order_price)
            if not result["success"]:
                result["error"] = f"Partial fill {filled}/{quantity}"
                print(f"[EXEC] WARNING: {result['error']}", flush=True)
        except Exception as e:
            result["error"] = str(e)
            print(f"[EXEC] order error: {e}", flush=True)
        return result

    async def close_position(self, side: str, price: float, lot: int, label: str) -> dict:
        close_dir = OrderDirection.ORDER_DIRECTION_SELL if side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
        print(f"[{label}] {side} qty={lot} dir={'SELL' if close_dir == OrderDirection.ORDER_DIRECTION_SELL else 'BUY'} @ {price:.4f}", flush=True)
        return await self.market_order(close_dir, lot)


# ═══════════════════════════════════════════════════════════════
# MAIN LOOP
# ═══════════════════════════════════════════════════════════════

async def main():
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    if state.running:
        print("[REAL] Already running.")
        return

    token = os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: TINKOFF_TOKEN not set in .env")
        return

    print(f"[REAL] Start {TICKER} | PRODUCTION | gRPC", flush=True)

    state.raw_candles = []
    stats = load_stats_from_logs()
    for k, v in stats.items():
        setattr(state, k, v)
    print(f"[REAL] Logs: {state.trade_count} trades, P/L={state.total_pnl:+.2f}", flush=True)
    state.last_error = None

    async with AsyncClient(token, target=INVEST_GRPC_API, app_name=f"{TICKER}RealBot") as client:
        instr = await client.instruments.future_by(id_type=2, class_code="SPBFUT", id=TICKER)
        figi = instr.instrument.figi
        uid = instr.instrument.uid
        state.tick_size = qfloat(instr.instrument.min_price_increment)
        state.tick_value = qfloat(instr.instrument.min_price_increment_amount)
        state.basic_asset_size = qfloat(instr.instrument.basic_asset_size)
        print(f"[REAL] {TICKER} -> FIGI={figi} UID={uid} tick={state.tick_size}/{state.tick_value} asset_size={state.basic_asset_size}", flush=True)
        state.current_figi = figi

        apply_ticker_overrides()

        aid = ACCOUNT_ID or os.getenv("TINKOFF_ACCOUNT_ID") or ""
        if not aid:
            accs = await client.users.get_accounts()
            if accs.accounts:
                aid = accs.accounts[0].id
        if not aid:
            print("ERROR: no account ID")
            return
        print(f"[REAL] Account: {aid}", flush=True)

        # Preload candles
        now_utc = datetime.now(timezone.utc)
        if PRELOAD_HOURS > 0:
            from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
            print(f"[REAL] Loading {PRELOAD_HOURS}h history...", flush=True)
        else:
            session_start = await get_session_start(client, TICKER)
            if session_start is None:
                from_utc = now_utc - timedelta(hours=48)
                print(f"[REAL] Session start not found, fallback 48h", flush=True)
            else:
                from_utc = session_start - timedelta(minutes=1)
                print(f"[REAL] Loading from session start {session_start} UTC", flush=True)
        candles = []
        async for c in client.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
            candles.append(c)

        if not candles and PRELOAD_HOURS == 0:
            print("[REAL] No candles from session start, fallback to 48h", flush=True)
            from_utc = now_utc - timedelta(hours=48)
            candles = []
            async for c in client.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
                candles.append(c)

        if not candles:
            print("ERROR: no candle data", flush=True)
            return
        print(f"[REAL] Loaded {len(candles)} candles, last={candles[-1].time}", flush=True)
        state.raw_candles = candles

        # Resume position (always, unlike sandbox-only in bot.py)
        position = Position()
        position.lot = 10
        try:
            pf = await client.operations.get_portfolio(account_id=aid)
            for p in pf.positions:
                if p.figi == figi and qfloat(p.quantity) != 0:
                    qty = int(abs(qfloat(p.quantity)))
                    ep = qfloat(p.average_position_price) if p.average_position_price else 0
                    position.side = 'LONG' if qfloat(p.quantity) > 0 else 'SHORT'
                    position.lot = qty
                    position.entry_price = ep
                    position.peak_price = ep
                    position.entry_time = datetime.now(timezone.utc)
                    print(f"[REAL RESUME] {position.side} {qty} @ {ep:.4f}", flush=True)
                    break
        except Exception as e:
            print(f"[REAL RESUME] portfolio error: {e}", flush=True)

        state.position.side = position.side
        state.position.entry_price = position.entry_price
        state.position.lot = position.lot
        state.position.peak_price = position.peak_price
        state.force_close = False

        # Init managers
        risk = RiskManager()
        portfolio = PortfolioManager()
        executor = RealExecutor(client, figi, uid, aid)

        await portfolio.refresh(client, aid)
        print(f"\n{'='*50}", flush=True)
        print(f"REAL BOT READY | {TICKER}", flush=True)
        print(f"Balance: {portfolio.total_cash:.0f} RUB | Available: {portfolio.available_cash:.0f} RUB | Blocked: {portfolio.blocked:.0f} RUB", flush=True)
        print(f"EMA:{EMA_FAST}/{EMA_SLOW} RSI:{RSI_PERIOD} ADX>={ADX_MIN} SL:{STOP_LOSS_PCT}% TP:{TAKE_PROFIT_PCT}%", flush=True)
        if position.side != 'NONE':
            print(f"Position: {position.side} @ {position.entry_price:.4f}", flush=True)
        print(f"Risk: daily_loss<={MAX_DAILY_LOSS_PCT}% consecutive<={MAX_CONSECUTIVE_LOSSES} dev<={PRICE_DEVIATION_MAX_PCT}%", flush=True)
        print(f"{'='*50}\n", flush=True)

        # Startup briefing
        try:
            print("[REAL] Generating startup briefing...", flush=True)
            await _briefing.main()
            print("[REAL] Startup briefing done.", flush=True)
        except Exception as e:
            print(f"[REAL] Briefing start error: {e}", flush=True)

        # Stream setup
        candle_queue = asyncio.Queue(maxsize=100)
        stream_open = asyncio.Event()
        stream_error = None
        stream_ref = None
        last_stream_msg = 0.0
        reconnecting = False
        reconnect_count = 0
        first_fail_time = 0.0
        state.stream_connected = True

        async def stream_worker():
            nonlocal stream_error, stream_ref
            try:
                stream = client.create_market_data_stream()
                stream_ref = stream
                stream.candles.waiting_close().subscribe([
                    CandleInstrument(figi=figi, interval=SubscriptionInterval.SUBSCRIPTION_INTERVAL_ONE_MINUTE)
                ])
                stream.info.subscribe([InfoInstrument(figi=figi)])
                stream_open.set()
                async for md in stream:
                    if md.candle:
                        await candle_queue.put(('candle', md.candle))
                    if md.trading_status:
                        await candle_queue.put(('status', md.trading_status))
                    if md.ping:
                        await candle_queue.put(('ping', time.time()))
            except Exception as e:
                stream_error = e
                stream_open.set()

        async def restart_stream():
            nonlocal stream_error, stream_ref, worker, stream_open
            stream_open.clear()
            stream_error = None
            stream_ref = None
            worker = asyncio.create_task(stream_worker())
            await asyncio.wait_for(stream_open.wait(), timeout=30)
            if stream_error:
                raise stream_error

        async def sync_candles(fallback_hours=2):
            now_utc = datetime.now(timezone.utc)
            from_utc = now_utc - timedelta(hours=fallback_hours)
            fresh = []
            try:
                async for c in client.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
                    fresh.append(c)
            except Exception:
                return None
            seen = {c.time for c in fresh}
            merged = [c for c in candles if c.time not in seen] + fresh
            merged.sort(key=lambda c: c.time)
            return merged[-500:]

        worker = asyncio.create_task(stream_worker())
        await stream_open.wait()
        if stream_error:
            print(f"[REAL] Stream error: {stream_error}", flush=True)

        last_candle_minute = None
        market_open = detect_market_from_candles(candles)
        prev_price = qfloat(candles[-1].close) if candles else 0
        last_briefing_ts = time.time()
        last_portfolio_ts = time.time()
        prev_signal = ''
        signal_streak = 0

        # ── Helper: close a position ──
        async def do_close(side, entry_price, price, lot, label):
            if side == 'SHORT' and not portfolio.can_close_short(price, lot, state.basic_asset_size):
                print(f"  >> {label}: insufficient RUB to close SHORT", flush=True)
                return False
            result = await executor.close_position(side, price, lot, label)
            if not result["success"]:
                print(f"  >> {label}: order failed: {result.get('error')}", flush=True)
                return False
            com = calc_commission(entry_price, state.basic_asset_size, lot, COMMISSION_PCT)
            com += calc_commission(price, state.basic_asset_size, lot, COMMISSION_PCT)
            pnl = calc_pnl(side, entry_price, price, lot, state.tick_size, state.tick_value) - com
            fill_str = f" fill={result['fill_price']:.4f}" if result['fill_price'] else ""
            log_trade(f"CLOSE ({label})", figi, TICKER, lot, price, pnl)
            print(f"  >> {label} @ {price:.4f}{fill_str} | P/L: {pnl:+.2f} RUB", flush=True)
            state.record_trade(pnl)
            risk.record_result(pnl)
            risk.check_daily_loss(state.daily_pnl, portfolio.total_cash)
            position.reset()
            state.portfolio_blocked = 0.0
            await portfolio.refresh(client, aid)
            return True

        # ── Main loop ──
        while True:
            while not get_lifecycle_event().is_set():
                await asyncio.sleep(0.5)
            state.running = True
            state.start_time = datetime.now()

            try:
                try:
                    msg_type, msg = await asyncio.wait_for(candle_queue.get(), timeout=30)
                    last_stream_msg = time.time()
                    reconnecting = False
                    reconnect_count = 0
                except asyncio.TimeoutError:
                    if worker.done():
                        print(f"[REAL] Stream worker died, reconnecting...", flush=True)
                        reconnect_count += 1
                        if reconnect_count == 1:
                            first_fail_time = time.time()
                        if reconnect_count > 3:
                            elapsed = time.time() - first_fail_time
                            if elapsed < 120:
                                print(f"[REAL] 3 reconnects in {elapsed:.0f}s, giving up for 5min", flush=True)
                                await asyncio.sleep(300)
                            reconnect_count = 0
                        await asyncio.sleep(min(reconnect_count * 5, 60))
                        try:
                            await restart_stream()
                        except Exception as e:
                            print(f"[REAL] Stream restart failed: {e}", flush=True)
                            raise RuntimeError("Stream dead")
                    continue

                now_utc = datetime.now(timezone.utc)
                now_msk = now_utc + timedelta(hours=3)

                # Candle
                if msg_type == 'candle':
                    c = msg
                    last_candle_minute = c.time.minute
                    price = qfloat(c.close)
                    state.current_price = price
                    new_candle = {
                        "time": c.time,
                        "open": qfloat(c.open),
                        "high": qfloat(c.high),
                        "low": qfloat(c.low),
                        "close": price,
                        "volume": c.volume or 0,
                        "is_complete": True,
                    }
                    if not candles or candles[-1].time != c.time:
                        candles.append(c)
                    else:
                        candles[-1] = c
                    candles = candles[-500:]

                # Status
                elif msg_type == 'status':
                    ts = msg
                    market_open = (
                        ts.trading_status == SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING
                        or ts.market_order_available_flag
                        or ts.limit_order_available_flag
                    )

                # Tick / ping
                else:
                    market_open = detect_market_from_candles(candles)

                price = qfloat(candles[-1].close) if candles else 0
                state.current_price = price
                indicators = compute_indicators(candles)
                state.ind_ema = indicators.get('ema_fast') or 0.0
                state.ind_ema_slow = indicators.get('ema_slow') or 0.0
                state.ind_rsi = indicators.get('rsi') or 0.0
                state.ind_adx = indicators.get('adx') or 0.0
                state.ind_momentum = indicators.get('momentum') or 0.0
                if indicators.get('vol_avg'):
                    state.ind_volume_mult = round(indicators['volume'] / indicators['vol_avg'], 2)
                state.ind_percentile_high = indicators.get('percentile_high') or 0.0
                state.ind_percentile_low = indicators.get('percentile_low') or 0.0
                signal = analyze_signal(indicators)

                # ── Signal streak (N-candle confirmation) ──
                if signal == prev_signal and signal != 'NEUTRAL':
                    signal_streak += 1
                elif signal != 'NEUTRAL':
                    signal_streak = 1
                else:
                    signal_streak = 0
                prev_signal = signal

                # Briefing trigger
                now_ts = time.time()
                if now_ts - last_briefing_ts > BRIEFING_COOLDOWN and market_open:
                    bb_l = indicators.get('bb_lower')
                    bb_u = indicators.get('bb_upper')
                    if bb_l and bb_u:
                        if price <= bb_l * 1.002 or price >= bb_u * 0.998:
                            print(f"[REAL] Level break (BB), triggering briefing", flush=True)
                            asyncio.create_task(_briefing.main())
                            last_briefing_ts = now_ts
                    if prev_price and abs(price - prev_price) / prev_price > 0.012:
                        print(f"[REAL] Price move {abs(price-prev_price)/prev_price*100:.2f}%, triggering briefing", flush=True)
                        asyncio.create_task(_briefing.main())
                        last_briefing_ts = now_ts
                prev_price = price

                if DEBUG and msg_type == 'candle':
                    print(
                        f"[{now_msk.strftime('%H:%M')}] "
                        f"p={price:.4f} EMA={indicators['ema_fast'] or 0:.4f}/{indicators['ema_slow'] or 0:.4f} "
                        f"RSI={indicators['rsi'] or 0:.1f} ADX={indicators['adx'] or 0:.1f} "
                        f"MOM={indicators['momentum'] or 0:+.4f}% V={indicators['volume']:>4}/{indicators['vol_avg'] or 0:>4.0f} "
                        f">>> {signal} | pos={position.side} | streak={signal_streak}/{MIN_SIGNAL_STREAK} | market={'OPEN' if market_open else 'CLOSED'}"
                    )

                if signal != 'NEUTRAL' and now_msk.hour >= TIME_FILTER_HOUR:
                    signal = 'NEUTRAL'

                if signal != 'NEUTRAL' and signal_streak < MIN_SIGNAL_STREAK:
                    signal = 'NEUTRAL'

                # ── Close ──
                if state.force_close and market_open:
                    await do_close(position.side, position.entry_price, price, position.lot, "FORCE")
                    state.force_close = False

                elif position.side != 'NONE' and market_open:
                    pp = pnl_pct_for(position.side, position.entry_price, price)

                    # Trailing activation
                    if pp >= TRAILING_ACTIVATE and not position.trailing_active:
                        position.trailing_active = True
                        position.peak_price = price
                        state.position.trailing_active = True
                        if DEBUG:
                            print(f"  >> TRAIL ACTIVE @ {price:.4f} (+{pp:.2f}%)", flush=True)

                    # Trailing close
                    if position.trailing_active:
                        is_long = position.side == 'LONG'
                        if is_long:
                            if price > position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 - TRAILING_DISTANCE / 100)
                            triggered = price <= trail_level
                        else:
                            if price < position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 + TRAILING_DISTANCE / 100)
                            triggered = price >= trail_level
                        if triggered:
                            await do_close(position.side, position.entry_price, price, position.lot, f"TRAIL @ {trail_level:.4f}")
                            continue

                    # Stop-Loss
                    if position.side != 'NONE' and pp <= -STOP_LOSS_PCT:
                        await do_close(position.side, position.entry_price, price, position.lot, "SL")
                        state.last_sl_time = now_utc

                    # Take-Profit
                    if position.side != 'NONE' and pp >= TAKE_PROFIT_PCT:
                        await do_close(position.side, position.entry_price, price, position.lot, "TP")

                    state.position.side = position.side
                    state.position.entry_price = position.entry_price
                    state.position.peak_price = position.peak_price
                    state.position.trailing_active = position.trailing_active
                    state.position.lot = position.lot

                # ── Open ──
                manual_side = state.manual_entry_side
                state.manual_entry_side = ""
                if manual_side:
                    signal = manual_side

                if position.side == 'NONE' and signal != 'NEUTRAL' and market_open:
                    # SL cooldown
                    if state.last_sl_time and (now_utc - state.last_sl_time).total_seconds() < MIN_BETWEEN_SL:
                        signal = 'NEUTRAL'

                    # Risk check
                    risk_err = risk.check_entry(price, prev_price)
                    if risk_err:
                        print(f"  >> Risk blocked entry: {risk_err}", flush=True)
                        signal = 'NEUTRAL'

                    # Daily loss check
                    if risk.check_daily_loss(state.daily_pnl, portfolio.total_cash):
                        print(f"  >> Daily loss limit hit, stopping entries", flush=True)
                        signal = 'NEUTRAL'

                    # Lot calc
                    if signal != 'NEUTRAL':
                        try:
                            if state.basic_asset_size > 0:
                                lot = max(1, int(portfolio.total_cash * 0.5 / (price * state.basic_asset_size)))
                            else:
                                lot = 10
                        except Exception:
                            lot = 10

                        # Margin check
                        if not portfolio.margin_ok(price, lot, state.basic_asset_size):
                            print(f"  >> Insufficient margin (need ~{price * lot * state.basic_asset_size * (1 + MIN_CASH_BUFFER_PCT / 100):.0f}, avail {portfolio.available_cash:.0f})", flush=True)
                            signal = 'NEUTRAL'

                    if signal != 'NEUTRAL':
                        direction = OrderDirection.ORDER_DIRECTION_BUY if signal == 'LONG' else OrderDirection.ORDER_DIRECTION_SELL
                        result = await executor.market_order(direction, lot)
                        if result["success"]:
                            fill_price = result["fill_price"] or price
                            position.side = signal
                            position.entry_price = fill_price
                            position.entry_bar = len(candles)
                            position.lot = lot
                            position.entry_time = now_utc
                            position.peak_price = fill_price
                            position.trailing_active = False
                            log_trade(f"{'[MANUAL] ' if manual_side else ''}OPEN {signal}", figi, TICKER, lot, fill_price)
                            state.position.side = signal
                            state.position.entry_price = fill_price
                            state.position.entry_bar = len(candles)
                            state.position.entry_time = now_utc
                            state.position.peak_price = fill_price
                            state.position.lot = lot
                            await portfolio.refresh(client, aid)
                            state.portfolio_blocked = portfolio.blocked
                            print(f"  >> OPEN {signal} @ {fill_price:.4f} (lot={lot})", flush=True)
                        else:
                            print(f"  >> Open error: {result.get('error')}", flush=True)
                            state.record_error(result.get('error', 'open failed'))

                # Clear stale errors
                if state.last_error and 'Cannot connect' in str(state.last_error):
                    state.last_error = None

                # Portfolio log every 60s (only when in position)
                if time.time() - last_portfolio_ts > 60 and state.position.side != 'NONE':
                    await portfolio.refresh(client, aid)
                    log_portfolio()
                    last_portfolio_ts = time.time()

            except asyncio.CancelledError:
                print("\n[REAL] Cancelled.", flush=True)
                break
            except Exception as e:
                import traceback
                print(f"[REAL] Error: {e}", flush=True)
                traceback.print_exc()
                state.record_error(str(e))
                if isinstance(e, RuntimeError):
                    raise
                await asyncio.sleep(5)

        worker.cancel()
        if stream_ref:
            stream_ref.stop()
        print("[REAL] Stopped.", flush=True)


# ═══════════════════════════════════════════════════════════════
# RUN FOREVER
# ═══════════════════════════════════════════════════════════════

async def run_forever(ticker=None):
    if ticker:
        import configbot
        configbot.TICKER = ticker
        os.environ["BOT_TICKER"] = ticker
    import traceback
    delay = 1
    while True:
        try:
            await main()
            delay = 1
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"[REAL] CRASH: {e}", flush=True)
            traceback.print_exc()
            print(f"[REAL] Restart in {delay}s...", flush=True)
            await asyncio.sleep(delay)
            delay = min(delay * 2, 60)
            continue
        break
