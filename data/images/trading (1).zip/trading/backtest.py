"""
backtest.py — прогон стратегии на исторических данных за N дней.
Использует те же индикаторы, что и bot.py.
"""
import sys, os, json, asyncio, statistics, math, argparse
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from configbot import (
    TICKER as CFG_TICKER, SANDBOX,
    EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    VOLUME_MULTIPLIER, MOMENTUM_PERIOD,
    STOP_LOSS_PCT, TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE, TRAILING_DISTANCE, TIME_FILTER_HOUR,
    MOMENTUM_MIN, VOLUME_ABS_MIN, ADX_MIN, RSI_OVERBOUGHT_FILTER,
    CANDLE_INTERVAL,
    PERCENTILE_DAYS, PERCENTILE_FILTER, MIN_BETWEEN_SL,
    MIN_SIGNAL_STREAK,
    MIN_COOLDOWN_SEC,
)

COMMISSION_PCT = 0

from shared import qfloat
from bot import calc_ema, calc_rsi, calc_adx, calc_momentum, calc_volume_avg, calc_pnl
from t_tech.invest import AsyncClient
from t_tech.invest.constants import INVEST_GRPC_API_SANDBOX

HISTORY_DIR = Path(__file__).parent / "history"
HISTORY_DIR.mkdir(exist_ok=True)

class CachedCandle:
    __slots__ = ('time', 'open', 'high', 'low', 'close', 'volume')
    def __init__(self, **kw):
        for k, v in kw.items():
            setattr(self, k, v)

class IncEMA:
    __slots__ = ('alpha', 'value', '_count')
    def __init__(self, period):
        self.alpha = 2.0 / (period + 1)
        self.value = None
        self._count = 0
    def add(self, price):
        if self.value is None:
            self.value = price
        else:
            self.value = price * self.alpha + self.value * (1 - self.alpha)
        self._count += 1
    def ready(self, min_samples):
        return self._count >= min_samples

class IncRSI:
    __slots__ = ('period', 'avg_gain', 'avg_loss', 'prev_close', '_count')
    def __init__(self, period):
        self.period = period
        self.avg_gain = 0.0
        self.avg_loss = 0.0
        self.prev_close = None
        self._count = 0
    def add(self, price):
        if self.prev_close is not None:
            diff = price - self.prev_close
            gain = diff if diff > 0 else 0.0
            loss = -diff if diff < 0 else 0.0
            if self._count <= self.period:
                self.avg_gain += gain
                self.avg_loss += loss
            else:
                self.avg_gain = (self.avg_gain * (self.period - 1) + gain) / self.period
                self.avg_loss = (self.avg_loss * (self.period - 1) + loss) / self.period
        self.prev_close = price
        self._count += 1
    def ready(self, min_samples):
        return self._count > min_samples  # need one extra for initial diff
    def value(self):
        if self.avg_loss == 0:
            return 100.0
        rs = self.avg_gain / self.avg_loss
        return 100.0 - (100.0 / (1.0 + rs))

class IncADX:
    __slots__ = ('period', 'tr', 'plus_dm', 'minus_dm', 'adx', 'prev_high', 'prev_low', 'prev_close',
                 '_count', '_tr_smooth', '_plus_smooth', '_minus_smooth', '_dx_vals')
    def __init__(self, period):
        self.period = period
        self.prev_high = None
        self.prev_low = None
        self.prev_close = None
        self._count = 0
        self.tr = 0.0
        self.plus_dm = 0.0
        self.minus_dm = 0.0
        self._tr_smooth = None
        self._plus_smooth = None
        self._minus_smooth = None
        self._dx_vals = []
    def add(self, high, low, close):
        if self.prev_high is not None:
            tr = max(high - low, abs(high - self.prev_close), abs(low - self.prev_close))
            up_move = high - self.prev_high
            down_move = self.prev_low - low
            pdm = up_move if up_move > down_move and up_move > 0 else 0.0
            mdm = down_move if down_move > up_move and down_move > 0 else 0.0
            if self._count <= self.period:
                self.tr += tr
                self.plus_dm += pdm
                self.minus_dm += mdm
            else:
                if self._tr_smooth is None:
                    self._tr_smooth = self.tr
                    self._plus_smooth = self.plus_dm
                    self._minus_smooth = self.minus_dm
                self._tr_smooth = (self._tr_smooth * (self.period - 1) + tr) / self.period
                self._plus_smooth = (self._plus_smooth * (self.period - 1) + pdm) / self.period
                self._minus_smooth = (self._minus_smooth * (self.period - 1) + mdm) / self.period
                if self._plus_smooth + self._minus_smooth != 0:
                    dx = abs(self._plus_smooth - self._minus_smooth) / (self._plus_smooth + self._minus_smooth) * 100.0
                    self._dx_vals.append(dx)
                    if len(self._dx_vals) > self.period:
                        self._dx_vals.pop(0)
        self.prev_high = high
        self.prev_low = low
        self.prev_close = close
        self._count += 1
    def ready(self, min_samples):
        return self._count >= self.period + min_samples
    def value(self):
        if not self._dx_vals:
            return 0.0
        return sum(self._dx_vals) / len(self._dx_vals)

DAYS = 7
LOT = 10  # 10 контрактов (пересчитывается от basic_asset_size)

INITIAL_EQUITY = 40000.0

TICKER_FALLBACKS = [
    "CRM6",       # CNY futures, июнь 2026
    "CR-6.26",    # MOEX формат
    "CR6.26",     # без дефиса
    "CR",         # базовый код
]

@dataclass
class Trade:
    side: str
    entry_time: datetime
    entry_price: float
    exit_time: datetime = None
    exit_price: float = None
    reason: str = ''
    pnl: float = 0.0
    pnl_pct: float = 0.0

@dataclass
class BacktestState:
    side: str = 'NONE'
    entry_price: float = 0.0
    entry_time: datetime = None
    entry_bar: int = 0
    peak_price: float = 0.0
    trailing_active: bool = False
    trades: list = field(default_factory=list)
    equity: float = INITIAL_EQUITY
    peak_equity: float = INITIAL_EQUITY

    def reset(self):
        self.side = 'NONE'
        self.entry_price = 0.0
        self.entry_time = None
        self.entry_bar = 0
        self.peak_price = 0.0
        self.trailing_active = False

def calc_percentile(values, percentile):
    if not values:
        return None
    s = sorted(values)
    idx = int(len(s) * percentile / 100)
    idx = max(0, min(idx, len(s) - 1))
    return s[idx]

def pnl_pct(side, entry, cur):
    if entry <= 0:
        return 0.0
    return ((cur - entry) / entry * 100) if side == 'LONG' else ((entry - cur) / entry * 100)

def calc_commission(price, asset_size, lot, rate_pct):
    if rate_pct <= 0 or price <= 0 or asset_size <= 0:
        return 0.0
    return round(price * asset_size * (rate_pct / 100) * lot, 2)

async def run(ticker_override=None):
    token = os.getenv("TINKOFF_SANDBOX_TOKEN") or os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: no token")
        return

    target = INVEST_GRPC_API_SANDBOX if SANDBOX else None
    async with AsyncClient(token, target=target, app_name="Backtest") as client:
        if ticker_override:
            tickers_to_try = [ticker_override] + TICKER_FALLBACKS
        else:
            tickers_to_try = [CFG_TICKER] + TICKER_FALLBACKS
        figi = None
        resolved_ticker = None
        for tkr in tickers_to_try:
            if not tkr:
                continue
            try:
                instr = await client.instruments.future_by(id_type=2, class_code="SPBFUT", id=tkr)
                figi = instr.instrument.figi
                ts_ = qfloat(instr.instrument.min_price_increment)
                tv_ = qfloat(instr.instrument.min_price_increment_amount)
                bas_ = qfloat(instr.instrument.basic_asset_size)
                contract_mult = tv_ / ts_ if ts_ > 0 else bas_
                resolved_ticker = tkr
                print(f"  Resolved: {tkr} -> {figi} tick={ts_}/{tv_} asset_size={bas_} mult={contract_mult:.0f}")
                break
            except Exception as e:
                print(f"  {tkr}: not found ({e})")
                continue
        if not figi or not resolved_ticker:
            print(f"ERROR: could not resolve any ticker from: {tickers_to_try}")
            return

        # Apply ticker-specific param overrides
        import configbot as _cfg
        _override_key = f"{resolved_ticker}_5MIN" if CANDLE_INTERVAL == 2 else resolved_ticker
        _overrides = _cfg.TICKER_PARAMS.get(_override_key, _cfg.TICKER_PARAMS.get(resolved_ticker, {}))
        if _overrides:
            for _k, _v in _overrides.items():
                if _k in globals():
                    globals()[_k] = _v
            print(f"  Applied {len(_overrides)} overrides for {resolved_ticker}: {_overrides}")
        print(f"  Commission rate: {COMMISSION_PCT}% of notional per side")
        print(f"  SL cooldown: {MIN_BETWEEN_SL} sec")

        now = datetime.now(timezone.utc)
        from_ = now - timedelta(days=DAYS)
        print(f"Loading {DAYS} days ({from_.date()} to {now.date()})...")

        _cache_key = f"{resolved_ticker}_{CANDLE_INTERVAL}_{from_.strftime('%Y%m%d')}_{now.strftime('%Y%m%d')}"
        _cache_path = HISTORY_DIR / f"{_cache_key}.json"
        candles = []

        if _cache_path.exists():
            print(f"  Cache found: {_cache_path.name}")
            _data = json.loads(_cache_path.read_text(encoding="utf-8"))
            for d in _data:
                c = CachedCandle(time=datetime.fromisoformat(d['t']), open=d['o'], high=d['h'], low=d['l'], close=d['c'], volume=d['v'])
                candles.append(c)
        else:
            print(f"  Downloading from API...")
            async for c in client.get_all_candles(figi=figi, from_=from_, to=now, interval=CANDLE_INTERVAL):
                candles.append(c)
            _data = [{"t": c.time.isoformat(), "o": qfloat(c.open), "h": qfloat(c.high),
                      "l": qfloat(c.low), "c": qfloat(c.close), "v": c.volume} for c in candles]
            _cache_path.write_text(json.dumps(_data, ensure_ascii=False), encoding="utf-8")
            print(f"  Cached to {_cache_path.name}")

        print(f"Loaded {len(candles)} candles")

        if not candles:
            print("No candles")
            return

        # Auto-calculate LOT from contract multiplier
        if contract_mult > 0:
            _prices = [qfloat(c.close) for c in candles[:100]]
            _avg = sum(_prices) / len(_prices) if _prices else qfloat(candles[-1].close)
            _notional = _avg * contract_mult
            LOT = max(1, int(INITIAL_EQUITY * 0.5 / _notional))
            print(f"  LOT={LOT} (notional={_notional:.0f} RUB/contract @ avg={_avg:.4f})")

        bt = BacktestState()
        last_sl_time = None
        last_exit_time = None
        prev_signal = ''
        signal_streak = 0
        inc_ema_f = IncEMA(EMA_FAST)
        inc_ema_s = IncEMA(EMA_SLOW)
        inc_rsi = IncRSI(RSI_PERIOD)
        inc_adx = IncADX(14)
        _mom_vals = []
        _vol_ring = []
        _close_ring = []  # last 500 closes for percentile

        for i, c in enumerate(candles):
            price = qfloat(c.close)
            ts = c.time
            high = qfloat(c.high)
            low = qfloat(c.low)
            vol = c.volume

            inc_ema_f.add(price)
            inc_ema_s.add(price)
            inc_rsi.add(price)
            inc_adx.add(high, low, price)
            _mom_vals.append(price)
            _vol_ring.append(vol)
            if len(_vol_ring) > 20:
                _vol_ring.pop(0)
            _close_ring.append(price)
            if len(_close_ring) > 500:
                _close_ring.pop(0)

            if i < EMA_SLOW:
                continue

            ema_f = inc_ema_f.value
            ema_s = inc_ema_s.value
            rsi = inc_rsi.value()
            adx = inc_adx.value()
            mom = (_mom_vals[-1] / _mom_vals[-1 - MOMENTUM_PERIOD] - 1) * 100 if len(_mom_vals) > MOMENTUM_PERIOD and _mom_vals[-1 - MOMENTUM_PERIOD] != 0 else 0
            vol_avg = sum(_vol_ring) / len(_vol_ring) if _vol_ring else vol

            msk = ts + timedelta(hours=3)

            # ── Exit logic (high/low based) ──
            if bt.side != 'NONE':
                low = qfloat(c.low)
                high = qfloat(c.high)

                if bt.side == 'LONG':
                    sl_triggered = low <= bt.entry_price * (1 - STOP_LOSS_PCT / 100)
                    tp_triggered = high >= bt.entry_price * (1 + TAKE_PROFIT_PCT / 100)

                    # Trailing activation on high
                    if not bt.trailing_active and high >= bt.entry_price * (1 + TRAILING_ACTIVATE / 100):
                        bt.trailing_active = True
                        bt.peak_price = max(bt.peak_price, bt.entry_price)

                    if bt.trailing_active:
                        if high > bt.peak_price:
                            bt.peak_price = high
                        trail_level = bt.peak_price * (1 - TRAILING_DISTANCE / 100)
                        trail_triggered = low <= trail_level
                    else:
                        trail_triggered = False
                        trail_level = 0

                    # Order: SL → TRAIL → TP
                    if sl_triggered:
                        ep = bt.entry_price * (1 - STOP_LOSS_PCT / 100)
                        pp = -STOP_LOSS_PCT
                        com = calc_commission(bt.entry_price, contract_mult, LOT, COMMISSION_PCT) + calc_commission(ep, contract_mult, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('LONG', bt.entry_price, ep, LOT, ts_, tv_) - com
                        t = Trade('LONG', bt.entry_time, bt.entry_price, ts, ep, 'SL', pnl, pp)
                        last_sl_time = ts
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

                    if trail_triggered:
                        pp = pnl_pct('LONG', bt.entry_price, trail_level)
                        com = calc_commission(bt.entry_price, contract_mult, LOT, COMMISSION_PCT) + calc_commission(trail_level, contract_mult, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('LONG', bt.entry_price, trail_level, LOT, ts_, tv_) - com
                        t = Trade('LONG', bt.entry_time, bt.entry_price, ts, trail_level, 'TRAIL', pnl, pp)
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

                    if tp_triggered:
                        ep = bt.entry_price * (1 + TAKE_PROFIT_PCT / 100)
                        pp = TAKE_PROFIT_PCT
                        com = calc_commission(bt.entry_price, contract_mult, LOT, COMMISSION_PCT) + calc_commission(ep, contract_mult, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('LONG', bt.entry_price, ep, LOT, ts_, tv_) - com
                        t = Trade('LONG', bt.entry_time, bt.entry_price, ts, ep, 'TP', pnl, pp)
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

                else:  # SHORT
                    sl_triggered = high >= bt.entry_price * (1 + STOP_LOSS_PCT / 100)
                    tp_triggered = low <= bt.entry_price * (1 - TAKE_PROFIT_PCT / 100)

                    # Trailing activation on low
                    if not bt.trailing_active and low <= bt.entry_price * (1 - TRAILING_ACTIVATE / 100):
                        bt.trailing_active = True
                        bt.peak_price = min(bt.peak_price, bt.entry_price)

                    if bt.trailing_active:
                        if low < bt.peak_price:
                            bt.peak_price = low
                        trail_level = bt.peak_price * (1 + TRAILING_DISTANCE / 100)
                        trail_triggered = high >= trail_level
                    else:
                        trail_triggered = False
                        trail_level = 0

                    # Order: SL → TRAIL → TP
                    if sl_triggered:
                        ep = bt.entry_price * (1 + STOP_LOSS_PCT / 100)
                        pp = -STOP_LOSS_PCT
                        com = calc_commission(bt.entry_price, contract_mult, LOT, COMMISSION_PCT) + calc_commission(ep, contract_mult, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('SHORT', bt.entry_price, ep, LOT, ts_, tv_) - com
                        t = Trade('SHORT', bt.entry_time, bt.entry_price, ts, ep, 'SL', pnl, pp)
                        last_sl_time = ts
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

                    if trail_triggered:
                        pp = pnl_pct('SHORT', bt.entry_price, trail_level)
                        com = calc_commission(bt.entry_price, contract_mult, LOT, COMMISSION_PCT) + calc_commission(trail_level, contract_mult, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('SHORT', bt.entry_price, trail_level, LOT, ts_, tv_) - com
                        t = Trade('SHORT', bt.entry_time, bt.entry_price, ts, trail_level, 'TRAIL', pnl, pp)
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

                    if tp_triggered:
                        ep = bt.entry_price * (1 - TAKE_PROFIT_PCT / 100)
                        pp = TAKE_PROFIT_PCT
                        com = calc_commission(bt.entry_price, bas_, LOT, COMMISSION_PCT) + calc_commission(ep, bas_, LOT, COMMISSION_PCT)
                        pnl = calc_pnl('SHORT', bt.entry_price, ep, LOT, ts_, tv_) - com
                        t = Trade('SHORT', bt.entry_time, bt.entry_price, ts, ep, 'TP', pnl, pp)
                        bt.trades.append(t)
                        bt.equity += t.pnl
                        bt.peak_equity = max(bt.peak_equity, bt.equity)
                        last_exit_time = ts
                        bt.reset()
                        continue

            # ── Signal streak (N-candle confirmation) ──
            if bt.side == 'NONE':
                if None in (ema_f, ema_s, rsi, vol_avg):
                    continue
                cur_signal = 'NEUTRAL'
                trend_up = ema_f > ema_s
                vol_ok = vol >= vol_avg * VOLUME_MULTIPLIER and vol >= VOLUME_ABS_MIN
                adx_ok = adx >= ADX_MIN
                mom_ok = abs(mom) >= MOMENTUM_MIN
                n = min(len(_close_ring), PERCENTILE_DAYS * 525, 500)
                if len(_close_ring) >= 100:
                    subset = _close_ring[-n:]
                    ph = calc_percentile(subset, PERCENTILE_FILTER)
                    pl = calc_percentile(subset, 100 - PERCENTILE_FILTER)
                else:
                    ph = pl = None
                if trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD \
                   and (ph is None or price <= ph):
                    cur_signal = 'LONG'
                elif not trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD \
                     and (pl is None or price >= pl):
                    cur_signal = 'SHORT'
                if cur_signal == prev_signal and cur_signal != 'NEUTRAL':
                    signal_streak += 1
                elif cur_signal != 'NEUTRAL':
                    signal_streak = 1
                else:
                    signal_streak = 0
                prev_signal = cur_signal

            # ── Entry logic ──
            if bt.side == 'NONE':
                if msk.hour >= TIME_FILTER_HOUR:
                    continue
                if last_sl_time and (ts - last_sl_time).total_seconds() < MIN_BETWEEN_SL:
                    continue
                if last_exit_time and (ts - last_exit_time).total_seconds() < MIN_COOLDOWN_SEC:
                    continue
                if cur_signal == 'NEUTRAL' or signal_streak < MIN_SIGNAL_STREAK:
                    continue

                bt.side = cur_signal
                bt.entry_price = price
                bt.entry_time = ts
                bt.entry_bar = i
                bt.peak_price = price

        # Close any open position at end
        if bt.side != 'NONE':
            price = qfloat(candles[-1].close)
            com = calc_commission(bt.entry_price, bas_, LOT, COMMISSION_PCT) + calc_commission(price, bas_, LOT, COMMISSION_PCT)
            pnl = calc_pnl(bt.side, bt.entry_price, price, LOT, ts_, tv_) - com
            pp = pnl_pct(bt.side, bt.entry_price, price)
            t = Trade(bt.side, bt.entry_time, bt.entry_price, candles[-1].time, price, 'FORCE_CLOSE', pnl, pp)
            bt.trades.append(t)
            bt.equity += pnl
            bt.peak_equity = max(bt.peak_equity, bt.equity)
            last_exit_time = candles[-1].time
            bt.reset()

        # ── Compute stats ──
        closed = bt.trades
        wins = [t for t in closed if t.pnl > 0]
        losses = [t for t in closed if t.pnl < 0]
        total_pnl = sum(t.pnl for t in closed)
        gross_profit = sum(t.pnl for t in wins)
        gross_loss = abs(sum(t.pnl for t in losses))
        profit_factor = round(gross_profit / gross_loss, 2) if gross_loss > 0 else float('inf')
        avg_win = round(sum(t.pnl for t in wins) / len(wins), 2) if wins else 0
        avg_loss = round(sum(t.pnl for t in losses) / len(losses), 2) if losses else 0
        wr = round(len(wins) / len(closed) * 100, 1) if closed else 0
        max_consec_wins = 0
        max_consec_losses = 0
        cur_streak = 0
        cur_type = None
        for t in closed:
            ttype = 'W' if t.pnl > 0 else 'L'
            if ttype == cur_type:
                cur_streak += 1
            else:
                cur_streak = 1
                cur_type = ttype
            if cur_type == 'W':
                max_consec_wins = max(max_consec_wins, cur_streak)
            else:
                max_consec_losses = max(max_consec_losses, cur_streak)
        best_trade = max(closed, key=lambda x: x.pnl) if closed else None
        worst_trade = min(closed, key=lambda x: x.pnl) if closed else None
        dd = max(0, bt.peak_equity - min(bt.equity, bt.peak_equity)) if closed else 0
        dd_pct = round(dd / bt.peak_equity * 100, 2) if bt.peak_equity > 0 else 0

        # Per-day breakdown
        daily = {}
        for t in closed:
            d = t.exit_time.date()
            daily.setdefault(d, {'pnl': 0.0, 'wins': 0, 'losses': 0, 'count': 0})
            daily[d]['pnl'] += t.pnl
            daily[d]['count'] += 1
            if t.pnl > 0:
                daily[d]['wins'] += 1
            else:
                daily[d]['losses'] += 1

        # Approximate Sharpe Ratio (daily returns)
        daily_returns = [v['pnl'] for v in daily.values()]
        sharpe = round(statistics.mean(daily_returns) / statistics.stdev(daily_returns) * math.sqrt(252), 2) \
            if len(daily_returns) > 1 and statistics.stdev(daily_returns) > 0 else 0

        # ── Print results ──
        print(f"\n{'='*68}")
        print(f"  BACKTEST RESULTS — {resolved_ticker} | {DAYS} days | {LOT} contract")
        print(f"{'='*68}")
        print(f"  Period:      {candles[0].time.date()} to {candles[-1].time.date()}")
        print(f"  Candles:     {len(candles)} ({CANDLE_INTERVAL})")
        print(f"  Trades:      {len(closed)}")
        print(f"  {'─'*64}")
        print(f"  Wins:        {len(wins)} / Losses: {len(losses)}")
        print(f"  WinRate:     {wr}%")
        print(f"  Profit Fact: {profit_factor}")
        print(f"  Total P/L:   {total_pnl:+.2f} RUB")
        print(f"  Avg Win:     {avg_win:+.2f} RUB")
        print(f"  Avg Loss:    {avg_loss:+.2f} RUB")
        print(f"  Best:        {best_trade.pnl:+.2f} RUB" if best_trade else "  Best:        -")
        print(f"  Worst:       {worst_trade.pnl:+.2f} RUB" if worst_trade else "  Worst:       -")
        print(f"  Max Consec W:{max_consec_wins} / L:{max_consec_losses}")
        print(f"  Sharpe (ann):{sharpe}")
        print(f"  {'─'*64}")
        print(f"  Start:       {INITIAL_EQUITY:.2f} RUB")
        print(f"  End:         {bt.equity:.2f} RUB")
        ret = (bt.equity - INITIAL_EQUITY) / INITIAL_EQUITY * 100
        print(f"  Return:      {ret:+.2f}%")
        print(f"  Max DD:      {dd:.2f} RUB ({dd_pct}%)")
        print(f"{'='*68}\n")

        # Daily breakdown
        print(f"{'─'*68}")
        print(f"  DAILY BREAKDOWN")
        print(f"{'─'*68}")
        print(f"  {'Date':12s} {'Trades':>6s} {'W/L':>8s} {'PnL':>10s} {'Cumul PnL':>10s}")
        print(f"  {'─'*48}")
        cumul = 0
        for d in sorted(daily.keys()):
            v = daily[d]
            cumul += v['pnl']
            wl = f"{v['wins']}/{v['losses']}"
            print(f"  {d.strftime('%Y-%m-%d'):12s} {v['count']:6d} {wl:>8s} {v['pnl']:>+10.2f} {cumul:>+10.2f}")
        print(f"  {'─'*48}\n")

        # All trades table
        print(f"{'─'*96}")
        print(f"  ALL TRADES")
        print(f"{'─'*96}")
        header = f"  {'#':>3s} {'Side':5s} {'Entry':>14s} {'Exit':>14s} {'EntryPx':>8s} {'ExitPx':>8s} {'P/L%':>7s} {'PnL':>8s} {'Reason':10s}"
        print(header)
        print(f"  {'─'*88}")
        for idx, t in enumerate(closed, 1):
            et = t.entry_time.strftime('%m-%d %H:%M')
            ext = t.exit_time.strftime('%m-%d %H:%M') if t.exit_time else '?'
            print(f"  {idx:3d} {t.side:5s} {et:>14s} {ext:>14s} {t.entry_price:>8.4f} {t.exit_price:>8.4f} {t.pnl_pct:>+6.2f}% {t.pnl:>+8.2f} {t.reason:10s}")
        print(f"  {'─'*88}")
        print(f"  {'TOTAL':>52s} {total_pnl:>+8.2f}")
        print(f"{'─'*96}\n")

        # JSON export
        result = {
            "ticker": resolved_ticker,
            "days": DAYS,
            "from": str(candles[0].time.date()),
            "to": str(candles[-1].time.date()),
            "candles": len(candles),
            "interval": CANDLE_INTERVAL,
            "trades_count": len(closed),
            "wins": len(wins),
            "losses": len(losses),
            "winrate": wr,
            "profit_factor": profit_factor,
            "total_pnl": round(total_pnl, 2),
            "avg_win": avg_win,
            "avg_loss": avg_loss,
            "best_trade": round(best_trade.pnl, 2) if best_trade else 0,
            "worst_trade": round(worst_trade.pnl, 2) if worst_trade else 0,
            "max_consec_wins": max_consec_wins,
            "max_consec_losses": max_consec_losses,
            "sharpe_annual": sharpe,
            "start_equity": INITIAL_EQUITY,
            "end_equity": round(bt.equity, 2),
            "return_pct": round(ret, 2),
            "max_dd_rub": round(dd, 2),
            "max_dd_pct": dd_pct,
            "daily": {str(d): round(v['pnl'], 2) for d, v in sorted(daily.items())},
            "trades": [
                {
                    "side": t.side,
                    "entry": t.entry_time.strftime('%Y-%m-%dT%H:%M:%S'),
                    "exit": t.exit_time.strftime('%Y-%m-%dT%H:%M:%S') if t.exit_time else None,
                    "entry_price": t.entry_price,
                    "exit_price": t.exit_price,
                    "reason": t.reason,
                    "pnl": round(t.pnl, 2),
                    "pnl_pct": round(t.pnl_pct, 2)
                }
                for t in closed
            ]
        }
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        _backtest_dir = Path(__file__).parent / "backtest"
        _backtest_dir.mkdir(exist_ok=True)
        json_path = _backtest_dir / f"backtest_result_{resolved_ticker}_{ts}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)
        print(f"  JSON saved: {json_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Backtest trading strategy")
    parser.add_argument("--ticker", type=str, default=None,
                        help=f"Ticker to backtest (default: {CFG_TICKER})")
    parser.add_argument("--days", type=int, default=DAYS,
                        help=f"Days of history (default: {DAYS})")
    parser.add_argument("--interval", type=int, default=1, choices=[1, 2],
                        help="Candle interval: 1=1min, 2=5min (default: 1)")
    args = parser.parse_args()
    DAYS = args.days
    CANDLE_INTERVAL = args.interval
    asyncio.run(run(ticker_override=args.ticker))
