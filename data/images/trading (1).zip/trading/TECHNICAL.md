# Tinkoff Futures Trading Bot — Техническая записка

## 1. Архитектура системы

### 1.1. Обзор

Однопроцессное приложение: FastAPI-сервер (`server.py`) запускает Uvicorn в главном
async-цикле и порождает daemon-поток с ботом. Бот работает в своём собственном
event loop. Коммуникация между потоками — через `threading`-примитивы и общий
dataclass `BotState`.

```
┌─────────────────────────────────────────────────────┐
│  server.py (главный процесс)                         │
│                                                      │
│  thread 1 (main): asyncio.run → uvicorn              │
│    ┌──────────────────────┐                          │
│    │  bot_api.py          │ ← REST / SSE             │
│    │  FastAPI :5000       │                          │
│    │  CORS, StaticFiles   │                          │
│    └────────┬─────────────┘                          │
│             │                                        │
│  thread 2 (daemon): asyncio.run → run_forever()      │
│    ┌──────────────────────────────┐                  │
│    │  bot.py (sandbox)            │                  │
│    │  real_trader.py (real)       │                  │
│    │  AsyncClient → Tinkoff gRPC  │                  │
│    │  polling loop, stream,       │                  │
│    │  entry/exit logic            │                  │
│    └──────────────────────────────┘                  │
│             │                                        │
│  shared state: state = BotState() (threading.Lock)   │
└─────────────────────────────────────────────────────┘
```

### 1.2. Двухпоточная модель

| Поток | Роль | Event loop |
|-------|------|-----------|
| Main (thread 1) | FastAPI-сервер, REST API, SSE push | `asyncio.run(main())` в `server.py` |
| Bot (daemon thread 2) | Tinkoff gRPC, MarketDataStream, торговля | `asyncio.run(run_forever())` в `bot.py` или `real_trader.py` |

Бот-поток стартует как `threading.Thread(daemon=True)`. При завершении главного
процесса он умирает автоматически.

### 1.3. Выбор режима

`server.py --mode sandbox|real`:
- **sandbox** (по умолчанию): импортирует `bot.run_forever`, использует
  `INVEST_GRPC_API_SANDBOX`, токен `TINKOFF_SANDBOX_TOKEN`
- **real**: импортирует `real_trader.run_forever`, использует `INVEST_GRPC_API`,
  токен `TINKOFF_TOKEN`

Режим фиксируется в `state.mode` для отображения в дашборде.

### 1.4. Lifecycle бота

```
server.py start
  │
  ├── get_lifecycle_event().set()  ─── сигнал "можно работать"
  ├── bot_thread.start()
  │     └── asyncio.run(run_forever())
  │           └── main()
  │                 └── while True:
  │                       ├── событие .is_set()? → работаем
  │                       ├── .clear()? → break
  │                       └── итерация
  └── uvicorn.serve()

/api/bot/stop  →  get_lifecycle_event().clear()
                       │
                       └── main(): check → break → run_forever ждёт .set()

/api/bot/start  →  get_lifecycle_event().set()
                       │
                       └── run_forever: loop → main() заново

Крах бота  →  run_forever: except → sleep(1) → main() заново
```

Ключевые точки:
- `main()` имеет два выхода: `break` (остановка API) и `RuntimeError` (stream dead).
- `run_forever` ловит `break` от `main()` и переходит в ожидание `.set()`.
- `run_forever` ловит `RuntimeError` и делает полный restart `main()`.

### 1.5. Процесс загрузки

```
server.py
  │
  ├── parse args (--ticker, --mode)
  ├── import bot or real_trader
  ├── state.server_start_time = datetime.now()
  ├── get_lifecycle_event().set()
  ├── bot_thread = Thread(target=bot_runner, daemon=True)
  ├── bot_thread.start()
  └── uvicorn.Server(config).serve()

bot.py main():
  ├── load_stats_from_logs()
  ├── AsyncClient → resolve instrument (figi, uid, tick_size, ...)
  ├── resolve account_id
  ├── preload candles (PRELOAD_HOURS = 0 → с начала сессии через API trading_schedules, fallback 48h)
  ├── resume position (sandbox: get_portfolio → если есть открытая)
  ├── get_margin_attributes (sandbox: guarantee_for_futures = 0)
  ├── startup briefing
  ├── create stream_worker (MarketDataStream, CandleInstrument + InfoInstrument)
  ├── state.start_time = datetime.now()
  ├── while True:
  │     ├── ожидание .is_set()
  │     ├── polling loop (0.5s)
  │     ├── reconnect если stream мёртв
  │     ├── обработка свечи/статуса
  │     ├── compute_indicators → analyze_signal
  │     ├── exit logic (force_close → trailing → SL → TP)
  │     ├── entry logic
  │     ├── log_portfolio каждые 60s
  │     └── briefing trigger (Bollinger break / price move)
  └── worker.cancel(), stream.stop()
```

---

## 2. Межпоточное взаимодействие

### 2.1. `BotState` — общее состояние

Dataclass-синглтон в `shared.py`. Все поля потокобезопасны через `state_lock`
(threading.Lock) при записи ключевых полей (`record_trade`, `record_error`,
`to_dict`).

```python
@dataclass
class BotState:
    running: bool = False
    position: Position = field(default_factory=Position)
    daily_pnl: float = 0.0
    last_trade_time: Optional[datetime] = None
    last_trade_pnl: Optional[float] = None
    last_error: Optional[str] = None
    raw_candles: list = field(default_factory=list)
    start_time: Optional[datetime] = None
    server_start_time: Optional[datetime] = None
    trade_count: int = 0
    best_trade: float = 0.0
    win_count: int = 0
    loss_count: int = 0
    worst_trade: float = 0.0
    total_pnl: float = 0.0
    current_figi: str = ""
    force_close: bool = False
    manual_entry_side: str = ""
    portfolio_balance: float = 0.0
    portfolio_blocked: float = 0.0
    stream_connected: bool = True
    current_price: float = 0.0
    tick_size: float = 1.0
    tick_value: float = 1.0
    basic_asset_size: float = 0.0
    last_sl_time: Optional[datetime] = None
    mode: str = "sandbox"
    total_cash: float = 0.0
    available_cash: float = 0.0
    circuit_breaker: bool = False
    # Индикаторы (обновляются каждую итерацию бота)
    ind_ema, ind_ema_slow, ind_rsi, ind_adx, ...
```

### 2.2. Механизмы синхронизации

| Примитив | Тип | Назначение |
|----------|-----|-----------|
| `_bot_lifecycle` | `threading.Event` | Start/stop бота. API: `.set()` / `.clear()`. Бот: `.is_set()`. |
| `state_lock` | `threading.Lock` | Защита `BotState` при записи статистики и чтении для SSE. |
| `_operation_lock` | `threading.Lock` | Mutex API-операций (stop/start/close/open, non-blocking acquire). |
| `force_close` | `bool` на `state` | Сигнал API → бот: «закрой позицию». GIL-атомарное чтение/запись. |
| `manual_entry_side` | `str` на `state` | Сигнал API → бот: «открой LONG/SHORT». Read-and-clear. |

### 2.3. Сигналы API → Бот

#### `force_close: bool`
- **Запись**: `bot_api.py:298` — `/api/bot/close` → `state.force_close = True`
- **Сброс**: `bot.py` после успешного закрытия или ошибки → `state.force_close = False`
- **Чтение**: polling loop `bot.py:544` — одна из 4 причин выйти из ожидания
- **Guard**: `bot_api.py:296` — проверка `if state.force_close` (предотвращает дубликат)

#### `manual_entry_side: str`
- **Запись**: `bot_api.py:319` — `/api/bot/open` → `state.manual_entry_side = side`
- **Чтение + сброс**: `bot.py:803-804` — атомарно: `manual_side = state.manual_entry_side; state.manual_entry_side = ""`
- **Guard**: API проверяет `state.position.is_open()` — только если позиция закрыта

### 2.4. Операционный mutex

`_operation_lock = threading.Lock()` с non-blocking acquire. Используется в
`bot_api.py` для всех 4 endpoint'ов:

```python
def acquire_operation_lock() -> bool:
    return _operation_lock.acquire(blocking=False)

def release_operation_lock():
    _operation_lock.release()
```

Если операция уже выполняется, endpoint возвращает `{"ok": False, "message": "..."}`.
Это исключает race condition между быстрыми нажатиями кнопок в дашборде.

### 2.5. SSE push

`/api/events` — бесконечный StreamingResponse. Каждые 2 секунды сериализует
`state.to_dict()` и отправляет клиенту, если данные изменились.

Дашборд подключается к SSE при загрузке и обновляет UI на лету. До первого
ответа SSE используется `window.__INITIAL__` — инлайн-слепок состояния,
встроенный в HTML.

---

## 3. Rate Limiter и Retry

### 3.1. Token-bucket `RateLimiter`

```python
class RateLimiter:
    def __init__(self, max_calls: int, period: float = 60.0):
        self.max_calls = max_calls
        self.period = period
        self.tokens = float(max_calls)
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()
```

Алгоритм: при каждом `acquire()` вычисляется elapsed, добавляются токены
пропорционально прошедшему времени, при нехватке — `asyncio.sleep()` на
необходимое время.

### 3.2. Предустановленные лимитеры

| Лимитер | Лимит | Назначение |
|---------|-------|-----------|
| `orders_lim` | 500/мин | `PostOrder`, `post_order_with_retry` |
| `portfolio_lim` | 60/мин | `GetPortfolio`, `GetOrders` |
| `margin_lim` | 60/мин | `GetMarginAttributes` |
| `payin_lim` | 20/мин | `SandboxPayIn` |

### 3.3. `post_order_with_retry`

```python
async def post_order_with_retry(
    client, *, figi, uid, quantity, direction,
    account_id, order_type, price=None,
    max_retries=2, retry_delay=1.0,
):
```

Ключевые решения:
- **UUID idempotency**: `order_id = str(uuid.uuid4())` — единый на все попытки.
  Tinkoff гарантирует, что повторный вызов с тем же `order_id` не создаст дубликат.
- **2 retry attempts** (итого 3 попытки) с паузой 1 секунда.
- **`is_definitive()`**: ошибки 30034, 30079, 30042 прерывают retry немедленно.
- **`is_retryable()`**: сетевые ошибки (UNAVAILABLE, DEADLINE_EXCEEDED, CANCELLED,
  INTERNAL network error, UNKNOWN) — retry разрешён.
- **Лимитер срабатывает до каждого вызова**: `orders_lim.acquire()` внутри retry-цикла.

### 3.4. Классификация ошибок

| Код | Причина | Definitive | Действие |
|-----|---------|-----------|----------|
| 30034 | Not enough balance | Да | Нет retry. Sandbox: ложное «недостаточно средств». |
| 30079 | Instrument not available for trading | Да | Нет retry. Рынок закрыт. |
| 30042 | Instrument not found | Да | Нет retry. Неверный figi/uid. |
| Прочие AioRequestError | Зависит от code | Нет | Retry. |

---

## 4. Бот (sandbox — `bot.py`)

### 4.1. Инициализация

1. **Загрузка статистики из логов**: `load_stats_from_logs()` парсит
   `logs/trades_{дата}.log` по шаблону `P/L:\s*([+-]?[\d.]+)` и восстанавливает
   `state.total_pnl`, `state.trade_count` и т.д.
2. **Resolve instrument**: `client.instruments.future_by()`. Получает figi, uid,
   `min_price_increment` (tick_size), `min_price_increment_amount` (tick_value),
   `basic_asset_size`.
3. **Account ID**: приоритет: `ACCOUNT_ID` → `TINKOFF_SANDBOX_ACCOUNT_ID` →
   `TINKOFF_ACCOUNT_ID` → первый из `get_accounts()`.
4. **Preload candles**: 6 часов истории (1-min interval), последние 500 свечей в буфере.
5. **Resume position**: для sandbox: проверяет `get_portfolio()`, если есть
   позиция по figi — восстанавливает `position.side/lot/entry_price`.
6. **Get margin attributes**: для реального GO (sandbox: всегда 0).
7. **Применение тикерных переопределений**: `apply_ticker_overrides()`.
8. **Startup briefing**: однократный вызов `_briefing.main()`.

### 4.2. Polling-цикл (ядро)

Цикл ожидания `while True` с `asyncio.sleep(0.5)` проверяет 4 условия
(порядок важен):

```python
while True:
    if not candle_queue.empty():
        msg_type, msg = candle_queue.get_nowait()
        last_stream_msg = time.time()
        break                                   # свеча/статус/ping
    if state.force_close and market_open and position.side != 'NONE':
        msg_type = msg = None; break            # кнопка Close
    if state.manual_entry_side:
        msg_type = msg = None; break            # кнопка Long/Short
    if time.time() - last_stream_msg > 30 and worker.done() and not reconnecting:
        break                                   # мёртвый стрим → reconnect
    await asyncio.sleep(0.5)
```

**Почему polling вместо Event?** Четыре независимых условия (очередь, два булевых
флага от API, таймаут стрима) тяжело свести к одному `threading.Event` или
`asyncio.Event`. Booleans с GIL-атомарностью — простейшее корректное решение
для двух потоков.

### 4.3. Повторное подключение стрима

При обнаружении мёртвого стрима (worker.done() + 30с тишины):

1. `reconnecting = True` (блокирует повторный вход в reconnect)
2. Сохраняет состояние: `saved_prev_price`, `last_briefing_ts`, `last_portfolio_ts`, `last_candle_minute`
3. Останавливает старый стрим: `stream_ref.stop()`, `worker.cancel()`
4. Очищает очередь: `while not candle_queue.empty(): get_nowait()`
5. 3 попытки реконнекта с exponential backoff (1s / 3s / 10s):
   - `restart_stream()` → новый `stream_worker()`, `asyncio.wait_for(stream_open.wait(), timeout=30)`
   - `sync_candles(2)` — загружает последние 2 часа истории и мержит с локальными
   - Восстанавливает сохранённые переменные
6. Если все 3 попытки неудачны:
   - `state.stream_connected = False`
   - Ждёт 120 секунд
   - Счётчик `reconnect_count`: после 3 циклов (>6ч с первого фейла) → `RuntimeError`

### 4.4. Обработка свечи

Когда новый `HistoricCandle` приходит из стрима:

```python
if candles and candles[-1].time == c.time:
    candles[-1] = c              # обновление последней свечи
else:
    candles.append(c)            # новая минута
candles = candles[-500:]         # буфер
state.raw_candles = candles
```

Стрим подписан на `waiting_close()` — свеча приходит после закрытия минуты.

### 4.5. Обработка статуса торгов

`TradingStatus` из стрима определяет `market_open`:

```python
market_open = (
    ts.trading_status == SECURITY_TRADING_STATUS_NORMAL_TRADING
    or ts.market_order_available_flag
    or ts.limit_order_available_flag
)
```

Fallback (если нет статуса): `detect_market_from_candles()` — возраст последней
свечи ≤ 10 минут → рынок открыт.

Клиринг (14:00-14:03 МСК): trading_status уходит из NORMAL_TRADING → бот не входит.

### 4.6. Приоритет обработки входа/выхода

```
1. force_close?       → закрыть (без проверки сигнала)
2. trailing active?   → обновить peak, проверить триггер
3. SL?                → закрыть по стоп-лоссу
4. TP?                → закрыть по тейк-профиту
5. manual_entry_side? → прочитать, очистить, открыть
6. сигнал LONG/SHORT? → проверить фильтры, открыть
```

### 4.7. `close_balance_ok()` — sandbox pay-in перед BUY

Sandbox работает только с рублями. При закрытии SHORT-позиции нужен BUY-ордер,
для которого на счёте должно быть достаточно RUB. Если нет — sandbox возвращает
30034. `close_balance_ok()` делает `pay_in` перед BUY:

```python
async def close_balance_ok(close_dir, price, lot, label=""):
    if close_dir != ORDER_DIRECTION_BUY: return True   # SELL не требует RUB
    if not SANDBOX: return True                         # real — доверяем бирже
    needed = price * lot * basic_asset_size            # номинал
    amount = int(needed) + 100_000                     # + буфер
    await client.sandbox.sandbox_pay_in(...)            # бесплатно в песочнице
    # Обновляем portfolio_balance
    pf = await client.operations.get_portfolio(...)
    state.portfolio_balance = qfloat(pf.total_amount_currencies)
```

После pay-in проверка `get_portfolio` обновляет `state.portfolio_balance` для
расчёта лота при следующем входе.

### 4.8. Детекция рынка (входные фильтры)

Перед входом проверяется каскад фильтров:

```
1. signal != 'NEUTRAL'
2. market_open (trading_status + fallback)
3. now_msk.hour < TIME_FILTER_HOUR (19:00 MSK)
4. last_sl_time cooldown (MIN_BETWEEN_SL = 1800 сек)
5. get_margin_attributes: funds_sufficiency_level > 1.0
```

### 4.9. Run forever — crash recovery

```python
async def run_forever(ticker=None):
    while True:
        try:
            await main()
        except asyncio.CancelledError:
            break
        except RuntimeError:
            await asyncio.sleep(1)
            continue         # полный restart main()
        # main() completed normally (stop requested)
        while not get_lifecycle_event().is_set():
            await asyncio.sleep(0.5)  # ждём /api/bot/start
```

---

## 5. Real Trader (`real_trader.py`)

### 5.1. Отличия от sandbox

| Аспект | Sandbox (`bot.py`) | Real (`real_trader.py`) |
|--------|-------------------|------------------------|
| Токен | `TINKOFF_SANDBOX_TOKEN` | `TINKOFF_TOKEN` |
| gRPC target | `INVEST_GRPC_API_SANDBOX` | `INVEST_GRPC_API` |
| Pay-in | `close_balance_ok()` делает pay_in перед BUY | Доверяет бирже |
| Resume position | Только sandbox | Всегда (на случай перезапуска) |
| Margin/GO | `guarantee_for_futures = 0` | Реальные данные |
| RiskManager | Нет | `RiskManager`, `PortfolioManager`, `RealExecutor` |
| Polling | 4-условный polling (0.5s) | `asyncio.wait_for(queue.get(), timeout=30)` |
| Circuit breaker | Нет | При N убытков подряд или дневной просадке |

### 5.2. RealExecutor — размещение ордеров с верификацией

```python
async def market_order(self, direction, quantity) -> dict:
    resp = await post_order_with_retry(...)
    filled = resp.lots_executed or 0
    result["success"] = filled == quantity          # полное исполнение
    if resp.executed_order_price:
        result["fill_price"] = qfloat(resp.executed_order_price)
    if not result["success"]:
        result["error"] = f"Partial fill {filled}/{quantity}"
```

Возвращает `{"success", "order_id", "filled", "fill_price", "error"}`.
`do_close()` использует этот результат: если fill_price отличается от запрошенной
цены — сделка логируется с фактической ценой исполнения.

### 5.3. PortfolioManager — актуальный баланс

```python
async def refresh(self, client, account_id):
    margin = await client.users.get_margin_attributes(account_id)
    self.blocked = qfloat(margin.guarantee_for_futures)
    self.available_cash = qfloat(margin.liquid_portfolio)   # RUB - GO
    pf = await client.operations.get_portfolio(account_id)
    self.total_cash = qfloat(pf.total_amount_currencies)
```

`margin_ok()`: проверяет, что `available_cash >= price * lot * asset_size * (1 + MIN_CASH_BUFFER_PCT/100)`.

`can_close_short()`: для SHORT → BUY нужно `total_cash >= cost`.

### 5.4. RiskManager

```python
class RiskManager:
    consecutive_losses = 0
    daily_loss_hit = False
    circuit_breaker_until = 0.0
```

Триггеры:
- **MAX_CONSECUTIVE_LOSSES=2**: после 2 убыточных сделок подряд — circuit breaker
  на `CIRCUIT_BREAKER_COOLDOWN=3600с`.
- **MAX_DAILY_LOSS_PCT=3%**: если дневной PNL ≤ -3% от портфеля —
  `daily_loss_hit = True` до конца дня.
- **PRICE_DEVIATION_MAX_PCT=5%**: если цена отклонилась более чем на 5% от
  предыдущей — вход блокируется.

### 5.5. Stream reconnect (real_trader.py)

Использует `asyncio.wait_for(candle_queue.get(), timeout=30)` — оригинальный
подход (без polling). Reconnect при `asyncio.TimeoutError` + `worker.done()`:

```
TimeoutError → reconnect_count++
              reconnect_count > 3 за <120s → пауза 300s
              иначе restart_stream()
              после 3 неудач → RuntimeError → run_forever restart
```

---

## 6. API Layer (`bot_api.py`)

### 6.1. FastAPI приложение

```python
app = FastAPI(title="CCM6 Trading Bot API")
app.add_middleware(CORSMiddleware, allow_origins=[
    f"http://127.0.0.1:{SERVER_PORT}",
    f"http://localhost:{SERVER_PORT}",
])
```

CORS ограничен localhost. Static files монтируются в `server.py`, не в bot_api.

### 6.2. REST endpoints

| Endpoint | Method | Описание | Формат ответа |
|----------|--------|----------|-------------|
| `/` | GET | HTML dashboard с injected `__INITIAL__` | `text/html` |
| `/api/status` | GET | Полное состояние бота | `JSON: BotState.to_dict()` |
| `/api/portfolio` | GET | Последняя запись из `portfolio.jsonl` | `JSON` |
| `/api/trades` | GET | Сделки за дату | `JSON: [trade, ...]` |
| `/api/candles` | GET | Последние 200 свечей для графика | `JSON: [{time,open,high,low,close,volume}]` |
| `/api/stats` | GET | Статистика за дату | `JSON: {wins,losses,winrate,total_pnl,...}` |
| `/api/yesterday` | GET | Вчера: trades + stats + portfolio | `JSON` |
| `/api/logs` | GET | Последние N строк `bot.log` | `JSON: {lines}` |
| `/api/briefing` | GET | Текущий брифинг (сегодня) | `JSON: {briefing, ts, price, rsi, ...}` |
| `/api/briefing-history` | GET | Брифинг за дату `?date=YYYY-MM-DD` | `JSON: [entry]` |
| `/api/events` | GET | SSE push (state diffs) | `text/event-stream` |
| `/api/bot/stop` | POST | Остановить бота | `JSON: {ok, message}` |
| `/api/bot/start` | POST | Запустить бота | `JSON: {ok, message}` |
| `/api/bot/close` | POST | Принудительно закрыть позицию | `JSON: {ok, message}` |
| `/api/bot/open` | POST | Открыть позицию `?dir=long|short` | `JSON: {ok, message}` |

### 6.3. SSE — `/api/events`

```python
@app.get("/api/events")
async def events():
    async def generate():
        last_json = "{}"
        while True:
            current = json.dumps(state.to_dict())
            if current != last_json:
                last_json = current
                yield f"data: {current}\n\n"
            await asyncio.sleep(2)
    return StreamingResponse(generate(), media_type="text/event-stream")
```

Дашборд подключается через `new EventSource('/api/events')`, переподключается
автоматически при обрыве.

### 6.4. Чтение логов сделок

`parse_trades_log(date_str)` парсит `logs/trades_{DDMMYYYY}.log`:

Формат строки лога:
```
06.05.2026 22:08:46 | OPEN LONG | CCM6 | 1 контрактов @ 316.2000
06.05.2026 22:26:30 | CLOSE (SL) | CCM6 | 1 контрактов @ 316.9000 | P/L: +1.00 RUB
```

Парсинг: регексп `P/L:\s*([+-]?[\d.]+)` для PnL, `@\s*([\d.]+)` для цены,
тип закрытия из action (SL/TP/TRAIL).

`compute_stats(trades)`: winrate, total_pnl, avg_pnl, best/worst trade.

### 6.5. Конвертация свечей для TradingView

```python
def candles_to_chart(candles: list) -> list:
    # time → Unix seconds, open/high/low/close → float
    # volume → int
    # Фильтр: игнорируем свечи с ошибками парсинга
    result.append({
        "time": ts,
        "open": qfloat(_cget(c, "open")),
        "high": qfloat(_cget(c, "high")),
        "low": qfloat(_cget(c, "low")),
        "close": qfloat(_cget(c, "close")),
        "volume": _cget(c, "volume") or 0,
    })
```

### 6.6. `/api/yesterday` — для ночного дашборда

До 09:00 MSK дашборд показывает вчерашний день. `/api/yesterday` возвращает:
- `trades` — список сделок за вчера
- `stats` — статистика
- `portfolio` — последняя запись из `portfolio.jsonl`
- `is_yesterday: true`

Дашборд определяет час по `new Date().getUTCHours() + 3 < 9`.

---

## 7. Торговая стратегия

### 7.1. Индикаторы

Все индикаторы — расчёт на 1-минутных свечах из `raw_candles` (буфер 500 свечей).

| Индикатор | Параметры | Функция |
|-----------|-----------|---------|
| EMA fast | 9 периодов | `calc_ema(closes, 9)` |
| EMA slow | 21 период | `calc_ema(closes, 21)` |
| RSI | 14 периодов | `calc_rsi(closes, 14)` |
| ADX | 14 периодов | `calc_adx(highs, lows, closes, 14)` |
| Momentum | 6 периодов (≈30 мин) | `calc_momentum(closes, 6)` |
| Volume avg | 20 периодов | `calc_volume_avg(volumes, 20)` |
| Bollinger | 20 периодов, 2σ | `calc_bollinger(closes, 20, 2)` |
| Percentile | 5 дней (≈2625 баров) | `calc_percentile(closes, 95/5)` |

Реализации:
- **EMA**: `значение = close * k + prev_ema * (1 - k)`, где `k = 2 / (n + 1)`
- **RSI**: `100 - 100 / (1 + avg_gain / avg_loss)`, SMA сглаживание
- **ADX**: directional movement сглаживание по Wilder (14 периодов)
- **Momentum**: `(close / close[-n] - 1) * 100` (%)
- **Bollinger**: `rolling_mean ± 2 * rolling_std`
- **Percentile**: `sorted(closes)[int(len * percentile / 100)]`

### 7.2. Сигнал (`analyze_signal`)

```python
def analyze_signal(indicators) -> str:  # 'LONG' | 'SHORT' | 'NEUTRAL'
    trend_up = ema_fast > ema_slow

    vol_ok = (vol_avg > 0
              and vol >= vol_avg * VOLUME_MULTIPLIER
              and vol >= VOLUME_ABS_MIN)
    adx_ok = adx is None or adx >= ADX_MIN
    mom_ok = mom is None or abs(mom) >= MOMENTUM_MIN

    if trend_up and vol_ok and adx_ok and mom_ok
       and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD
       and (ph is None or price <= ph):
        return 'LONG'

    if not trend_up and vol_ok and adx_ok and mom_ok
       and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD
       and (pl is None or price >= pl):
        return 'SHORT'

    return 'NEUTRAL'
```

**Детали фильтров:**
- `RSI_OVERBOUGHT_FILTER = 55`: запрет LONG при RSI > 55 (даже если формально не перекуплен)
- `RSI_OVERSOLD = 30`: минимальный RSI для входа (для SHORT — RSI ≤ 70, но с фильтром 55)
- `VOLUME_MULTIPLIER = 1.2`: объём должен быть на 20% выше среднего
- `VOLUME_ABS_MIN = 60`: минимум 60 контрактов (защита от шума в пустом стакане)
- `ADX_MIN = 30`: средняя сила тренда (22 для CRM6)
- Percentile: LONG блокируется выше 100-го процентиля (фактически max за 5 дней)
- `MIN_SIGNAL_STREAK = 2`: сигнал должен держаться N свечей подряд до входа

### 7.3. Signal streak (N-свечное подтверждение)

Трекается на сыром сигнале (до time filter):

```python
if signal == prev_signal and signal != 'NEUTRAL':
    signal_streak += 1
elif signal != 'NEUTRAL':
    signal_streak = 1
else:
    signal_streak = 0
prev_signal = signal
```

После всех фильтров: `if signal != 'NEUTRAL' and signal_streak < MIN_SIGNAL_STREAK: signal = 'NEUTRAL'`

Порядок фильтрации: `analyze_signal → streak tracking → time filter → streak filter → SL cooldown → margin check → entry`. Стреак-фильтр устраняет flicker SHORT→NEUTRAL на смежных свечах.

### 7.4. Функция PnL

```python
def calc_pnl(side, entry, price, lot, tick_size, tick_value) -> float:
    diff = price - entry if side == 'LONG' else entry - price
    ticks = diff / tick_size
    return round(ticks * tick_value * lot, 2)
```

**Точность**: PnL считается в тиках (не в рублях напрямую). `tick_value` — стоимость
одного тика в рублях. Комиссия вычитается отдельно.

```python
def calc_commission(price, basic_asset_size, lot, comm_pct) -> float:
    return price * basic_asset_size * (comm_pct / 100) * lot
```

Комиссия считается как процент от нотариала сделки (price × asset_size × lot),
списывается дважды (при открытии и при закрытии).

### 7.5. Выход из позиции

**Stop-Loss** (`STOP_LOSS_PCT = 1.2%` для CCM6):
```
pnl_pct = pnl_pct_for(side, entry, price)
if pnl_pct <= -STOP_LOSS_PCT: → market sell/buy
```

**Take-Profit** (`TAKE_PROFIT_PCT = 1.5%` для CCM6):
```
if pnl_pct >= TAKE_PROFIT_PCT: → market sell/buy
```

**Trailing Stop**:
```
Активация: pnl_pct >= TRAILING_ACTIVATE (0.8%)
После активации:
  LONG: peak = max(peak, price); trail = peak * (1 - 0.4%)
  SHORT: peak = min(peak, price); trail = peak * (1 + 0.4%)
  Триггер: price <= trail (LONG) или price >= trail (SHORT)
```

Приоритет выхода: **force_close → trailing → SL → TP**.
Trailing проверяется первым после force_close, что даёт ему приоритет над SL.
Если trailing активен и цена движется ниже trail_level — срабатывает trailing,
а не SL (trailing level обычно выше SL level).

### 7.5. Per-ticker overrides

`configbot.py:TICKER_PARAMS` — словарь, ключ по имени тикера:

| Параметр | CCM6 | CRM6 |
|----------|------|------|
| ADX_MIN | 30 | 20 |
| STOP_LOSS_PCT | 1.2% | 0.4% |
| TAKE_PROFIT_PCT | 1.5% | 0.6% |
| TRAILING_ACTIVATE | 0.8% | 0.4% |
| TRAILING_DISTANCE | 0.4% | 0.15% |
| VOLUME_MULTIPLIER | 1.2 | 1.1 |
| COMMISSION_PCT | 0.01320% | 0.00462% |
| MOMENTUM_MIN | 0.005% | (default) |
| VOLUME_ABS_MIN | 60 | (default) |

Применяются через `apply_ticker_overrides()` в начале `main()`:
```python
for k, v in TICKER_PARAMS.get(TICKER, {}).items():
    if k in globals(): globals()[k] = v
```

### 7.6. Временные фильтры

- **TIME_FILTER_HOUR = 19**: запрет входа после 19:00 МСК
- **MIN_BETWEEN_SL = 1800с (30 мин)**: пауза после SL перед следующим входом
- **Клиринг**: 14:00-14:03 МСК — trading_status уходит из NORMAL_TRADING
- **Briefing cooldown**: 300с (5 мин) между генерациями брифинга

---

## 8. Sandbox-specific логика

### 8.1. Особенности песочницы Tinkoff

- **Pay-in бесплатный и безлимитный**: можно пополнять сколько угодно
- **`guarantee_for_futures = 0`**: песочница не возвращает ГО для фьючерсов
- **30034 «Not enough balance»**: может приходить даже при достаточном балансе —
  песочница не учитывает позицию как обеспечение
- **`api_trade_available_flag` отсутствует**: в `TradingStatus` нет этого поля,
  используется `market_order_available_flag || limit_order_available_flag`
- **Resume**: песочница хранит позиции между перезапусками, `get_portfolio`
  показывает открытые позиции на момент старта

### 8.2. Pay-in перед BUY (SHORT close)

При закрытии SHORT-позиции в sandbox:
1. Нужен BUY-ордер → на счёте должно быть достаточно RUB
2. `close_balance_ok()`: вычисляет `needed = price * lot * basic_asset_size`
3. Делает `sandbox_pay_in` на `needed + 100_000` (буфер)
4. Обновляет `state.portfolio_balance` через `get_portfolio`

Для SELL-ордеров (LONG close) pay-in не требуется.

### 8.3. Расчёт лота при manual entry

Когда нет позиции и нет `position.lot`:

```python
order_lot = max(1, int(
    state.portfolio_balance * 0.5 /
    (price * state.basic_asset_size)
))
```

50% свободного баланса на один контракт. Если `basic_asset_size = 0` — fallback 10 лотов.

### 8.4. AUTO_PAYIN

Если `AUTO_PAYIN` установлен в числовое значение (RUB), при старте бот делает
однократный `sandbox_pay_in` на эту сумму.

---

## 9. Dashboard (`templates/index.html`)

### 9.1. Технологии

- **График**: TradingView [Lightweight Charts](https://github.com/tradingview/lightweight-charts) v4
- **SSE**: нативный `EventSource` с авто-переподключением
- **Стили**: чистый CSS (86 строк, `static/style.css`)
- **Шрифт**: system-ui, `-apple-system`, `Segoe UI`

### 9.2. Структура панелей

```
┌────────────────────────────────────────────┐
│ HEADER: Status badge | Start | Stop | Reload│
├──────────────────────┬─────────────────────┤
│ CHART (full width)   │                     │
│ [TradingView OHLC]   │                     │
│ [Volume histogram]   │                     │
├──────────────────────┤                     │
│ INDICATORS (full)    │                     │
│ EMA RSI ADX MOM VOL  │                     │
├──────────┬───────────┤                     │
│ POSITION │ PORTFOLIO │                     │
│ Long/    │ Баланс    │                     │
│ Short    │ Блок/Дост │                     │
│ Close    │ P/L день  │                     │
├──────────┤ Сделок    │                     │
│ TRADES   │ Винрейт   │                     │
│ (таблица)│           │                     │
├──────────┴───────────┤                     │
│ BRIEFING             │                     │
│ RSI bar, уровни,     │                     │
│ рекомендация         │                     │
└────────────────────────────────────────────┘
```

### 9.3. Инициализация

При загрузке страницы:
1. `window.__INITIAL__` — инлайн JSON с `state.to_dict()` (встроен в HTML сервером)
2. `window.__TICKER__` — имя тикера
3. Первичный рендер из `__INITIAL__` (мгновенный, без запроса)
4. `loadAll()` → `loadStatus()` (REST) + `loadCandles()` + `loadTrades()` + `loadBriefing()`
5. После загрузки → подключение SSE для real-time обновлений
6. `setInterval(15000)` для периодической загрузки свечей, сделок, брифинга

### 9.4. SSE real-time

```javascript
function connectSSE() {
    es = new EventSource('/api/events');
    es.onmessage = (e) => updateUI(JSON.parse(e.data));
    es.onerror = () => { es.close(); setTimeout(connectSSE, 5000); };
}
```

`updateUI()`: обновляет все DOM-элементы:
- Бейдж статуса (RUNNING/STOPPED, зелёный/красный с пульсацией)
- Позиция (сторона, вход, текущая, PnL, цветовое кодирование)
- Индикаторы (EMA, RSI, ADX, Momentum, Volume mult)
- Портфель (баланс, заблокировано, доступно, PnL день, сделки, винрейт, эквити с open PnL)
- RSI fill bar (зелёный < 30, синий 30-70, красный > 70)

### 9.5. График

Lightweight Charts:
- Candlestick series: зелёный/красный, кастомный `priceFormat` с `priceDecimals` от `tick_size`
- Volume histogram series: привязан к шкале 'volume' (scaleMargins top 0.8)
- Crosshair: при наведении показывает цену, изменение %, время
- MSK clock: обновляется каждую секунду в правом верхнем углу

### 9.6. Yesterday mode

До 09:00 MSK дашборд показывает вчерашний день (система не переключалась на
новый день торгов). Отличия:
- Статус: «ВЧЕРА DD.MM.YYYY» вместо RUNNING/STOPPED
- Все индикаторы скрыты
- Позиция: NONE
- Портфель: вчерашняя статистика из `/api/yesterday`
- Брифинг: читаем вчерашний briefing через `/api/briefing-history`

### 9.7. API actions (кнопки)

```javascript
function apiAction(url, method, extra) {
    // anti-spam: _apiBusy + cooldown 1000ms
    // блокировка кнопок на время запроса
    fetch(url, { method, body })
    .then(r => r.json())
    .then(d => {
        showError(d.message);  // всплывающий баннер
        loadAll();             // полная перезагрузка
    });
}
```

Все кнопки Start/Stop/Close/Long/Short вызывают `apiAction()`.
Ошибки показываются в красном `#error-banner` и исчезают через 4-5 секунд.

---

## 10. Briefing (`briefing.py`)

### 10.1. gRPC (через SDK)

Брифинг использует `AsyncClient` (gRPC SDK) для получения свечей и инструментов.
Может принимать опциональный параметр `client: AsyncClient` от `bot.py` для
переиспользования соединения, либо создавать своё (standalone, `run_briefing.py`).

```python
async def main(client: Optional['AsyncClient'] = None):
    owned_client = client is None
    if owned_client:
        client = AsyncClient(token, target=..., app_name="Briefing")
    try:
        async with client if owned_client else nullcontext():
            instr = await client.instruments.future_by(...)
            figi = instr.instrument.figi
            async for c in client.get_all_candles(figi=figi, ...):
                closes.append(c.close)
    finally:
        if not owned_client:
            pass  # caller owns cleanup
```

`nullcontext` — no-op async context manager для случая, когда клиент передан извне.
Aiohttp остался только для `get_bot_status()` (HTTP-запрос к `/api/status` бота).

### 10.2. Триггеры генерации

- **Startup**: однократно при запуске бота
- **Bollinger break**: цена ≤ BB_lower × 1.002 или цена ≥ BB_upper × 0.998
- **Price move**: изменение цены > 1.2% от предыдущей свечи
- **Cooldown**: 300 секунд между генерациями (BRIEFING_COOLDOWN)

### 10.3. Анализ (шаблонный, без LLM)

```python
RSI > 70 → "перекуплен"
RSI < 30 → "перепродан"
иначе    → "нейтральная зона"

MACD > 0 → "бычий" / < 0 → "медвежий"

BB: цена ниже нижней → "сильный сигнал на покупку"
    цена выше верхней → "сильный сигнал на продажу"
```

Key levels: Bollinger bands (support = lower, resistance = upper, pivot = middle).

### 10.4. Формат вывода

Одиночный файл `briefings/briefing_{YYYY-MM-DD}.json`, атомарная запись:
```python
data = {
    "ts": datetime.now().isoformat(),
    "ticker": TICKER,
    "price": price,
    "rsi": rsi,
    "position": position.side,
    "balance": portfolio_balance,
    "analysis": {
        "sentiment": "bullish|bearish|neutral",
        "summary": "...",
        "key_levels": { "support": ..., "resistance": ..., "pivot": ... },
        "signals": ["..."],
        "warnings": ["..."],
    },
}
# Атомарная запись:
tmp = path.with_suffix(".tmp")
tmp.write_text(json.dumps(data))
tmp.replace(path)
```

### 10.5. API для брифинга

- `/api/briefing` → читает `briefing_{today}.json`, возвращает поля анализа
- `/api/briefing-history?date=YYYY-MM-DD` → читает `briefing_{date}.json`, возвращает `[entry]`

---

## 11. Бэктест (`backtest.py`)

### 11.1. Загрузка данных

- Загружает `DAYS` (по умолчанию 7) истории через gRPC SDK
- Кэширует свечи в `history/{ticker}_{interval}_{from}_{to}.json` (Cache-first)
- Поддерживает `--interval 1|2` (1min/5min) — настраиваемый интервал
- Пробует несколько тикеров через `TICKER_FALLBACKS` при ошибке resolve

### 11.2. Расчёт позиции на bar'ах OHLC (high/low-based)

В отличие от live-бота (close-to-close), бэктест использует low/high для exit:
```
LONG: SL = low ≤ entry * (1 - SL%), TP = high ≥ entry * (1 + TP%)
SHORT: SL = high ≥ entry * (1 + SL%), TP = low ≤ entry * (1 - TP%)
Trailing: для LONG — peak = max(peak, high), триггер = low ≤ trail
```

Порядок exit внутри бара: SL → TRAIL → TP (приоритет стопов).

### 11.3. Комиссия

```python
com = calc_commission(entry, asset_size, LOT, COMMISSION_PCT)
    + calc_commission(exit_price, asset_size, LOT, COMMISSION_PCT)
```

Списывается при открытии и закрытии.

### 11.4. Вывод статистики

```
BACKTEST RESULTS — CCM6 | 7 days | 1 contract
══════════════════════════════════════════════════════════
  Period:      2026-05-19 to 2026-05-26
  Candles:     10080 (1)
  Trades:      47
  ────────────────────────────────────────────────
  Wins:        22 / Losses: 25
  WinRate:     46.8%
  Profit Fact: 1.35
  Total P/L:   +4725.00 RUB
  Avg Win:     +350.00 RUB
  Avg Loss:    -175.00 RUB
  Best:        +1200.00 RUB
  Worst:       -800.00 RUB
  Max Consec W:4 / L:5
  Sharpe (ann):0.85
  ────────────────────────────────────────────────
  Start:       40000.00 RUB
  End:         44725.00 RUB
  Return:      +11.81%
  Max DD:      3200.00 RUB (8.0%)
```

Также: per-day breakdown, таблица всех сделок, JSON экспорт в
`backtest/backtest_result_{ticker}_{timestamp}.json`.

### 11.5. Используемые модули

Импортирует из `bot.py`: `calc_ema`, `calc_rsi`, `calc_adx`, `calc_momentum`,
`calc_volume_avg`, `calc_pnl`. Из `shared.py`: `qfloat`.

---

## 12. Конфигурация и развертывание

### 12.1. `.env`

```
TINKOFF_SANDBOX_TOKEN=...
TINKOFF_TOKEN=...
TINKOFF_ACCOUNT_ID=...
TINKOFF_SANDBOX_ACCOUNT_ID=...
BOT_TICKER=CCM6
```

Загружается `dotenv` в начале каждого модуля. Приоритет: переменные окружения
переопределяют .env.

### 12.2. `configbot.py` — структура параметров

| Раздел | Ключи |
|--------|-------|
| Режим | `SANDBOX`, `AUTO_PAYIN`, `ACCOUNT_ID` |
| Debug | `DEBUG` |
| Инструмент | `TICKER` |
| Стратегия | `EMA_FAST`, `EMA_SLOW`, `RSI_PERIOD`, `RSI_OVERBOUGHT`, `RSI_OVERSOLD`, `VOLUME_MULTIPLIER`, `MOMENTUM_PERIOD` |
| Фильтры | `MOMENTUM_MIN`, `VOLUME_ABS_MIN`, `ADX_MIN`, `MIN_BETWEEN_SL`, `RSI_OVERBOUGHT_FILTER` |
| Per-ticker | `TICKER_PARAMS` (словарь) |
| Percentile | `PERCENTILE_DAYS`, `PERCENTILE_FILTER` |
| Risk | `RISK_PERCENT`, `STOP_LOSS_PCT`, `TAKE_PROFIT_PCT` |
| Trailing | `TRAILING_ACTIVATE`, `TRAILING_DISTANCE` |
| Сервер | `SERVER_PORT` |
| Время | `TIME_FILTER_HOUR`, `PRELOAD_HOURS` (0 = от начала сессии) |
| Real-only | `MAX_DAILY_LOSS_PCT`, `MAX_CONSECUTIVE_LOSSES`, `PRICE_DEVIATION_MAX_PCT`, `MIN_CASH_BUFFER_PCT`, `CIRCUIT_BREAKER_COOLDOWN` |

### 12.3. Быстрый старт

```bash
# Sandbox (песочница)
python server.py --ticker CCM6

# Real (реальный счёт)
python server.py --ticker CCM6 --mode real

# Бот без дашборда
python bot.py --ticker CCM6

# Бэктест
python backtest.py --ticker CCM6 --days 14

# Брифинг
python run_briefing.py --ticker CCM6

# Termux
bash termux_start.sh tmux
```

### 12.4. Termux (Android)

`termux_start.sh`:
- `install`: установка tmux, rust, protobuf, pip-пакетов
- `tmux`: запуск через tmux — не умирает при закрытии Termux
- Wake lock: автоматический захват и отпускание
- Дашборд: `http://localhost:5000/` в браузере Android
- Battery optimization: отключить для Termux

### 12.5. Зависимости

```bash
pip install fastapi uvicorn aiohttp python-dotenv
pip install t-tech-investments --index-url \
  https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple
```

`requirements.txt` отсутствует — зависимости устанавливаются вручную.

---

## 13. Обработка ошибок и логирование

### 13.1. Centralised error logging

```python
# bot.py main():
try:
    # ... main loop ...
except asyncio.CancelledError:
    break
except Exception as e:
    traceback.print_exc()
    state.record_error(str(e))
    if isinstance(e, RuntimeError):
        raise  # stream dead → full restart
    await asyncio.sleep(5)
```

`state.record_error()` записывает последнюю ошибку под `state_lock` — отображается
в дашборде.

### 13.2. Форматы логов

**Сделки** — `logs/trades_{DDMMYYYY}.log`:
```
06.05.2026 22:08:46 | OPEN LONG | CCM6 | 1 контрактов @ 316.2000
06.05.2026 22:26:30 | CLOSE (SL) | CCM6 | 1 контрактов @ 316.9000 | P/L: +1.00 RUB
```

**Портфель** — `logs/portfolio.jsonl` (JSONL, одна строка = 1 запись):
```json
{"ts":"2026-05-06T22:26:30","balance":40000.00,"blocked":3169.00,
 "side":"LONG","entry_price":316.2000,"lot":10,"price":316.9000,
 "daily_pnl":1.00,"total_pnl":1.00}
```

### 13.3. Восстановление статистики при старте

`load_stats_from_logs()` парсит все `logs/trades_*.log` и восстанавливает:
```python
{ "total_pnl": ..., "trade_count": ..., "win_count": ..., "loss_count": ...,
  "best_trade": ..., "worst_trade": ...,
  "daily_pnl": ... }  # только за сегодня
```

Регексп: `P/L:\s*([+-]?[\d.]+)` → суммирует, считает winrate и экстремумы.

### 13.4. Crash recovery

```
run_forever: main() → RuntimeError → sleep(1) → main() [sandbox]
run_forever: main() → ошибка → sleep(1) → sleep(2) → ... ×2 → max 60s [real]
```

В sandbox `delay` фиксирован (1s). В real — exponential backoff (1, 2, 4, ... 60).

### 13.5. Dead stream detection

- **bot.py** (sandbox): `time.time() - last_stream_msg > 30` + `worker.done()`
- **real_trader.py**: `asyncio.TimeoutError` (30s) + `worker.done()`

Reconnect: до 3 попыток подряд. После 3 неудач → 120s пауза (sandbox) или 300s (real).

---

## 14. Хелперы (`shared.py`)

### `qfloat(v) -> float`

Универсальный конвертер Tinkoff Quotation/MoneyValue в float:

```python
def qfloat(v) -> float:
    if v is None: return 0.0
    if isinstance(v, (int, float)): return float(v)
    if hasattr(v, 'units') and hasattr(v, 'nano'):
        return int(v.units or 0) + int(v.nano or 0) / 1_000_000_000
    if isinstance(v, dict):
        return int(v.get("units", 0) or 0) + int(v.get("nano", 0) or 0) / 1_000_000_000
    return 0.0
```

Поддерживает: `None`, `int/float`, gRPC dataclass (`{units, nano}`), REST JSON (`{units, nano}`).

### `log_trade(action, figi, ticker, quantity, price, pnl=None)`

Логирование сделки с атомарной записью в `logs/trades_{date}.log`.

---

## 15. Известные ограничения

### 15.1. Tinkoff API

- **30034 Not enough balance**: песочница возвращает ошибку даже при достаточном
  балансе. Root cause: `guarantee_for_futures` всегда 0, система не видит ГО.
- **`api_trade_available_flag`** отсутствует в `TradingStatus` — fallback через
  `market_order_available_flag || limit_order_available_flag`.
- **Futures margin**: песочница не рассчитывает ГО для фьючерсов.
- **SDK**: gRPC SDK `t-tech-investments` с открытого registry Tinkoff.

### 15.2. Кодовые

- **Нет тестов**, линтера, typecheck — вся codebase Python 3.10+ без статической типизации
- **Нет `requirements.txt`** — зависимости ставятся вручную
- **Нет git**: `.git` директория есть, но git.exe недоступен — бэкапы через
  `Copy-Item` вручную
- **No persistence**: при перезапуске вся статистика восстанавливается из логов
  (парсинг текстовых файлов)

### 15.3. Стратегия

- **Нет backtest tab** в дашборде
- **Нет лога свечей**: при перезапуске история свечей загружается за текущую
  сессию (через `trading_schedules` API при `PRELOAD_HOURS=0`, fallback 48h)
