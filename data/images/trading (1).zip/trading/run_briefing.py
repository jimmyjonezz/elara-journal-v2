#!/usr/bin/env python3
"""Точка входа брифинга — загружает env, запускает briefing.main().
   Можно также напрямую: python -c "import asyncio; from briefing import main; asyncio.run(main())"
"""
import os, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from dotenv import load_dotenv
load_dotenv(Path(__file__).parent / ".env")

from briefing import main
import asyncio
asyncio.run(main())
