"""server.py — сервер + бот (sandbox/real)."""
import asyncio
import os
import threading
import sys
import argparse
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

parser = argparse.ArgumentParser()
parser.add_argument("--ticker", default=None, help="Instrument ticker (default: CCM6)")
parser.add_argument("--mode", default="sandbox", choices=["sandbox", "real"],
                    help="sandbox (bot.py) or real (real_trader.py)")
_args = parser.parse_args()
if _args.ticker:
    os.environ["BOT_TICKER"] = _args.ticker

from configbot import SERVER_PORT

async def main():
    from shared import state, get_lifecycle_event
    import uvicorn
    from fastapi.staticfiles import StaticFiles
    from bot_api import app as api_app

    if _args.mode == "real":
        from real_trader import run_forever as run_bot
        state.mode = "real"
    else:
        from bot import run_forever as run_bot

    static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    if os.path.isdir(static_path):
        api_app.mount("/static", StaticFiles(directory=static_path, html=True), name="static")

    state.server_start_time = datetime.now()
    get_lifecycle_event().set()

    def bot_runner():
        asyncio.run(run_bot())

    bot_thread = threading.Thread(target=bot_runner, daemon=True)
    bot_thread.start()

    config = uvicorn.Config(
        api_app,
        host="127.0.0.1",
        port=SERVER_PORT,
        log_level="error",
        lifespan="off",
    )
    server = uvicorn.Server(config)
    await server.serve()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    finally:
        from shared import state, get_lifecycle_event
        get_lifecycle_event().clear()
        state.running = False
