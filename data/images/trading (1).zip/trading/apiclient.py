"""
apiclient.py — Rate limiter + PostOrder with retry для Tinkoff API.

Использование:
  from apiclient import post_order_with_retry, orders_lim
  resp = await post_order_with_retry(client, figi=..., uid=..., ...)
"""
import asyncio, time, uuid
from grpc import StatusCode
from t_tech.invest.exceptions import AioRequestError


# ── Rate Limiter (token bucket) ────────────────────────────────

class RateLimiter:
    """Token-bucket rate limiter. acquire() blocks until a token is available."""
    def __init__(self, max_calls: int, period: float = 60.0):
        self.max_calls = max_calls
        self.period = period
        self.tokens = float(max_calls)
        self.last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self):
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_refill
            self.tokens = min(self.max_calls, self.tokens + elapsed * self.max_calls / self.period)
            self.last_refill = now
            if self.tokens < 1.0:
                wait = (1.0 - self.tokens) * self.period / self.max_calls
                await asyncio.sleep(wait)
                self.tokens = 0.0
            else:
                self.tokens -= 1.0


# ── Predefined limiters ────────────────────────────────────────

orders_lim    = RateLimiter(500, 60)   # PostOrder — 500/мин (документированный лимит)
portfolio_lim = RateLimiter(60,  60)   # GetOrders, GetPortfolio
margin_lim    = RateLimiter(60,  60)   # GetMarginAttributes


# ── Error classification ───────────────────────────────────────

def is_definitive(e: Exception) -> bool:
    """Ошибки, которые бесполезно ретраить: неверный баланс, рынок закрыт и т.п."""
    if not isinstance(e, AioRequestError):
        return False
    d = e.details.lower() if e.details else ""
    if "30079" in d or "not available for trading" in d:
        return True
    if "30042" in d or "instrument not found" in d:
        return True
    return False


def is_retryable(e: Exception) -> bool:
    """Сетевые ошибки, после которых имеет смысл повторить запрос."""
    if not isinstance(e, AioRequestError):
        return True
    if e.code in (StatusCode.UNAVAILABLE, StatusCode.DEADLINE_EXCEEDED, StatusCode.CANCELLED):
        return True
    d = e.details.lower() if e.details else ""
    if e.code == StatusCode.INTERNAL and "internal network error" in d:
        return True
    if e.code == StatusCode.UNKNOWN:
        return True
    return False


# ── PostOrder with retry ───────────────────────────────────────

async def post_order_with_retry(
    client,
    *,
    figi: str,
    uid: str,
    quantity: int,
    direction,
    account_id: str,
    order_type,
    price=None,
    max_retries: int = 2,
    retry_delay: float = 1.0,
    sandbox: bool = False,
):
    """
    PostOrder с автоматическим ретраем при сетевых ошибках.

    Использует один и тот же order_id (UUID) на все попытки —
    Tinkoff гарантирует идемпотентность: повторный вызов с тем же order_id
    вернёт статус уже созданной заявки без дублирования.

    Не ретраит при определённых ошибках (30079, 30042).
    sandbox=True → использует client.sandbox.post_sandbox_order (песочница T-Invest).
    """
    order_id = str(uuid.uuid4())
    last_error = None
    post = client.sandbox.post_sandbox_order if sandbox else client.orders.post_order

    for attempt in range(max_retries + 1):
        try:
            await orders_lim.acquire()
            return await post(
                figi=figi, quantity=quantity, direction=direction,
                account_id=account_id, order_type=order_type,
                price=price, order_id=order_id, instrument_id=uid,
            )
        except Exception as e:
            last_error = e
            if attempt >= max_retries:
                break
            if is_definitive(e):
                break
            await asyncio.sleep(retry_delay)

    raise last_error
