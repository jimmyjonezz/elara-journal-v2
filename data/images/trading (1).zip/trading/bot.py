"""
Фьючерсный моментум-бот (gRPC через SDK t-tech-investments)
"""
import sys
import os
import re
import json
import asyncio
from datetime import datetime, timezone, timedelta
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
sys.stdout.reconfigure(encoding='utf-8')

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

from configbot import (
    SANDBOX, ACCOUNT_ID, TICKER, DEBUG,
    EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    VOLUME_MULTIPLIER, MOMENTUM_PERIOD,
    RISK_PERCENT, STOP_LOSS_PCT, TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE, TRAILING_DISTANCE, TIME_FILTER_HOUR, PRELOAD_HOURS,
    MOMENTUM_MIN, VOLUME_ABS_MIN, ADX_MIN, MIN_BETWEEN_SL,
    MIN_SIGNAL_STREAK, MIN_COOLDOWN_SEC, RSI_OVERBOUGHT_FILTER, SERVER_PORT,
    PERCENTILE_DAYS, PERCENTILE_FILTER,
)
from shared import state, Position, get_lifecycle_event, qfloat, log_trade, get_session_start, MAX_RECONNECT_WINDOW
from apiclient import post_order_with_retry, orders_lim, portfolio_lim, margin_lim

COMMISSION_PCT = 0


async def close_via_sandbox_or_retry(client, figi, uid, quantity, direction, account_id, order_type, price=0, basic_asset_size=0):
    """Close with sandbox_pay_in before SHORT-close (BUY) in sandbox, then post_order_with_retry."""
    if SANDBOX and direction == OrderDirection.ORDER_DIRECTION_BUY:
        extra = round(price * quantity * basic_asset_size * 1.1)
        if extra > 0:
            try:
                await client.sandbox.sandbox_pay_in(
                    account_id=account_id,
                    amount=MoneyValue(currency="rub", units=extra, nano=0),
                )
                print(f"  >> Sandbox pay-in {extra} RUB for SHORT close", flush=True)
                await asyncio.sleep(1)
            except Exception as e:
                print(f"  >> Sandbox pay-in error: {e}", flush=True)
    await post_order_with_retry(
        client, figi=figi, uid=uid, quantity=quantity,
        direction=direction, account_id=account_id,
        order_type=order_type, sandbox=SANDBOX,
    )


def apply_ticker_overrides():
    """Применить TICKER_PARAMS из configbot к глобалам этого модуля."""
    import configbot as _cb
    for _k, _v in _cb.TICKER_PARAMS.get(_cb.TICKER, {}).items():
        if _k in globals():
            globals()[_k] = _v

from t_tech.invest import (
    AsyncClient, CandleInstrument, InfoInstrument, SubscriptionInterval,
    OrderDirection, OrderType, MarketDataResponse, MoneyValue,
    SecurityTradingStatus,
)
from t_tech.invest.constants import INVEST_GRPC_API, INVEST_GRPC_API_SANDBOX

import briefing as _briefing
BRIEFING_COOLDOWN = 300

# ── helpers ───────────────────────────────────────────────────

def cell_mk(c):
    return (qfloat(c.open), qfloat(c.high), qfloat(c.low), qfloat(c.close))

def price_to_float(m) -> float:
    return qfloat(m)

SDK_TARGET = INVEST_GRPC_API_SANDBOX if SANDBOX else INVEST_GRPC_API

# ── log dir ───────────────────────────────────────────────────

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

def load_stats_from_logs() -> dict:
    today_prefix = datetime.now().strftime("%d%m%Y")
    total_c = total_w = total_l = 0
    total_p = 0.0
    daily_p = 0.0
    if not os.path.isdir(LOG_DIR):
        return {"trade_count": 0, "win_count": 0, "loss_count": 0,
                "daily_pnl": 0.0, "total_pnl": 0.0, "winrate": 0.0}
    for fname in sorted(os.listdir(LOG_DIR)):
        if not (fname.startswith("trades_") and fname.endswith(".log")):
            continue
        is_today = fname == f"trades_{today_prefix}.log"
        with open(os.path.join(LOG_DIR, fname), encoding="utf-8") as f:
            for line in f:
                m = re.search(r'P/L:\s*([+-]?[\d.]+)', line)
                if not m:
                    continue
                v = float(m.group(1))
                total_p += v
                total_c += 1
                total_w += v > 0
                total_l += v < 0
                if is_today:
                    daily_p += v
    wr = round(total_w / total_c * 100, 1) if total_c else 0.0
    return {"trade_count": total_c, "win_count": total_w, "loss_count": total_l,
            "total_pnl": round(total_p, 2), "daily_pnl": round(daily_p, 2), "winrate": wr}

def log_portfolio():
    """Записать состояние портфеля в JSONL (одна строка = JSON)."""
    try:
        now = datetime.now()
        entry = {
            "ts": now.strftime("%Y-%m-%dT%H:%M:%S"),
            "balance": round(state.portfolio_balance, 2),
            "blocked": round(state.portfolio_blocked, 2),
            "side": state.position.side,
            "entry_price": round(state.position.entry_price, 4) if state.position.entry_price else 0,
            "lot": state.position.lot,
            "price": round(state.current_price, 4),
            "daily_pnl": round(state.daily_pnl, 2),
            "total_pnl": round(state.total_pnl, 2),
        }
        p = Path(LOG_DIR) / "portfolio.jsonl"
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        print(f"log_portfolio error: {e}")

# ── indicators (pure math, unchanged) ────────────────────────

def calc_ema(values, period):
    if len(values) < period:
        return None
    k = 2.0 / (period + 1)
    ema = sum(values[:period]) / period
    for v in values[period:]:
        ema = v * k + ema * (1 - k)
    return ema

def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [d if d > 0 else 0 for d in deltas]
    losses = [-d if d < 0 else 0 for d in deltas]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100.0 - (100.0 / (1.0 + avg_gain / avg_loss))

def calc_adx(highs, lows, closes, period=14):
    if len(closes) < period * 2 + 1:
        return None
    trs, plus_dms, minus_dms = [], [], []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], highs[i] - closes[i - 1], closes[i - 1] - lows[i])
        plus = highs[i] - highs[i - 1]
        minus = lows[i - 1] - lows[i]
        trs.append(tr)
        plus_dms.append(plus if plus > minus and plus > 0 else 0)
        minus_dms.append(minus if minus > plus and minus > 0 else 0)

    def smooth(data, p):
        s = sum(data[:p]) / p
        result = [s]
        for i in range(p, len(data)):
            s = (s * (p - 1) + data[i]) / p
            result.append(s)
        return result

    tr_s, plus_s, minus_s = smooth(trs, period), smooth(plus_dms, period), smooth(minus_dms, period)
    plus_di = [100 * p / t if t > 0 else 0 for p, t in zip(plus_s, tr_s)]
    minus_di = [100 * m / t if t > 0 else 0 for m, t in zip(minus_s, tr_s)]
    dx = [abs(plus_di[i] - minus_di[i]) / (plus_di[i] + minus_di[i]) * 100
          if (plus_di[i] + minus_di[i]) > 0 else 0 for i in range(len(plus_di))]
    if len(dx) < period:
        return None
    adx = sum(dx[:period]) / period
    for i in range(period, len(dx)):
        adx = (adx * (period - 1) + dx[i]) / period
    return adx

def calc_momentum(closes, period=10):
    if len(closes) < period + 1:
        return None
    prev = closes[-period - 1]
    if prev == 0:
        return None
    return (closes[-1] - prev) / prev * 100

def calc_volume_avg(volumes, period=20):
    if not volumes:
        return 0
    return sum(volumes[-min(period, len(volumes)):]) / min(period, len(volumes))

def calc_bollinger(closes, period=20, mult=2.0):
    if len(closes) < period:
        return None, None, None
    import statistics
    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - mult * std, mean, mean + mult * std

def calc_percentile(values, percentile):
    if not values:
        return None
    s = sorted(values)
    idx = int(len(s) * percentile / 100)
    idx = max(0, min(idx, len(s) - 1))
    return s[idx]

def compute_indicators(candles: list) -> dict:
    clusters = [[qfloat(c.close) for c in candles],
                [qfloat(c.high) for c in candles],
                [qfloat(c.low) for c in candles],
                [c.volume for c in candles]]
    closes, highs, lows, volumes = clusters
    result = {
        'close': closes[-1] if closes else 0,
        'volume': volumes[-1] if volumes else 0,
        'ema_fast': None, 'ema_slow': None,
        'rsi': None, 'adx': None, 'momentum': None, 'vol_avg': None,
        'bb_lower': None, 'bb_mid': None, 'bb_upper': None,
    }
    if len(closes) >= EMA_FAST:
        result['ema_fast'] = calc_ema(closes, EMA_FAST)
    if len(closes) >= EMA_SLOW:
        result['ema_slow'] = calc_ema(closes, EMA_SLOW)
    if len(closes) >= RSI_PERIOD + 1:
        result['rsi'] = calc_rsi(closes, RSI_PERIOD)
    if len(closes) >= EMA_SLOW * 2 + 1:
        result['adx'] = calc_adx(highs, lows, closes, 14)
    if len(closes) >= MOMENTUM_PERIOD + 1:
        result['momentum'] = calc_momentum(closes, MOMENTUM_PERIOD)
    if volumes:
        result['vol_avg'] = calc_volume_avg(volumes, 20)
    bb_l, bb_m, bb_u = calc_bollinger(closes)
    result['bb_lower'] = bb_l
    result['bb_mid'] = bb_m
    result['bb_upper'] = bb_u
    n = min(len(closes), PERCENTILE_DAYS * 525, 500)
    if len(closes) >= 100:
        subset = closes[-n:]
        result['percentile_high'] = calc_percentile(subset, PERCENTILE_FILTER)
        result['percentile_low'] = calc_percentile(subset, 100 - PERCENTILE_FILTER)
    return result

def analyze_signal(indicators: dict) -> str:
    ef = indicators.get('ema_fast')
    es = indicators.get('ema_slow')
    rsi = indicators.get('rsi')
    adx = indicators.get('adx')
    mom = indicators.get('momentum')
    va = indicators.get('vol_avg')
    vol = indicators.get('volume', 0)
    if None in (ef, es, rsi):
        return 'NEUTRAL'
    trend_up = ef > es
    vol_ok = (va and va > 0 and vol >= va * VOLUME_MULTIPLIER and vol >= VOLUME_ABS_MIN)
    adx_ok = adx is None or adx >= ADX_MIN
    mom_ok = mom is None or abs(mom) >= MOMENTUM_MIN
    ph = indicators.get('percentile_high')
    pl = indicators.get('percentile_low')
    price = indicators.get('close', 0)
    if trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD \
       and (ph is None or price <= ph):
        return 'LONG'
    if not trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER and rsi >= RSI_OVERSOLD \
       and (pl is None or price >= pl):
        return 'SHORT'
    return 'NEUTRAL'

def pnl_pct_for(side, entry, cur) -> float:
    if entry <= 0:
        return 0.0
    return ((cur - entry) / entry * 100) if side == 'LONG' else ((entry - cur) / entry * 100)

def calc_commission(price, basic_asset_size, lot, comm_pct) -> float:
    return price * basic_asset_size * (comm_pct / 100) * lot

def calc_pnl(side, entry, price, lot, tick_size=1.0, tick_value=1.0) -> float:
    if entry <= 0 or tick_size <= 0:
        return 0.0
    diff = price - entry if side == 'LONG' else entry - price
    ticks = diff / tick_size
    return round(ticks * tick_value * lot, 2)

# ── market detection via API ─────────────────────────────────

def detect_market_from_candles(candles) -> bool:
    """Если возраст последней свечи ≤ 10 мин — рынок активен."""
    if not candles:
        return False
    last = candles[-1]
    age = (datetime.now(timezone.utc) - last.time).total_seconds()
    return age <= 600

# ── main ──────────────────────────────────────────────────────

async def main():
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    if state.running:
        print("[BOT] Already running.")
        return

    token = SANDBOX_TOKEN = os.getenv("TINKOFF_SANDBOX_TOKEN")
    if not token:
        token = os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: no token in .env")
        return

    print(f"[BOT] Start {TICKER} | SANDBOX={SANDBOX} | SDK gRPC", flush=True)

    state.raw_candles = []
    stats = load_stats_from_logs()
    for k, v in stats.items():
        setattr(state, k, v)
    print(f"[BOT] Logs: {state.trade_count} trades, P/L={state.total_pnl:+.2f}", flush=True)

    state.last_error = None

    async with AsyncClient(token, target=SDK_TARGET, app_name=f"{TICKER}Bot") as client:
        # Resolve instrument
        instr = await client.instruments.future_by(
            id_type=2, class_code="SPBFUT", id=TICKER
        )
        figi = instr.instrument.figi
        uid = instr.instrument.uid
        state.tick_size = qfloat(instr.instrument.min_price_increment)
        state.tick_value = qfloat(instr.instrument.min_price_increment_amount)
        state.basic_asset_size = qfloat(instr.instrument.basic_asset_size)
        print(f"[BOT] {TICKER} → FIGI={figi} UID={uid} tick={state.tick_size}/{state.tick_value} asset_size={state.basic_asset_size}", flush=True)
        state.current_figi = figi

        # Apply ticker-specific param overrides
        import configbot as _cfg
        _overrides = _cfg.TICKER_PARAMS.get(TICKER, {})
        if _overrides:
            for _k, _v in _overrides.items():
                if _k in globals():
                    globals()[_k] = _v
            print(f"[BOT] Applied {len(_overrides)} overrides for {TICKER}: {_overrides}", flush=True)

        # Account
        aid = ACCOUNT_ID or os.getenv("TINKOFF_SANDBOX_ACCOUNT_ID") or os.getenv("TINKOFF_ACCOUNT_ID") or ""
        if not aid:
            accs = await client.users.get_accounts()
            if accs.accounts:
                aid = accs.accounts[0].id
        if not aid:
            print("ERROR: no account ID")
            return
        client._account_id = aid
        print(f"[BOT] Account: {aid}", flush=True)

        # Log sandbox balance (auto pay-in removed, account set up manually)
        if SANDBOX:
            try:
                pf = await client.operations.get_portfolio(account_id=aid)
                bal = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())
                state.portfolio_balance = bal
                print(f"[BOT] Sandbox balance: {bal:.0f} RUB", flush=True)
            except Exception as e:
                print(f"[BOT] Sandbox portfolio check: {e}", flush=True)

        # Preload candles
        now_utc = datetime.now(timezone.utc)
        if PRELOAD_HOURS > 0:
            from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
            print(f"[BOT] Loading {PRELOAD_HOURS}h history...", flush=True)
        else:
            session_start = await get_session_start(client, TICKER)
            if session_start is None:
                from_utc = now_utc - timedelta(hours=48)
                print(f"[BOT] Session start not found, fallback 48h", flush=True)
            else:
                from_utc = session_start - timedelta(minutes=1)
                print(f"[BOT] Loading from session start {session_start} UTC", flush=True)
        candles = []
        async for c in client.get_all_candles(
            figi=figi, from_=from_utc, to=now_utc, interval=1
        ):
            candles.append(c)

        if not candles and PRELOAD_HOURS == 0:
            print("[BOT] No candles from session start, fallback to 48h", flush=True)
            from_utc = now_utc - timedelta(hours=48)
            candles = []
            async for c in client.get_all_candles(
                figi=figi, from_=from_utc, to=now_utc, interval=1
            ):
                candles.append(c)

        if not candles:
            print("ERROR: no candle data", flush=True)
            return

        print(f"[BOT] Loaded {len(candles)} candles, last={candles[-1].time}", flush=True)
        state.raw_candles = candles

        # Resume position (sandbox)
        position = Position()
        position.lot = 0
        if SANDBOX:
            try:
                pf = await client.operations.get_portfolio(account_id=aid)
                for p in pf.positions:
                    if p.figi == figi and qfloat(p.quantity) != 0:
                        qty = int(abs(qfloat(p.quantity)))
                        ep = qfloat(p.average_position_price) if p.average_position_price else 0
                        position.side = 'LONG' if qfloat(p.quantity) > 0 else 'SHORT'
                        position.lot = qty
                        position.entry_price = ep
                        position.peak_price = ep
                        position.entry_time = datetime.now(timezone.utc)
                        print(f"[RESUME] {position.side} {qty} @ {ep:.4f}", flush=True)
                        break
                bal = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())
                state.portfolio_balance = bal
            except Exception as e:
                print(f"[RESUME] portfolio error: {e}", flush=True)
        # Real GO for current position
        try:
            margin = await client.users.get_margin_attributes(account_id=aid)
            state.portfolio_blocked = qfloat(margin.guarantee_for_futures) if qfloat(margin.guarantee_for_futures) > 0 else 0.0
        except Exception as e:
            pass

        state.position.side = position.side
        state.position.entry_price = position.entry_price
        state.position.lot = position.lot
        state.position.peak_price = position.peak_price
        state.force_close = False

        # Print config
        print(f"\n{'='*50}", flush=True)
        print(f"BOT READY | {TICKER} | {'SANDBOX' if SANDBOX else 'PROD'}", flush=True)
        print(f"EMA:{EMA_FAST}/{EMA_SLOW} RSI:{RSI_PERIOD} ADX>={ADX_MIN}", flush=True)
        if position.side != 'NONE':
            print(f"Position: {position.side} @ {position.entry_price:.4f}", flush=True)
        print(f"{'='*50}\n", flush=True)

        # ── Startup briefing ──
        try:
            print("[BOT] Generating startup briefing...", flush=True)
            await _briefing.main()
            print("[BOT] Startup briefing done.", flush=True)
        except Exception as e:
            print(f"[BOT] Briefing start error: {e}", flush=True)

        # ── Market data stream setup ──
        candle_queue = asyncio.Queue(maxsize=100)
        stream_open = asyncio.Event()
        stream_error = None
        stream_ref = None

        # Reconnect state
        reconnecting = False
        reconnect_count = 0
        first_fail_time = 0.0
        state.stream_connected = True

        async def stream_worker():
            """Background: consume market data stream → push to queue."""
            nonlocal stream_error, stream_ref
            try:
                stream = client.create_market_data_stream()
                stream_ref = stream
                stream.candles.waiting_close().subscribe([
                    CandleInstrument(figi=figi, interval=SubscriptionInterval.SUBSCRIPTION_INTERVAL_ONE_MINUTE)
                ])
                stream.info.subscribe([InfoInstrument(figi=figi)])
                stream_open.set()

                async for md in stream:
                    if md.candle:
                        await candle_queue.put(('candle', md.candle))
                    if md.trading_status:
                        await candle_queue.put(('status', md.trading_status))
                    if md.ping:
                        await candle_queue.put(('ping', time.time()))
            except Exception as e:
                stream_error = e
                stream_open.set()

        async def restart_stream():
            """Create new stream worker, wait for ready, raise on error."""
            nonlocal stream_error, stream_ref, worker, stream_open
            stream_open.clear()
            stream_error = None
            stream_ref = None
            worker = asyncio.create_task(stream_worker())
            await asyncio.wait_for(stream_open.wait(), timeout=30)
            if stream_error:
                raise stream_error

        async def sync_candles(fallback_hours=2):
            """Fetch recent history and merge with local candles to fill gaps."""
            now_utc = datetime.now(timezone.utc)
            from_utc = now_utc - timedelta(hours=fallback_hours)
            fresh = []
            try:
                async for c in client.get_all_candles(figi=figi, from_=from_utc, to=now_utc, interval=1):
                    fresh.append(c)
            except Exception as e:
                print(f"[BOT] Sync candles error: {e}", flush=True)
                return None
            seen = {c.time for c in fresh}
            merged = [c for c in candles if c.time not in seen] + fresh
            merged.sort(key=lambda c: c.time)
            return merged[-500:]

        worker = asyncio.create_task(stream_worker())
        await stream_open.wait()

        if stream_error:
            print(f"[BOT] Stream error: {stream_error}", flush=True)

        # ── Main lifecycle loop ──
        last_candle_minute = None
        market_open = detect_market_from_candles(candles)
        prev_price = qfloat(candles[-1].close) if candles else 0
        last_briefing_ts = time.time()
        last_portfolio_ts = time.time()
        last_stream_msg = time.time()
        prev_signal = ''
        signal_streak = 0

        state.start_time = datetime.now()
        force_close_retries = 0

        while True:
            # Если бот остановлен API — выйти из main() для clean restart
            if not get_lifecycle_event().is_set() and state.start_time:
                break
            while not get_lifecycle_event().is_set():
                await asyncio.sleep(0.5)
            state.running = True

            try:
                # ── Wait for event (polling 0.5s, instant response to buttons) ──
                while True:
                    if not candle_queue.empty():
                        msg_type, msg = candle_queue.get_nowait()
                        last_stream_msg = time.time()
                        break
                    if state.force_close and market_open and position.side != 'NONE':
                        msg_type = msg = None; break
                    if state.manual_entry_side:
                        msg_type = msg = None; break
                    if time.time() - last_stream_msg > 30 and worker.done() and not reconnecting:
                        break  # dead stream, fall through to reconnect
                    await asyncio.sleep(0.5)

                # ── Reconnect on dead stream ──
                if worker.done() and not reconnecting:
                    reconnecting = True
                    state.stream_connected = False
                    saved_prev_price = prev_price
                    saved_briefing_ts = last_briefing_ts
                    saved_portfolio_ts = last_portfolio_ts
                    saved_candle_minute = last_candle_minute
                    saved_prev_signal = prev_signal
                    saved_signal_streak = signal_streak
                    if stream_ref:
                        try: stream_ref.stop()
                        except: pass
                    worker.cancel()
                    try: await worker
                    except: pass
                    while not candle_queue.empty():
                        try: candle_queue.get_nowait()
                        except asyncio.QueueEmpty: break
                    attempt = 0
                    while attempt < 3:
                        attempt += 1
                        try:
                            await asyncio.wait_for(restart_stream(), timeout=30)
                            merged = await sync_candles(2)
                            if merged:
                                candles = merged
                                state.raw_candles = merged
                            state.stream_connected = True
                            reconnect_count = 0
                            last_stream_msg = time.time()
                            prev_price = saved_prev_price
                            last_briefing_ts = saved_briefing_ts
                            last_portfolio_ts = saved_portfolio_ts
                            last_candle_minute = saved_candle_minute
                            prev_signal = saved_prev_signal
                            signal_streak = saved_signal_streak
                            market_open = detect_market_from_candles(candles)
                            print(f"[BOT] Reconnected, {len(candles)} candles", flush=True)
                            break
                        except Exception as e:
                            print(f"[BOT] Reconnect {attempt}/3: {e}", flush=True)
                            if attempt < 3:
                                await asyncio.sleep([1, 3, 10][attempt - 1])
                    else:
                        state.stream_connected = False
                        reconnect_count += 1
                        first_fail_time = time.time()
                        print(f"[BOT] Reconnect failed, waiting 120s...", flush=True)
                        await asyncio.sleep(120)
                        if reconnect_count >= 3 and time.time() - first_fail_time > MAX_RECONNECT_WINDOW:
                            raise RuntimeError("Stream dead for too long")
                    reconnecting = False
                    market_open = detect_market_from_candles(candles)
                    continue

                now_utc = datetime.now(timezone.utc)
                now_msk = now_utc + timedelta(hours=3)

                # ── Process candle from stream ──
                if msg_type == 'candle':
                    c = msg
                    if candles and candles[-1].time == c.time:
                        candles[-1] = c
                    else:
                        candles.append(c)
                    if len(candles) > 500:
                        candles = candles[-500:]
                    state.raw_candles = candles
                    last_candle_minute = c.time.minute

                # ── Process trading status ──
                if msg_type == 'status':
                    ts = msg
                    market_open = (
                        ts.trading_status == SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING
                        or ts.market_order_available_flag
                        or ts.limit_order_available_flag
                    )


                # ── Compute indicators ──
                price = qfloat(candles[-1].close) if candles else 0
                state.current_price = price
                indicators = compute_indicators(candles)
                state.ind_ema = indicators.get('ema_fast') or 0.0
                state.ind_ema_slow = indicators.get('ema_slow') or 0.0
                state.ind_rsi = indicators.get('rsi') or 0.0
                state.ind_adx = indicators.get('adx') or 0.0
                state.ind_momentum = indicators.get('momentum') or 0.0
                if indicators.get('vol_avg'):
                    state.ind_volume_mult = round(
                        indicators['volume'] / indicators['vol_avg'], 2
                    )
                state.ind_percentile_high = indicators.get('percentile_high') or 0.0
                state.ind_percentile_low = indicators.get('percentile_low') or 0.0
                signal = analyze_signal(indicators)

                if DEBUG and msg_type == 'candle':
                    print(
                        f"[{now_msk.strftime('%H:%M')}] "
                        f"p={price:.4f} EMA={indicators['ema_fast'] or 0:.4f}/{indicators['ema_slow'] or 0:.4f} "
                        f"RSI={indicators['rsi'] or 0:.1f} ADX={indicators['adx'] or 0:.1f} "
                        f"MOM={indicators['momentum'] or 0:+.4f}% V={indicators['volume']:>4}/{indicators['vol_avg'] or 0:>4.0f} "
                        f">>> {signal} | pos={position.side} | streak={signal_streak}/{MIN_SIGNAL_STREAK} | market={'OPEN' if market_open else 'CLOSED'}"
                    )

                if signal != 'NEUTRAL' and now_msk.hour >= TIME_FILTER_HOUR:
                    signal = 'NEUTRAL'

                if signal != 'NEUTRAL' and signal_streak < MIN_SIGNAL_STREAK:
                    signal = 'NEUTRAL'

                # ── Close logic ──
                if state.force_close and market_open:
                    close_dir = OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
                    print(f"[FORCE_CLOSE] {position.side} qty={position.lot} dir={'SELL' if close_dir == OrderDirection.ORDER_DIRECTION_SELL else 'BUY'} @ {price:.4f}", flush=True)
                    try:
                        await close_via_sandbox_or_retry(
                            client, figi=figi, uid=uid, quantity=position.lot,
                            direction=close_dir, account_id=aid,
                            order_type=OrderType.ORDER_TYPE_MARKET,
                            price=price, basic_asset_size=state.basic_asset_size,
                        )
                        com = calc_commission(position.entry_price, state.basic_asset_size, position.lot, COMMISSION_PCT) + calc_commission(price, state.basic_asset_size, position.lot, COMMISSION_PCT)
                        pnl = calc_pnl(position.side, position.entry_price, price, position.lot, state.tick_size, state.tick_value) - com
                        log_trade("CLOSE (MANUAL)", figi, TICKER, position.lot, price, pnl)
                        print(f"  >> CLOSE (MANUAL) @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                        state.record_trade(pnl)
                        state.last_exit_time = now_utc
                        state.force_close = False
                        force_close_retries = 0
                        position.side = 'NONE'
                        position.entry_price = 0.0
                        position.peak_price = 0.0
                        position.trailing_active = False
                        position.entry_time = None
                        position.lot = 0
                        state.position.side = 'NONE'
                        state.portfolio_blocked = 0.0
                    except Exception as e:
                        print(f"  >> Force close error: {e}", flush=True)
                        state.record_error(str(e))
                        force_close_retries += 1
                        if force_close_retries >= 3:
                            state.force_close = False
                            force_close_retries = 0

                elif position.side != 'NONE' and market_open:
                    pp = pnl_pct_for(position.side, position.entry_price, price)

                    # Trailing activation
                    if pp >= TRAILING_ACTIVATE and not position.trailing_active:
                        position.trailing_active = True
                        position.peak_price = price
                        state.position.trailing_active = True
                        if DEBUG:
                            print(f"  >> TRAIL ACTIVE @ {price:.4f} (+{pp:.2f}%)", flush=True)

                    # Trailing close
                    if position.trailing_active:
                        is_long = position.side == 'LONG'
                        if is_long:
                            if price > position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 - TRAILING_DISTANCE / 100)
                            triggered = price <= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_SELL
                        else:
                            if price < position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 + TRAILING_DISTANCE / 100)
                            triggered = price >= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_BUY

                        if triggered:
                            try:
                                await close_via_sandbox_or_retry(
                                    client, figi=figi, uid=uid, quantity=position.lot,
                                    direction=close_dir, account_id=aid,
                                    order_type=OrderType.ORDER_TYPE_MARKET,
                                    price=price, basic_asset_size=state.basic_asset_size,
                                )
                                com = calc_commission(position.entry_price, state.basic_asset_size, position.lot, COMMISSION_PCT) + calc_commission(price, state.basic_asset_size, position.lot, COMMISSION_PCT)
                                pnl = calc_pnl(position.side, position.entry_price, price, position.lot, state.tick_size, state.tick_value) - com
                                log_trade(f"CLOSE (TRAIL @ {trail_level:.4f})", figi, TICKER, position.lot, price, pnl)
                                print(f"  >> TRAIL CLOSE @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                                state.record_trade(pnl)
                                state.last_exit_time = now_utc
                                position.reset()
                                state.portfolio_blocked = 0.0
                            except Exception as e:
                                print(f"  >> Trailing close error: {e}", flush=True)
                                state.record_error(str(e))

                    # Stop-Loss
                    if position.side != 'NONE' and pp <= -STOP_LOSS_PCT:
                        close_dir = OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
                        notional_est = price * position.lot * state.basic_asset_size
                        print(f"  >> SL attempt: qty={position.lot} @ {price:.4f} (notion~{notional_est:.0f})", flush=True)
                        try:
                            await close_via_sandbox_or_retry(
                                client, figi=figi, uid=uid, quantity=position.lot,
                                direction=close_dir, account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                                price=price, basic_asset_size=state.basic_asset_size,
                            )
                            com = calc_commission(position.entry_price, state.basic_asset_size, position.lot, COMMISSION_PCT) + calc_commission(price, state.basic_asset_size, position.lot, COMMISSION_PCT)
                            pnl = calc_pnl(position.side, position.entry_price, price, position.lot, state.tick_size, state.tick_value) - com
                            log_trade("CLOSE (SL)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> SL @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            state.record_trade(pnl)
                            state.last_exit_time = now_utc
                            state.last_sl_time = now_utc
                            position.reset()
                            state.portfolio_blocked = 0.0
                        except Exception as e:
                            print(f"  >> SL error: {e}", flush=True)
                            state.record_error(str(e))

                    # Take-Profit
                    if position.side != 'NONE' and pp >= TAKE_PROFIT_PCT:
                        close_dir = OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
                        try:
                            await close_via_sandbox_or_retry(
                                client, figi=figi, uid=uid, quantity=position.lot,
                                direction=close_dir, account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                                price=price, basic_asset_size=state.basic_asset_size,
                            )
                            com = calc_commission(position.entry_price, state.basic_asset_size, position.lot, COMMISSION_PCT) + calc_commission(price, state.basic_asset_size, position.lot, COMMISSION_PCT)
                            pnl = calc_pnl(position.side, position.entry_price, price, position.lot, state.tick_size, state.tick_value) - com
                            log_trade("CLOSE (TP)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> TP @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            state.record_trade(pnl)
                            state.last_exit_time = now_utc
                            position.reset()
                            state.portfolio_blocked = 0.0
                        except Exception as e:
                            print(f"  >> TP error: {e}", flush=True)
                            state.record_error(str(e))

                    state.position.side = position.side
                    state.position.entry_price = position.entry_price
                    state.position.peak_price = position.peak_price
                    state.position.trailing_active = position.trailing_active
                    state.position.lot = position.lot

                # ── Open logic ──
                manual_side = state.manual_entry_side
                state.manual_entry_side = ""
                if manual_side:
                    signal = manual_side

                if position.side == 'NONE' and signal != 'NEUTRAL' and market_open:
                    # Cooldown checks
                    if state.last_sl_time and (now_utc - state.last_sl_time).total_seconds() < MIN_BETWEEN_SL:
                        signal = 'NEUTRAL'
                    if state.last_exit_time and (now_utc - state.last_exit_time).total_seconds() < MIN_COOLDOWN_SEC:
                        signal = 'NEUTRAL'
                    # Check margin sufficiency before entry
                    margin_ok = True
                    try:
                        await margin_lim.acquire()
                        margin = await client.users.get_margin_attributes(account_id=aid)
                        if qfloat(margin.funds_sufficiency_level) <= 1.0:
                            print(f"  >> Insufficient margin, skip entry", flush=True)
                            margin_ok = False
                    except Exception as e:
                        print(f"  >> Margin check warning: {e}", flush=True)
                    if margin_ok:
                        try:
                            if state.basic_asset_size > 0:
                                order_lot = max(1, int(state.portfolio_balance * 0.5 / (price * state.basic_asset_size)))
                            else:
                                order_lot = 10
                            direction = OrderDirection.ORDER_DIRECTION_BUY if signal == 'LONG' else OrderDirection.ORDER_DIRECTION_SELL
                            await post_order_with_retry(
                                client, figi=figi, uid=uid, quantity=order_lot,
                                direction=direction, account_id=aid,
                                order_type=OrderType.ORDER_TYPE_MARKET,
                                sandbox=SANDBOX,
                            )
                            position.side = signal
                            position.entry_price = price
                            position.entry_bar = len(candles)
                            position.lot = order_lot
                            position.entry_time = now_utc
                            position.peak_price = price
                            position.trailing_active = False
                            log_trade(f"{'[MANUAL] ' if manual_side else ''}OPEN {signal}", figi, TICKER, order_lot, price)
                            state.position.side = signal
                            state.position.entry_price = price
                            state.position.entry_bar = len(candles)
                            state.position.entry_time = now_utc
                            state.position.peak_price = price
                            state.position.lot = order_lot
                            try:
                                await margin_lim.acquire()
                                margin = await client.users.get_margin_attributes(account_id=aid)
                                state.portfolio_blocked = qfloat(margin.guarantee_for_futures) if qfloat(margin.guarantee_for_futures) > 0 else round(price * order_lot * state.basic_asset_size, 2)
                            except Exception as e:
                                state.portfolio_blocked = round(price * order_lot * state.basic_asset_size, 2) if SANDBOX else 0.0
                            print(f"  >> OPEN {signal} @ {price:.4f}", flush=True)
                        except Exception as e:
                            print(f"  >> Open error: {e}", flush=True)
                            state.record_error(str(e))

                # Clear stale errors
                if state.last_error and 'Cannot connect' in str(state.last_error):
                    state.last_error = None

                # Portfolio log every 60s (only when in position)
                if time.time() - last_portfolio_ts > 60 and state.position.side != 'NONE':
                    log_portfolio()
                    last_portfolio_ts = time.time()

            except asyncio.CancelledError:
                print("\nBot cancelled.", flush=True)
                break
            except Exception as e:
                import traceback
                print(f"[BOT] Error: {e}", flush=True)
                traceback.print_exc()
                state.record_error(str(e))
                if isinstance(e, RuntimeError):
                    raise  # stream dead too long → full restart via run_forever
                await asyncio.sleep(5)

        worker.cancel()
        if stream_ref:
            stream_ref.stop()
        print("[BOT] Stopped.", flush=True)





async def run_forever(ticker=None):
    """Запускает main() в бесконечном цикле с авто-перезапуском при сбоях."""
    if ticker:
        import configbot
        configbot.TICKER = ticker
        os.environ["BOT_TICKER"] = ticker
    import traceback
    while True:
        try:
            await main()
        except asyncio.CancelledError:
            break
        except Exception as e:
            print(f"[BOT] CRASH: {e}", flush=True)
            traceback.print_exc()
            delay = 1
            print(f"[BOT] Restart in {delay}s...", flush=True)
            await asyncio.sleep(delay)
            continue
        # main() вернулась (stop) — ждём /api/bot/start
        while not get_lifecycle_event().is_set():
            await asyncio.sleep(0.5)


if __name__ == "__main__":
    import argparse
    _parser = argparse.ArgumentParser()
    _parser.add_argument("--ticker", default=None, help="Instrument ticker")
    _args = _parser.parse_args()
    asyncio.run(run_forever(ticker=_args.ticker))
