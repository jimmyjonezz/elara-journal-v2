"""shared.py — общее состояние бота, доступное из API и из бота."""
import threading
from dataclasses import dataclass, field

# Event для lifecycle бота: Stop=clear, Start=set
_bot_lifecycle = threading.Event()

def get_lifecycle_event():
    return _bot_lifecycle
from datetime import datetime
from typing import Optional


@dataclass
class Position:
    """Текущая торговая позиция."""
    side: str = 'NONE'              # NONE / LONG / SHORT
    entry_price: float = 0.0
    lot: int = 10
    entry_bar: int = 0
    entry_time: Optional[datetime] = None
    peak_price: float = 0.0
    trailing_active: bool = False

    def is_open(self) -> bool:
        return self.side != 'NONE'


@dataclass
class BotState:
    """Глобальное состояние, разделяемое между ботом и API."""
    running: bool = False           # бот работает
    position: Position = field(default_factory=Position)
    daily_pnl: float = 0.0         # P/L за сегодня, RUB
    last_trade_time: Optional[datetime] = None
    last_trade_pnl: Optional[float] = None
    last_error: Optional[str] = None
    raw_candles: list = field(default_factory=list)  # последние свечи
    start_time: Optional[datetime] = None
    server_start_time: Optional[datetime] = None     # время старта сервера
    trade_count: int = 0
    best_trade: float = 0.0
    win_count: int = 0
    loss_count: int = 0
    worst_trade: float = 0.0
    total_pnl: float = 0.0      # все сделки из логов
    current_figi: str = ""
    force_close: bool = False         # сигнал принудительного закрытия
    manual_entry_side: str = ""       # MANUAL_LONG / MANUAL_SHORT — принудительный вход
    portfolio_balance: float = 0.0    # баланс RUB
    portfolio_blocked: float = 0.0    # заблокировано под ГО
    # Текущие индикаторы (обновляются каждую итерацию)
    ind_ema: float = 0.0
    ind_ema_slow: float = 0.0
    ind_rsi: float = 0.0
    ind_adx: float = 0.0
    ind_momentum: float = 0.0
    ind_volume_mult: float = 0.0  # объём / avg_volume

    def record_trade(self, pnl: float):
        """Записать закрытую сделку в статистику."""
        self.last_trade_pnl = pnl
        self.last_trade_time = datetime.now()
        self.trade_count += 1
        if pnl > 0:
            self.win_count += 1
        else:
            self.loss_count += 1
        if self.trade_count == 1:
            self.best_trade = pnl
            self.worst_trade = pnl
        else:
            if pnl > self.best_trade:
                self.best_trade = pnl
            if pnl < self.worst_trade:
                self.worst_trade = pnl
        self.daily_pnl += pnl
        self.last_error = None

    def record_error(self, error: str):
        self.last_error = error

    def to_dict(self) -> dict:
        return {
            "running": self.running,
            "position": {
                "side": self.position.side,
                "entry_price": self.position.entry_price,
                "lot": self.position.lot,
                "entry_bar": self.position.entry_bar,
                "entry_time": (
                    self.position.entry_time.isoformat()
                    if self.position.entry_time else None
                ),
                "peak_price": self.position.peak_price,
                "trailing": self.position.trailing_active,
                "cur_price": self.ind_ema if self.ind_ema else self.position.peak_price,
                "ema": self.ind_ema if self.ind_ema else None,
                "ema_slow": self.ind_ema_slow if self.ind_ema_slow else None,
                "rsi": self.ind_rsi if self.ind_rsi else None,
                "adx": self.ind_adx if self.ind_adx else None,
                "momentum": self.ind_momentum if self.ind_momentum else None,
                "volume_mult": self.ind_volume_mult if self.ind_volume_mult else None,
            },
            "daily_pnl": self.daily_pnl,
            "last_trade_time": (
                self.last_trade_time.isoformat()
                if self.last_trade_time else None
            ),
            "last_trade_pnl": self.last_trade_pnl,
            "last_error": self.last_error,
            "trade_count": self.trade_count,
            "win_count": self.win_count,
            "loss_count": self.loss_count,
            "winrate": (
                round(self.win_count / self.trade_count * 100, 1)
                if self.trade_count > 0 else 0.0
            ),
            "total_pnl": self.total_pnl,  # все сделки из логов
            "uptime_sec": (
                round((datetime.now() - self.start_time).total_seconds())
                if self.start_time else 0
            ),
            "server_uptime_sec": (
                round((datetime.now() - self.server_start_time).total_seconds())
                if self.server_start_time else 0
            ),
            "portfolio_balance": self.portfolio_balance,
            "portfolio_blocked": self.portfolio_blocked,
        }


# Глобальный singleton — импортировать как `from shared import state`
state = BotState()