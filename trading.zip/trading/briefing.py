#!/usr/bin/env python3
"""
briefing.py — генерирует аналитический брифинг CCM6.
Запускается по cron каждые 30 мин.
Данные: свечи с Tinkoff API + позиция/баланс с бота (HTTP) + LLM-анализ.
Выход: append в briefings/briefing_{date}.jsonl
"""
import asyncio
import aiohttp
import json
import os
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
sys.stderr.reconfigure(encoding='utf-8')

BASE_DIR = Path(__file__).parent
BRIEFINGS_DIR = BASE_DIR / "briefings"
BRIEFINGS_DIR.mkdir(exist_ok=True)
ANALYSIS_DIR = BASE_DIR / "analysis"
ANALYSIS_DIR.mkdir(exist_ok=True)

LOCK_FILE = BASE_DIR / "briefing.lock"
from configbot import SERVER_PORT
BOT_URL = f"http://127.0.0.1:{SERVER_PORT}"
MAX_ENTRIES_PER_DAY = 96  # 48 часов × 2 записи

# ─── Config from .env ──────────────────────────────────────────
def load_env():
    # Trading .env
    env_path = BASE_DIR / ".env"
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            if '=' in line and not line.startswith('#'):
                k, v = line.strip().split('=', 1)
                os.environ.setdefault(k, v)
    # Hermes .env (for LLM key)
    hermes_env = Path.home() / ".hermes" / ".env"
    if hermes_env.exists():
        for line in hermes_env.read_text().splitlines():
            if '=' in line and not line.startswith('#'):
                k, v = line.strip().split('=', 1)
                os.environ.setdefault(k, v)

load_env()

TOKEN = os.getenv("TINKOFF_SANDBOX_TOKEN") or os.getenv("TINKOFF_TOKEN")
SANDBOX = os.getenv("TINKOFF_SANDBOX_TOKEN") is not None
ACCOUNT_ID = os.getenv("TINKOFF_ACCOUNT_ID") or ""
LLM_URL = os.getenv("LLM_URL", "https://opencode.ai/zen/v1/chat/completions")
LLM_KEY = os.getenv("OPENCODE_ZEN_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "minimax-m2.5-free")
BASE_URL = "https://invest-public-api.tinkoff.ru/rest"
TICKER = "CCM6"


async def resolve_future(ticker: str, class_code: str = "SPBFUT") -> str:
    """Resolve ticker → figi. idType=2 = INSTRUMENT_ID_TYPE_TICKER."""
    async with aiohttp.ClientSession() as sess:
        hdrs = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
        async with sess.post(
            f"{BASE_URL}/tinkoff.public.invest.api.contract.v1.InstrumentsService/FutureBy",
            headers=hdrs,
            json={"idType": 2, "id": ticker, "classCode": class_code},
            timeout=aiohttp.ClientTimeout(total=10),
        ) as r:
            data = await r.json()
            return data.get("instrument", {}).get("figi", "")


INTERVAL = "1min"
PRELOAD_HOURS = 6


# ─── Lock ─────────────────────────────────────────────────────
def acquire_lock():
    if LOCK_FILE.exists():
        pid = LOCK_FILE.read_text().strip()
        # Проверяем жив ли процесс
        if os.path.exists(f"/proc/{pid}"):
            print(f"[briefing] Lock held by {pid}, skip.")
            return False
        print(f"[briefing] Stale lock {pid}, removing.")
    LOCK_FILE.write_text(str(os.getpid()))
    return True

def release_lock():
    if LOCK_FILE.exists():
        LOCK_FILE.unlink()

async def get_candles(figi: str, hours: int = 6) -> list:
    """Получить свечи M1 за последние `hours` часов."""
    now = datetime.now(timezone.utc)
    to_ts = now.isoformat()
    from_ts = (now - timedelta(hours=hours)).isoformat()

    async with aiohttp.ClientSession() as sess:
        hdrs = {"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"}
        payload = {
            "figi": figi,
            "from": from_ts,
            "to": to_ts,
            "interval": "CANDLE_INTERVAL_1_MIN",
        }
        async with sess.post(
            f"{BASE_URL}/tinkoff.public.invest.api.contract.v1.MarketDataService/GetCandles",
            headers=hdrs, json=payload, timeout=aiohttp.ClientTimeout(total=15)
        ) as r:
            data = await r.json()
            candles_raw = data.get("candles", [])
            return [
                {
                    "time": c["time"],
                    "open": float(c["open"]["units"]) + float(c["open"]["nano"]) / 1e9,
                    "high": float(c["high"]["units"]) + float(c["high"]["nano"]) / 1e9,
                    "low": float(c["low"]["units"]) + float(c["low"]["nano"]) / 1e9,
                    "close": float(c["close"]["units"]) + float(c["close"]["nano"]) / 1e9,
                    "volume": int(c["volume"]),
                }
                for c in candles_raw
            ]


# ─── Indicators ───────────────────────────────────────────────
def calc_rsi(closes: list, period: int = 14) -> float:
    if len(closes) < period + 1:
        return 50.0
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gain = sum(max(d, 0) for d in deltas[-period:]) / period
    loss = sum(abs(min(d, 0)) for d in deltas[-period:]) / period
    if loss == 0:
        return 100.0
    rs = gain / loss
    return 100 - (100 / (1 + rs))


def calc_atr(candles: list, period: int = 14) -> float:
    if len(candles) < period + 1:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        h, l, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
        tr = max(h - l, abs(h - pc), abs(l - pc))
        trs.append(tr)
    return sum(trs[-period:]) / period


def calc_bollinger(closes: list, period: int = 20, std_mult: float = 2.0):
    if len(closes) < period:
        return None, None, None
    import statistics
    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - std_mult * std, mean, mean + std_mult * std


def calc_macd(closes: list, fast: int = 12, slow: int = 26, signal: int = 9):
    if len(closes) < slow + signal:
        return 0.0, 0.0, 0.0
    import statistics
    def ema(data, n):
        k = 2 / (n + 1)
        ema_val = sum(data[:n]) / n
        for v in data[n:]:
            ema_val = v * k + ema_val * (1 - k)
        return ema_val
    e_fast = ema(closes, fast)
    e_slow = ema(closes, slow)
    macd_line = e_fast - e_slow
    macd_hist = macd_line  # placeholder
    return macd_line, 0.0, macd_hist


# ─── Bot state via HTTP ────────────────────────────────────────
async def get_bot_status() -> dict:
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.get(
                f"{BOT_URL}/api/status", timeout=aiohttp.ClientTimeout(total=5)
            ) as r:
                if r.status == 200:
                    return await r.json()
    except Exception:
        pass
    return {}


SYSTEM_PROMPT = """Ты — торговый аналитик фьючерса COCOA (CCM6). Формат ответа — ТОЛЬКО JSON без markdown-разметки:

{
  "sentiment": "bullish | bearish | neutral",
  "summary": "2-3 предложения что происходит и почему",
  "key_levels": {"support": число, "resistance": число, "pivot": число},
  "signals": ["описание сигнала 1", "описание сигнала 2"],
  "warnings": ["предупреждение 1", "предупреждение 2"],
  "recommendation": "краткая рекомендация 1-2 слова"
}

Будь конкретным. Не придумывай уровни далеко от текущей цены."""

USER_PROMPT_TEMPLATE = """Текущая ситуация по CCM6 (COCOA futures):

Цена последней свечи: {price}
RSI(14): {rsi}
ATR(14): {atr}
Bollinger(20): lower={bb_lower:.2f}, mid={bb_mid:.2f}, upper={bb_upper:.2f}
MACD: {macd:.4f}
Объём последнего часа: {vol_h}
Объём средний (час): {vol_avg_h}

Позиция: {position} (entry={entry}, lot={lot})
Баланс: {balance} RUB
Время: {time_str}

Дай брифинг."""

def build_user_prompt(candles: list, status: dict, rsi_val, atr_val, bb, macd_val) -> str:
    closes = [c["close"] for c in candles]
    price = closes[-1] if closes else 0
    vol_last_hour = sum(c["volume"] for c in candles[-60:])
    vol_avg_hour = sum(c["volume"] for c in candles) / max(len(candles) / 60, 1)
    msk_tz = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk_tz)
    now_str = now_msk.strftime("%Y-%m-%d %H:%M MSK")

    pos = status.get("position", {})
    bb_l, bb_m, bb_u = bb or (0, 0, 0)

    return USER_PROMPT_TEMPLATE.format(
        price=round(price, 4),
        rsi=round(rsi_val, 1),
        atr=round(atr_val, 4),
        bb_lower=round(bb_l, 4),
        bb_mid=round(bb_m, 4),
        bb_upper=round(bb_u, 4),
        macd=round(macd_val, 4),
        vol_h=vol_last_hour,
        vol_avg_h=round(vol_avg_hour, 0),
        position=pos.get("side", "NONE"),
        entry=pos.get("entry_price", 0),
        lot=pos.get("lot", 0),
        balance=round(status.get("portfolio_balance", 0)),
        time_str=now_str,
    )


def build_analysis_template(price, rsi_val, bb, macd_val, atr_val, position, balance) -> dict:
    """Template-based fallback when LLM is unavailable."""
    closes_str = f"{price:.4f}"

    # RSI sentiment
    if rsi_val > 70:
        rsi_sent = "перекуплен"
    elif rsi_val < 30:
        rsi_sent = "перепродан"
    else:
        rsi_sent = "нейтральная зона"

    # MACD sentiment
    macd_sent = "бычий" if macd_val > 0 else "медвежий"

    # BB position
    if bb:
        bb_l, bb_m, bb_u = bb
        if price < bb_l:
            bb_pos = "ниже нижней полосы (сильный сигнал на покупку)"
        elif price > bb_u:
            bb_pos = "выше верхней полосы (сильный сигнал на продажу)"
        elif price > bb_m:
            bb_pos = "в верхней половине полос"
        else:
            bb_pos = "в нижней половине полос"
    else:
        bb_pos = "данные BB недоступны"

    sentiment = "bullish" if rsi_val < 50 else "bearish" if rsi_val > 65 else "neutral"

    summary = (
        f"COCOA (CCM6) торгуется на {closes_str}. "
        f"RSI(14)={rsi_val:.0f} ({rsi_sent}), MACD={macd_sent} ({macd_val:.4f}). "
        f"Bollinger: {bb_pos}. "
        f"{'Позиция SHORT открыта.' if position == 'SHORT' else 'Позиция NONE.'}"
    )

    support = round(bb[0], 4) if bb else 0
    resistance = round(bb[2], 4) if bb else 0
    pivot = round(bb[1], 4) if bb else round(price, 4)

    signals = []
    if rsi_val < 30:
        signals.append(f"RSI перепродан ({rsi_val:.0f}) — сигнал на покупку")
    elif rsi_val > 70:
        signals.append(f"RSI перекуплен ({rsi_val:.0f}) — сигнал на продажу")
    if macd_val > 0:
        signals.append("MACD в положительной зоне — бычий момент")
    elif macd_val < 0:
        signals.append("MACD в отрицательной зоне — медвежий момент")

    warnings = []
    if position != 'NONE':
        warnings.append(f"Позиция {position} открыта — следи за маржей")
    if balance < 10000:
        warnings.append(f"Низкий баланс ({balance:.0f} RUB)")

    return {
        "sentiment": sentiment,
        "summary": summary,
        "key_levels": {"support": support, "resistance": resistance, "pivot": pivot},
        "signals": signals or ["нет четких сигналов"],
        "warnings": warnings or [],
        "recommendation": "wait" if sentiment == "neutral" else ("long" if sentiment == "bullish" else "short"),
    }


def call_llm_sync(system: str, user: str) -> str:
    import urllib.request, json, os

    key = os.getenv("OPENCODE_ZEN_API_KEY", LLM_KEY)
    if not key:
        return json.dumps({"error": "no API key"})

    body = json.dumps({
        "model": LLM_MODEL,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "max_tokens": 350,
        "temperature": 0.3,
    }).encode()

    req = urllib.request.Request(
        LLM_URL, data=body, method="POST",
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
        }
    )
    resp = json.loads(urllib.request.urlopen(req, timeout=30).read())
    msg = resp.get("choices", [{}])[0].get("message", {})
    content = msg.get("content", "")
    # Handle null/empty content (reasoning models may not output content)
    if not content:
        return "{}"
    return content


async def call_llm(system: str, user: str) -> str:
    """Sync call (urllib is blocking but fine for this use case)."""
    import concurrent.futures
    loop = asyncio.get_event_loop()
    with concurrent.futures.ThreadPoolExecutor() as pool:
        return await loop.run_in_executor(pool, lambda: call_llm_sync(system, user))


# ─── JSONL ────────────────────────────────────────────────────
def today_file() -> Path:
    today = datetime.now().strftime("%Y-%m-%d")
    return BRIEFINGS_DIR / f"briefing_{today}.jsonl"


def trim_file(path: Path, max_entries: int = MAX_ENTRIES_PER_DAY):
    if not path.exists():
        return
    lines = path.read_text().strip().splitlines()
    if len(lines) > max_entries:
        path.write_text("\n".join(lines[-max_entries:]) + "\n")


def append_briefing(entry: dict):
    path = today_file()
    path.parent.mkdir(exist_ok=True)
    path.open("a").write(json.dumps(entry, ensure_ascii=False) + "\n")
    trim_file(path)


def latest_briefing() -> dict:
    path = today_file()
    if not path.exists():
        return {}
    lines = path.read_text().strip().splitlines()
    if not lines:
        return {}
    return json.loads(lines[-1])


# ─── Main ─────────────────────────────────────────────────────
async def main():
    msk_tz = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk_tz)
    ts_start = now_msk.isoformat()
    print(f"[briefing] Start {ts_start}")

    if not acquire_lock():
        return

    try:
        # 1. Resolve FIGI + fetch candles
        print("[briefing] Resolving ticker...")
        figi = await resolve_future(TICKER)
        if not figi:
            print(f"[briefing] Cannot resolve {TICKER}, skip.")
            return
        print(f"[briefing] {TICKER} -> {figi}")

        print("[briefing] Fetching candles...")
        candles = await get_candles(figi, hours=PRELOAD_HOURS)
        if not candles:
            print("[briefing] No candles, skip.")
            return
        closes = [c["close"] for c in candles]

        # 2. Indicators
        rsi_val = calc_rsi(closes)
        atr_val = calc_atr(candles)
        bb = calc_bollinger(closes)
        macd_val, _, _ = calc_macd(closes)

        # 3. Bot state
        status = await get_bot_status()

        # 4. LLM → template fallback
        user_prompt = build_user_prompt(candles, status, rsi_val, atr_val, bb, macd_val)
        raw = await call_llm(SYSTEM_PROMPT, user_prompt)

        # Parse LLM response, fallback to template
        try:
            analysis = json.loads(raw)
            if not analysis or analysis == {} or 'error' in analysis:
                raise ValueError("LLM error or empty")
        except Exception:
            price = closes[-1] if closes else 0
            pos = status.get("position", {}).get("side", "NONE")
            bal = status.get("portfolio_balance", 0)
            analysis = build_analysis_template(price, rsi_val, bb, macd_val, atr_val, pos, bal)
            print("[briefing] LLM unavailable, using template")

        # 5. Entry
        entry = {
            "ts": ts_start,
            "price": round(closes[-1], 4),
            "rsi": round(rsi_val, 1),
            "atr": round(atr_val, 4),
            "bb_lower": round(bb[0], 4) if bb else 0,
            "bb_upper": round(bb[2], 4) if bb else 0,
            "macd": round(macd_val, 4),
            "position": status.get("position", {}).get("side", "NONE"),
            "balance": status.get("portfolio_balance", 0),
            "analysis": analysis,
        }

        append_briefing(entry)

        # Write analysis/analysis_YYYYMMDD.txt for dashboard card
        date_str = datetime.now().strftime("%d%m%Y")
        analysis_file = ANALYSIS_DIR / f"analysis_{date_str}.txt"
        a = analysis

        # Market
        rsi_sent = "перекуплен" if rsi_val > 70 else "перепродан" if rsi_val < 30 else "нейтральная зона"
        macd_sent = "бычий" if macd_val > 0 else "медвежий"
        price_val = float(closes[-1]) if closes else 0.0
        price_str = f"{price_val:.2f}"
        if bb:
            bb_l, bb_u = bb[0], bb[2]
            bb_pos = "выше верхней полосы" if price_val > bb_u else "ниже нижней полосы" if price_val < bb_l else "внутри полос"
        else:
            bb_pos = "данные недоступны"
        market_line = f"РЫНОК: цена {price_str}, RSI={rsi_val:.0f} ({rsi_sent}), MACD {macd_sent} ({macd_val:.4f}), BB {bb_pos}."

        # Patterns
        patterns = []
        if rsi_val < 30:
            patterns.append("RSI перепродан — потенциал отскока")
        elif rsi_val > 70:
            patterns.append("RSI перекуплен — риск коррекции")
        if macd_val > 0:
            patterns.append("MACD выше 0 — бычий момент")
        elif macd_val < 0:
            patterns.append("MACD ниже 0 — медвежий момент")
        if bb and price_val:
            if price_val < bb[0]:
                patterns.append("цена ниже нижней BB — перепроданность")
            elif price_val > bb[2]:
                patterns.append("цена выше верхней BB — перекупленность")
        pos_side = status.get("position", {}).get("side", "NONE")
        if pos_side != "NONE":
            patterns.append(f"позиция {pos_side} открыта")
        patterns_line = "ПАТТЕРНЫ: " + "; ".join(patterns) if patterns else "ПАТТЕРНЫ: без сигналов."

        # Reasons / Warnings
        reasons = []
        sentiment = a.get("sentiment", "neutral")
        if sentiment == "bullish":
            reasons.append("настроение рынка бычье")
        elif sentiment == "bearish":
            reasons.append("настроение рынка медвежье")
        for w in (a.get("warnings") or [])[:3]:
            reasons.append(w)
        if pos_side != "NONE":
            entry_price = status.get("position", {}).get("entry_price", 0)
            reasons.append(f"вход по {entry_price:.2f}")
        reasons_line = "ПРИЧИНЫ: " + "; ".join(reasons) if reasons else "ПРИЧИНЫ: анализ данных."

        # Recommendation
        rec = a.get("recommendation", "wait")
        key_levels = a.get("key_levels", {}) or {}
        support = key_levels.get("support", 0)
        resistance = key_levels.get("resistance", 0)
        rec_line = f"РЕКОМЕНДАЦИЯ: {rec.upper()}"
        if support and resistance:
            rec_line += f" | поддержка {support:.2f}, сопротивление {resistance:.2f}"
        elif bb:
            rec_line += f" | BB {bb[0]:.1f}–{bb[2]:.1f}"

        analysis_text = f"{market_line}\n\n{patterns_line}\n\n{reasons_line}\n\n{rec_line}"
        analysis_file.write_text(analysis_text, encoding="utf-8")

        print(f"[briefing] Saved. sentiment={analysis.get('sentiment','?')} price={entry['price']}")

    except Exception as e:
        print(f"[briefing] Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        release_lock()


if __name__ == "__main__":
    asyncio.run(main())
