"""bot_server.py — subprocess runner. SIGINT корректно глушится."""
import os
import sys
import signal
import subprocess

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from configbot import SERVER_PORT

if __name__ == "__main__":
    print(f"\n{'='*55}")
    print(f"CCM6 Trading Dashboard")
    print(f"  Dashboard:  http://127.0.0.1:{SERVER_PORT}")
    print(f"  Stop:       Ctrl+C")
    print(f"{'='*55}\n")

    proc = subprocess.Popen(
        [sys.executable, os.path.join(BASE_DIR, "_server.py")],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=BASE_DIR,
    )

    def shutdown(signum, frame):
        print("\nОстановка...", flush=True)
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        print("Остановлено.", flush=True)
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # stdout/stderr → DEVNULL, процесс пишет в никуда
    # Бот логирует в файл bot.log напрямую
    proc.wait()