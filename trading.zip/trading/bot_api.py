"""bot_api.py — FastAPI REST API + SSE для dashboard."""
import os
import asyncio
import json
import re
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import FastAPI, Request, Body
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware

from shared import state
from configbot import TICKER
from bot import price_to_float

def _pf(val) -> float:
    """Safe price extractor: dict → float, float → float, else → 0."""
    if val is None:
        return 0.0
    if isinstance(val, float):
        return val
    if isinstance(val, int):
        return float(val)
    return price_to_float(val) if isinstance(val, dict) else 0.0

app = FastAPI(title="CCM6 Trading Bot API")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

LOG_DIR = os.path.dirname(os.path.abspath(__file__)) or "."


# ============================================================
# HELPERS
# ============================================================

def parse_trades_log(date_str: str) -> list:
    """Читает trades_{date}.log и возвращает список сделок."""
    filename = os.path.join(LOG_DIR, "logs", f"trades_{date_str.replace('.', '')}.log")
    trades = []
    if os.path.exists(filename):
        with open(filename, encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(" | ")
                if len(parts) < 4:
                    continue
                # 06.05.2026 22:08:46 | OPEN LONG | CCM6 | 1 контрактов @ 316.2000
                # 06.05.2026 22:26:30 | CLOSE (SL) | CCM6 | 1 контрактов @ 316.9000 | P/L: +1.00 RUB
                try:
                    trade = {
                        "time": parts[0],
                        "action": parts[1],
                        "ticker": parts[2],
                        "contracts_str": parts[3],
                        "pnl": None,
                        "reason": None,
                    }
                    if len(parts) >= 5:
                        pnl_part = parts[4]
                        m = re.search(r"P/L:\s*([+-]?[\d.]+)", pnl_part)
                        if m:
                            trade["pnl"] = float(m.group(1))
                        reason_m = re.search(r"(TP|SL|TRAIL|CLOSE)", parts[1])
                        if reason_m:
                            trade["reason"] = reason_m.group(1)
                    # Извлекаем цену
                    price_m = re.search(r"@\s*([\d.]+)", parts[3])
                    if price_m:
                        trade["price"] = float(price_m.group(1))
                    # Направление из action
                    if "LONG" in parts[1]:
                        trade["direction"] = "LONG"
                    elif "SHORT" in parts[1]:
                        trade["direction"] = "SHORT"
                    trades.append(trade)
                except Exception:
                    continue
    return trades


def compute_stats(trades: list) -> dict:
    """Считает статистику из списка сделок."""
    closed = [t for t in trades if t.get("pnl") is not None]
    wins = [t for t in closed if t["pnl"] > 0]
    losses = [t for t in closed if t["pnl"] < 0]
    pnls = [t["pnl"] for t in closed]
    total = sum(pnls) if pnls else 0.0

    return {
        "total_trades": len(closed),
        "wins": len(wins),
        "losses": len(losses),
        "winrate": round(len(wins) / len(closed) * 100, 1) if closed else 0.0,
        "total_pnl": round(total, 2),
        "avg_pnl": round(total / len(closed), 2) if closed else 0.0,
        "best_trade": max(pnls) if pnls else 0.0,
        "worst_trade": min(pnls) if pnls else 0.0,
    }


def _price(v) -> float:
    """Конвертирует цену: поддерживает dict {units,nano}, Quotation и числа."""
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    # Quotation / MoneyValue dataclass
    if hasattr(v, 'units') and hasattr(v, 'nano'):
        return int(v.units or 0) + int(v.nano or 0) / 1_000_000_000
    # dict format: {units, nano}
    if isinstance(v, dict):
        if not v:
            return 0.0
        return int(v.get("units", 0) or 0) + int(v.get("nano", 0) or 0) / 1_000_000_000
    return 0.0


def _cget(c, key):
    """Get attr from dataclass or dict."""
    if isinstance(c, dict):
        return c.get(key)
    return getattr(c, key, None)

def candles_to_chart(candles: list) -> list:
    """Конвертирует свечи Tinkoff в формат TradingView (time = Unix seconds)."""
    result = []
    for c in candles:
        try:
            raw_time = _cget(c, "time")
            if isinstance(raw_time, (int, float)):
                ts = int(raw_time)
            elif hasattr(raw_time, 'timestamp'):
                ts = int(raw_time.timestamp())
            else:
                t = datetime.fromisoformat(str(raw_time).replace("Z", "+00:00"))
                ts = int(t.timestamp())
            result.append({
                "time": ts,
                "open": _price(_cget(c, "open")),
                "high": _price(_cget(c, "high")),
                "low": _price(_cget(c, "low")),
                "close": _price(_cget(c, "close")),
            })
        except Exception:
            continue
    return result


# ============================================================
# HTML DASHBOARD
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    with open(os.path.join(LOG_DIR, "templates", "index.html"), encoding="utf-8") as f:
        html = f.read()
    # Inject initial data + latest analysis file
    import glob
    analysis = ""
    matches = sorted(glob.glob(os.path.join(LOG_DIR, "analysis", "analysis_*.txt")))
    if matches:
        with open(matches[-1], encoding="utf-8") as af:
            analysis = af.read()

    state_data = json.dumps(state.to_dict(), default=str)
    scripts = [
        f'<script>window.__INITIAL__ = {state_data};</script>',
        f'<script>window.__ANALYSIS__ = {json.dumps(analysis)};</script>',
    ]
    inject = '\n'.join(scripts)
    html = html.replace('<head>', f'<head>\n{inject}', 1)
    return html

@app.get("/test")
async def test_page():
    with open(os.path.join(LOG_DIR, "templates", "test.html")) as f:
        return HTMLResponse(f.read())


# ============================================================
# REST API
# ============================================================

@app.get("/api/status")
async def status():
    return state.to_dict()


@app.get("/api/portfolio")
async def portfolio():
    """Пытается прочитать последний portfolio_*.log"""
    today = datetime.now().strftime("%d.%m.%Y")
    filename = os.path.join(LOG_DIR, "logs", f"portfolio_{today.replace('.', '')}.log")
    content = ""
    if os.path.exists(filename):
        with open(filename, encoding="utf-8") as f:
            content = f.read()
    return {"raw": content, "file": filename}


@app.get("/api/trades")
async def trades(date: Optional[str] = None, period: Optional[str] = None):
    """period='yesterday' или до 09:00 MSK → вчерашний день."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    if period == "yesterday" or (date is None and now_msk.hour < 9):
        yesterday = now_msk - timedelta(days=1)
        date = yesterday.strftime("%d.%m.%Y")
    elif date is None:
        date = now_msk.strftime("%d.%m.%Y")
    return parse_trades_log(date)


@app.get("/api/candles")
async def candles():
    raw = state.raw_candles or []
    return candles_to_chart(raw[-200:])  # последние 200 свечей


@app.get("/api/stats")
async def stats(date: Optional[str] = None, period: Optional[str] = None):
    """period='yesterday' или до 09:00 MSK → вчерашний день."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    if period == "yesterday" or (date is None and now_msk.hour < 9):
        yesterday = now_msk - timedelta(days=1)
        date = yesterday.strftime("%d.%m.%Y")
    elif date is None:
        date = now_msk.strftime("%d.%m.%Y")
    trades_list = parse_trades_log(date)
    return compute_stats(trades_list)


@app.get("/api/yesterday")
async def yesterday():
    """Всё для вчерашнего дня: trades + stats. Для dashboard до 09:00."""
    msk = timezone(timedelta(hours=3))
    now_msk = datetime.now(msk)
    yesterday_dt = now_msk - timedelta(days=1)
    date_str = yesterday_dt.strftime("%d.%m.%Y")

    trades = parse_trades_log(date_str)
    stats_ = compute_stats(trades)

    # Читаем portfolio лог
    pf_file = os.path.join(LOG_DIR, "logs", f"portfolio_{date_str.replace('.', '')}.log")
    pf_raw = ""
    if os.path.exists(pf_file):
        with open(pf_file, encoding="utf-8") as f:
            pf_raw = f.read()

    return {
        "date": date_str,
        "trades": trades,
        "stats": stats_,
        "portfolio_raw": pf_raw,
        "is_yesterday": True,
    }


@app.get("/api/logs")
async def logs(lines: int = 50):
    """Последние N строк bot.log"""
    log_path = os.path.join(LOG_DIR, "bot.log")
    if os.path.exists(log_path):
        with open(log_path, encoding="utf-8") as f:
            all_lines = f.readlines()
        return {"lines": "".join(all_lines[-lines:])}
    return {"lines": ""}


# ============================================================
# REST API
# ============================================================

@app.post("/api/bot/stop")
async def bot_stop():
    """Останавливает бота: очищает lifecycle Event."""
    from shared import get_lifecycle_event
    state.running = False
    get_lifecycle_event().clear()
    return {"ok": True, "message": "Бот остановлен"}


@app.post("/api/bot/start")
async def bot_start():
    """Запускает бота: устанавливает lifecycle Event."""
    from shared import get_lifecycle_event
    if state.running:
        return {"ok": False, "message": "Бот уже запущен"}
    state.running = True
    state.start_time = __import__("datetime").datetime.now()
    get_lifecycle_event().set()
    return {"ok": True, "message": "Бот запущен"}


@app.post("/api/bot/close")
async def bot_close():
    """Принудительное закрытие текущей позиции."""
    if not state.position.is_open():
        return {"ok": False, "message": "Нет открытой позиции"}

    candles = state.raw_candles
    close_raw = _cget(candles[-1], 'close') if candles else None
    price = _pf(close_raw)
    entry = _pf(state.position.entry_price)
    side = state.position.side  # читаем ДО сброса
    lot = state.position.lot or 10

    state.force_close = True
    state.position.side = "NONE"
    state.position.entry_price = 0.0
    state.position.lot = 0
    state.position.peak_price = 0.0
    state.position.trailing_active = False

    if price and entry:
        pnl = (price - entry) * lot * 10 if side == "LONG" else (entry - price) * lot * 10
        state.daily_pnl = (state.daily_pnl or 0) + pnl
        state.last_trade_pnl = pnl
        state.last_trade_time = datetime.now(timezone.utc)
        state.trade_count += 1
        if pnl >= 0:
            state.win_count += 1
        else:
            state.loss_count += 1
        state.worst_trade = min(state.worst_trade or 0, pnl)
        state.best_trade = max(state.best_trade or 0, pnl)
        state.portfolio_blocked = 0
        msg = f"Закрытие {side} @ {price:.4f} | P/L: {pnl:.2f} RUB"
    else:
        msg = f"Закрытие {side}"
    return {"ok": True, "message": msg}



@app.post("/api/bot/open")
async def bot_open(body: dict = Body(default={}), dir: str = "long"):
    """Принудительное открытие позиции (10 лотов). dir=long|short."""
    if state.position.is_open():
        return {"ok": False, "message": f"Позиция уже открыта: {state.position.side}"}
    side = (body.get("side") or dir).upper()
    if side not in ("LONG", "SHORT"):
        return {"ok": False, "message": "dir должен быть: long или short"}

    candles = state.raw_candles
    close_raw = _cget(candles[-1], 'close') if candles else None
    price = _pf(close_raw)
    if not price:
        return {"ok": False, "message": "Нет данных свечей — невозможно открыть"}

    # Ставим флаг — бот откроет в следующем цикле
    state.manual_entry_side = side

    # Сразу обновляем state
    state.position.side = side
    state.position.entry_price = price
    state.position.lot = 10
    state.position.entry_time = datetime.now(timezone.utc)
    state.position.peak_price = price
    state.position.trailing_active = False
    state.portfolio_blocked = round(price * 10 * 1.0, 2)

    log_trade(f"[MANUAL] OPEN {side}", state.current_figi, TICKER, 10, price)

    return {"ok": True, "message": f"Открыто {side} 10 лотов @ {price:.4f}"}


def log_trade(action: str, figi: str, ticker: str, qty: int, price: float, pnl: float = None):
    """Логирование сделки в файл."""
    from pathlib import Path
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    log_path = log_dir / f"trades_{datetime.now().strftime('%d%m%Y')}.log"
    date_str = datetime.now().strftime("%d.%m.%Y %H:%M:%S")
    pnl_str = f" | P/L: {pnl:.2f} RUB" if pnl is not None else ""
    line = f"{date_str} | {action} | {ticker} | {qty} контрактов @ {price:.4f}{pnl_str}\n"
    try:
        with open(log_path, "a") as f:
            f.write(line)
    except Exception:
        pass


# ============================================================
# SSE (Server-Sent Events) — push-обновления в браузер
# ============================================================

@app.get("/api/briefing-history")
async def briefing_history(date: str = None):
    """GET /api/briefing-history?date=YYYY-MM-DD → entries from that day's briefing file."""
    from pathlib import Path
    base = Path(__file__).parent
    if not date:
        date = datetime.now().strftime("%Y-%m-%d")
    path = base / "briefings" / f"briefing_{date}.jsonl"
    if not path.exists():
        return []
    lines = path.read_text().strip().splitlines()
    entries = []
    for line in lines:
        try:
            entries.append(json.loads(line))
        except Exception:
            pass
    return entries


@app.get("/api/briefing")
async def get_briefing():
    """GET /api/briefing → latest entry from today's briefing."""
    from pathlib import Path
    base = Path(__file__).parent
    today = datetime.now().strftime("%Y-%m-%d")
    path = base / "briefings" / f"briefing_{today}.jsonl"
    if not path.exists():
        return {"briefing": None, "ts": None}
    lines = path.read_text().strip().splitlines()
    if not lines:
        return {"briefing": None, "ts": None}
    latest = json.loads(lines[-1])
    price_change = None
    if len(lines) >= 2:
        try:
            prev = json.loads(lines[-2])
            if latest.get('price') and prev.get('price'):
                price_change = round((latest['price'] - prev['price']) / prev['price'] * 100, 2)
        except Exception:
            pass
    return {
        "briefing": latest.get("analysis", {}),
        "ts": latest.get("ts", ""),
        "price": latest.get("price"),
        "price_change": price_change,
        "rsi": latest.get("rsi"),
        "position": latest.get("position"),
        "balance": latest.get("balance"),
    }


@app.get("/api/events")
async def events():
    async def generate():
        last_json = "{}"
        while True:
            current = json.dumps(state.to_dict())
            if current != last_json:
                last_json = current
                yield f"data: {current}\n\n"
            await asyncio.sleep(2)

    return StreamingResponse(generate(), media_type="text/event-stream")