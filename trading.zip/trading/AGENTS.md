# AGENTS.md — CCM6 Trading Bot

## Быстрый старт

| Команда | Назначение |
|---------|-----------|
| `python bot` | Запуск бота без дашборда |
| `python bot_server.py` | Бот + FastAPI дашборд (subprocess) |
| `python _server.py` | Запуск сервера напрямую (порт 5000) |
| `python run_briefing.py` | Генерация аналитического брифинга |

Зависимости устанавливаются вручную: `pip install fastapi uvicorn aiohttp python-dotenv`.

## Архитектура

- Два процесса: `bot_server.py` → subprocess → `_server.py` (FastAPI :5000 + бот в daemon-потоке)
- `bot_server.py` подавляет stdout/stderr дочернего процесса (пишет в DEVNULL) — усложняет отладку
- Lifecycle бота: `threading.Event` в `shared.py`. `/api/bot/stop` → `.clear()`, `/api/bot/start` → `.set()`
- Общее состояние: singleton `shared.state` класса `BotState` (dataclass)

## Конфигурация

- **configbot.py** — параметры стратегии, режим (песочница/реал), риск-менеджмент, `SERVER_PORT = 5000`
- **.env** — токены (не коммитить)
- `SANDBOX = True` — работа через `client.sandbox.sandbox_pay_in()` + `client.orders.post_order()`
- `SANDBOX = False` → используется `TINKOFF_TOKEN` (реальные ордера не реализованы)

## Tinkoff API (gRPC через SDK t-tech-investments)

- SDK: `pip install t-tech-investments --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple`
- Контекстный менеджер: `async with AsyncClient(token, target=..., app_name=...) as client:`
- `client` на самом деле `AsyncServices` из `t_tech.invest.async_services`
- Ордера: `client.orders.post_order(figi=..., quantity=..., direction=..., account_id=..., order_type=..., order_id=..., instrument_id=...)` — **только keyword-only**
- Свечи истории: `client.get_all_candles(figi=..., from_=..., to=..., interval=1)` → async iterable `HistoricCandle` (есть `is_complete`)
- Свечи стрима: `client.create_market_data_stream()` → `MarketDataStream`, `md.candle` → `Candle` (НЕТ `is_complete`)
- Статус торгов: `client.market_data.get_trading_status(figi=...)` → `TradingStatus` (поля: `trading_status`, `market_order_available_flag`, `limit_order_available_flag`, НЕТ `api_trade_available_flag`)
- Sandbox pay-in: `client.sandbox.sandbox_pay_in(account_id=..., amount=MoneyValue(currency="rub", units=..., nano=0))`
- Конвертация цен: `qfloat(q) = q.units + q.nano / 1e9` — работает для `Quotation` и `MoneyValue`
- MarketDataStream: `stream.candles.waiting_close().subscribe([CandleInstrument(...)])` + `stream.info.subscribe([InfoInstrument(...)])`

## Дашборд

- Порт задаётся в `configbot.py` (`SERVER_PORT`, по умолчанию 5000)
- HTML-дашборд: `templates/index.html` (TradingView Lightweight Charts)
- SSE: `/api/events` — push-обновления состояния
- Кнопки: Start / Stop / Close Pos / Open Long / Open Short

## Брифинг (briefing.py)

- Генерирует аналитику через LLM каждые 30 мин (по cron)
- **Требует** `OPENCODE_ZEN_API_KEY` из `~/.hermes/.env`
- Fallback на шаблонный анализ при недоступности LLM
- Результаты: `briefings/briefing_{YYYY-MM-DD}.jsonl` + `analysis_{DDMMYYYY}.txt`
- Lock-файл: `briefing.lock` (предотвращает параллельный запуск)
- `run_briefing.py` грузит `~/.hermes/.env` + `.env` перед запуском

## Логи и данные

- Сделки: `logs/trades_{DDMMYYYY}.log` — парсится по шаблону `P/L:\s*([+-]?[\d.]+)`
- Портфель: `logs/portfolio_{DDMMYYYY}.log`
- Аналитика: `analysis_{DDMMYYYY}.txt` — читается дашбордом
- Статистика при старте загружается из логов (`load_stats_from_logs`)

## Рынок

- Статус определяется динамически: `trading_status` из стрима (`NORMAL_TRADING` || `market_order_available_flag` || `limit_order_available_flag`) + возраст последней свечи ≤ 10 мин как fallback
- Хардкод расписания/праздников удалён (был `is_market_open()`, `is_trading_time()`)
- Клиринг (14:00–14:03 МСК) — трейдинг-статус уходит из NORMAL_TRADING, бот не входит

## Стратегия (ключевые параметры)

- EMA fast/slow = 9/21, RSI(14) oversold 30, overbought 70
- ADX ≥ 28, momentum ≥ 0.5, объём ≥ 1.2× от avg (минимум 100 контрактов)
- Запрет входа после 19:00 МСК, кулдаун между входами 30 мин
- RSI_OVERBOUGHT_FILTER = 55 — запрет LONG при RSI выше 55
- SL 0.5%, TP 1.5%, Trailing: активация при +0.8%, дистанция 0.4%

## Termux (Android)

- **Скрипт**: `bash termux_start.sh help` — смотреть команды
- **Установка**: `bash termux_start.sh install` — ставит tmux, rust, protobuf, pip пакеты
- **Запуск с tmux**: `bash termux_start.sh tmux` — бот в tmux-сессии, не умирает при закрытии Termux
- **Wake lock**: автоматически захватывается и отпускается при выходе
- **Дашборд**: `http://localhost:5000/` в браузере Android
- **Для фоновой работы**: отключить battery optimization для Termux (Настройки → Батарея → Исключения)

## Чего нет

- **Тесты**: отсутствуют
- **Линтер/форматтер/typecheck**: отсутствуют
- **Менеджер пакетов**: отсутствует (`requirements.txt`, `pyproject.toml`)
- **Git**: не репозиторий (папка `.git` есть, но git.exe недоступен в PATH)
- **Resume для реала**: логика восстановления позиции есть только для песочницы
- **briefing.py**: всё ещё использует REST (aiohttp), не SDK — работает, миграция не приоритетна
