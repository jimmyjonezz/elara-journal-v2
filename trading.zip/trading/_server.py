"""_server.py — внутренний сервер (запускается через subprocess).
   stderr уже подавлен в bot_server.py, здесь только логика."""
import asyncio
import os
import threading
import signal
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(__file__))
from configbot import SERVER_PORT

async def main():
    from shared import state, get_lifecycle_event
    import uvicorn
    from fastapi.staticfiles import StaticFiles
    from bot_api import app as api_app
    from bot import main as run_bot

    # Static files — монтируем прямо на api_app
    static_path = os.path.join(os.path.dirname(__file__), "static")
    if os.path.isdir(static_path):
        api_app.mount("/static", StaticFiles(directory=static_path, html=True), name="static")

    from shared import get_lifecycle_event
    from bot import main as run_bot
    state.server_start_time = datetime.now()
    get_lifecycle_event().set()  # бот стартует сразу

    def bot_runner():
        asyncio.run(run_bot())

    bot_thread = threading.Thread(target=bot_runner, daemon=True)
    bot_thread.start()

    config = uvicorn.Config(
        api_app,
        host="127.0.0.1",
        port=SERVER_PORT,
        log_level="error",
        lifespan="off",
    )
    server = uvicorn.Server(config)
    await server.serve()

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    finally:
        get_lifecycle_event().clear()
        state.running = False
