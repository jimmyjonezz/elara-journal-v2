#!/data/data/com.termux/files/usr/bin/bash
# termux_start.sh — запуск CCM6 бота на Android (Termux)
# Использование: bash termux_start.sh [server|bot]

set -e

DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

load_env() {
    if [ -f .env ]; then
        set -a; source .env; set +a
    fi
    if [ -f ~/.hermes/.env ]; then
        set -a; source ~/.hermes/.env; set +a
    fi
}

case "${1:-server}" in
    server)
        echo "=== CCM6: FastAPI + Bot ==="
        echo "[1/4] Wake lock..."
        termux-wake-lock ccm6
        trap 'termux-wake-unlock ccm6; echo "Wake lock released"' EXIT

        echo "[2/4] Loading .env..."
        load_env

        echo "[3/4] Starting server..."
        exec python _server.py
        ;;
    bot)
        echo "=== CCM6: Bot only (no dashboard) ==="
        echo "[1/3] Wake lock..."
        termux-wake-lock ccm6
        trap 'termux-wake-unlock ccm6; echo "Wake lock released"' EXIT

        echo "[2/3] Loading .env..."
        load_env

        echo "[3/3] Starting bot..."
        exec python bot.py
        ;;
    tmux)
        session="ccm6"
        echo "=== CCM6: tmux session '$session' ==="
        echo "Attach: tmux attach -t $session"

        # Kill existing session
        tmux kill-session -t "$session" 2>/dev/null || true

        tmux new-session -d -s "$session" -n bot
        tmux send-keys -t "$session:bot" "cd $DIR && bash termux_start.sh server" Enter

        tmux new-window -t "$session" -n shell
        tmux send-keys -t "$session:shell" "cd $DIR && echo 'Bot running in left pane (Ctrl+B 0). Dashboard: http://localhost:5000/'" Enter

        tmux select-window -t "$session:bot"

        echo "Attaching... (Ctrl+B D to detach)"
        tmux attach -t "$session"
        ;;
    install)
        echo "=== Installing Termux dependencies ==="
        pkg update -y
        pkg install -y tmux protobuf rust binutils python python-pip

        echo "Python packages..."
        pip install t-tech-investments fastapi uvicorn aiohttp python-dotenv \
            --index-url https://opensource.tbank.ru/api/v4/projects/238/packages/pypi/simple

        echo "Done. Run: bash termux_start.sh tmux"
        ;;
    help|*)
        echo "Usage: bash termux_start.sh <command>"
        echo ""
        echo "Commands:"
        echo "  server    Start FastAPI + bot (default)"
        echo "  bot       Start bot only (no dashboard)"
        echo "  tmux      Start in tmux session (stay alive after closing Termux)"
        echo "  install   Install Termux/system dependencies"
        echo "  help      Show this help"
        ;;
esac
