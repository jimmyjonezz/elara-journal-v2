"""
Фьючерсный моментум-бот (gRPC через SDK t-tech-investments)
Инструмент: CCM6, свечи 1-мин
"""
import sys
import os
import re
import asyncio
import uuid
from datetime import datetime, timezone, timedelta
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) or ".")
sys.stdout.reconfigure(encoding='utf-8')

from dotenv import load_dotenv
load_dotenv()

from configbot import (
    SANDBOX, AUTO_PAYIN, ACCOUNT_ID, TICKER, DEBUG,
    EMA_FAST, EMA_SLOW, RSI_PERIOD, RSI_OVERBOUGHT, RSI_OVERSOLD,
    VOLUME_MULTIPLIER, MOMENTUM_PERIOD,
    RISK_PERCENT, STOP_LOSS_PCT, TAKE_PROFIT_PCT,
    TRAILING_ACTIVATE, TRAILING_DISTANCE, TIME_FILTER_HOUR, PRELOAD_HOURS,
    MOMENTUM_MIN, VOLUME_ABS_MIN, ADX_MIN, ENTRY_COOLDOWN, MIN_HOLD_TIME,
    RSI_OVERBOUGHT_FILTER, SERVER_PORT,
)
from shared import state, Position, get_lifecycle_event

from t_tech.invest import (
    AsyncClient, CandleInstrument, InfoInstrument, SubscriptionInterval,
    OrderDirection, OrderType, MarketDataResponse, MoneyValue,
    SecurityTradingStatus,
)
from t_tech.invest.constants import INVEST_GRPC_API, INVEST_GRPC_API_SANDBOX

import briefing as _briefing
BRIEFING_COOLDOWN = 300

# ── helpers ───────────────────────────────────────────────────

def qfloat(q) -> float:
    if q is None:
        return 0.0
    return q.units + q.nano / 1_000_000_000

def cell_mk(c):
    return (qfloat(c.open), qfloat(c.high), qfloat(c.low), qfloat(c.close))

def price_to_float(m) -> float:
    return qfloat(m)

SDK_TARGET = INVEST_GRPC_API_SANDBOX if SANDBOX else INVEST_GRPC_API

# ── log dir ───────────────────────────────────────────────────

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)

def load_stats_from_logs() -> dict:
    today_prefix = datetime.now().strftime("%d%m%Y")
    total_c = total_w = total_l = 0
    total_p = 0.0
    daily_p = 0.0
    if not os.path.isdir(LOG_DIR):
        return {"trade_count": 0, "win_count": 0, "loss_count": 0,
                "daily_pnl": 0.0, "total_pnl": 0.0, "winrate": 0.0}
    for fname in sorted(os.listdir(LOG_DIR)):
        if not (fname.startswith("trades_") and fname.endswith(".log")):
            continue
        is_today = fname == f"trades_{today_prefix}.log"
        with open(os.path.join(LOG_DIR, fname), encoding="utf-8") as f:
            for line in f:
                m = re.search(r'P/L:\s*([+-]?[\d.]+)', line)
                if not m:
                    continue
                v = float(m.group(1))
                total_p += v
                total_c += 1
                total_w += v > 0
                total_l += v < 0
                if is_today:
                    daily_p += v
    wr = round(total_w / total_c * 100, 1) if total_c else 0.0
    return {"trade_count": total_c, "win_count": total_w, "loss_count": total_l,
            "total_pnl": round(total_p, 2), "daily_pnl": round(daily_p, 2), "winrate": wr}

def log_trade(action, figi, ticker, quantity, price, pnl=None):
    try:
        now = datetime.now()
        ts = now.strftime("%d.%m.%Y %H:%M:%S")
        ds = now.strftime("%d%m%Y")
        pnl_s = f" | P/L: {pnl:+.2f} RUB" if pnl is not None else ""
        line = f"{ts} | {action} | {ticker} | {quantity} контрактов @ {price:.4f}{pnl_s}\n"
        with open(os.path.join(LOG_DIR, f"trades_{ds}.log"), "a", encoding="utf-8") as f:
            f.write(line)
    except Exception as e:
        print(f"log error: {e}")

# ── indicators (pure math, unchanged) ────────────────────────

def calc_ema(values, period):
    if len(values) < period:
        return None
    k = 2.0 / (period + 1)
    ema = sum(values[:period]) / period
    for v in values[period:]:
        ema = v * k + ema * (1 - k)
    return ema

def calc_rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    deltas = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    gains = [d if d > 0 else 0 for d in deltas]
    losses = [-d if d < 0 else 0 for d in deltas]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    return 100.0 - (100.0 / (1.0 + avg_gain / avg_loss))

def calc_adx(highs, lows, closes, period=14):
    if len(closes) < period * 2 + 1:
        return None
    trs, plus_dms, minus_dms = [], [], []
    for i in range(1, len(closes)):
        tr = max(highs[i] - lows[i], highs[i] - closes[i - 1], closes[i - 1] - lows[i])
        plus = highs[i] - highs[i - 1]
        minus = lows[i - 1] - lows[i]
        trs.append(tr)
        plus_dms.append(plus if plus > minus and plus > 0 else 0)
        minus_dms.append(minus if minus > plus and minus > 0 else 0)

    def smooth(data, p):
        s = sum(data[:p]) / p
        result = [s]
        for i in range(p, len(data)):
            s = (s * (p - 1) + data[i]) / p
            result.append(s)
        return result

    tr_s, plus_s, minus_s = smooth(trs, period), smooth(plus_dms, period), smooth(minus_dms, period)
    plus_di = [100 * p / t if t > 0 else 0 for p, t in zip(plus_s, tr_s)]
    minus_di = [100 * m / t if t > 0 else 0 for m, t in zip(minus_s, tr_s)]
    dx = [abs(plus_di[i] - minus_di[i]) / (plus_di[i] + minus_di[i]) * 100
          if (plus_di[i] + minus_di[i]) > 0 else 0 for i in range(len(plus_di))]
    if len(dx) < period:
        return None
    adx = sum(dx[:period]) / period
    for i in range(period, len(dx)):
        adx = (adx * (period - 1) + dx[i]) / period
    return adx

def calc_momentum(closes, period=10):
    if len(closes) < period + 1:
        return None
    return closes[-1] - closes[-period - 1]

def calc_volume_avg(volumes, period=20):
    if not volumes:
        return 0
    return sum(volumes[-min(period, len(volumes)):]) / min(period, len(volumes))

def calc_bollinger(closes, period=20, mult=2.0):
    if len(closes) < period:
        return None, None, None
    import statistics
    mean = statistics.mean(closes[-period:])
    std = statistics.stdev(closes[-period:])
    return mean - mult * std, mean, mean + mult * std

def compute_indicators(candles: list) -> dict:
    clusters = [[qfloat(c.close) for c in candles],
                [qfloat(c.high) for c in candles],
                [qfloat(c.low) for c in candles],
                [c.volume for c in candles]]
    closes, highs, lows, volumes = clusters
    result = {
        'close': closes[-1] if closes else 0,
        'volume': volumes[-1] if volumes else 0,
        'ema_fast': None, 'ema_slow': None,
        'rsi': None, 'adx': None, 'momentum': None, 'vol_avg': None,
        'bb_lower': None, 'bb_mid': None, 'bb_upper': None,
    }
    if len(closes) >= EMA_FAST:
        result['ema_fast'] = calc_ema(closes, EMA_FAST)
    if len(closes) >= EMA_SLOW:
        result['ema_slow'] = calc_ema(closes, EMA_SLOW)
    if len(closes) >= RSI_PERIOD + 1:
        result['rsi'] = calc_rsi(closes, RSI_PERIOD)
    if len(closes) >= EMA_SLOW * 2 + 1:
        result['adx'] = calc_adx(highs, lows, closes, 14)
    if len(closes) >= MOMENTUM_PERIOD + 1:
        result['momentum'] = calc_momentum(closes, MOMENTUM_PERIOD)
    if volumes:
        result['vol_avg'] = calc_volume_avg(volumes, 20)
    bb_l, bb_m, bb_u = calc_bollinger(closes)
    result['bb_lower'] = bb_l
    result['bb_mid'] = bb_m
    result['bb_upper'] = bb_u
    return result

def analyze_signal(indicators: dict) -> str:
    ef = indicators.get('ema_fast')
    es = indicators.get('ema_slow')
    rsi = indicators.get('rsi')
    adx = indicators.get('adx')
    mom = indicators.get('momentum')
    va = indicators.get('vol_avg')
    vol = indicators.get('volume', 0)
    if None in (ef, es, rsi):
        return 'NEUTRAL'
    trend_up = ef > es
    vol_ok = (va and va > 0 and vol >= va * VOLUME_MULTIPLIER and vol >= VOLUME_ABS_MIN)
    adx_ok = adx is None or adx >= ADX_MIN
    mom_ok = mom is None or abs(mom) >= MOMENTUM_MIN
    if trend_up and vol_ok and adx_ok and mom_ok and rsi <= RSI_OVERBOUGHT_FILTER:
        return 'LONG'
    if not trend_up and vol_ok and adx_ok and mom_ok and RSI_OVERSOLD <= rsi <= 55:
        return 'SHORT'
    return 'NEUTRAL'

def pnl_pct_for(side, entry, cur) -> float:
    if entry <= 0:
        return 0.0
    return ((cur - entry) / entry * 100) if side == 'LONG' else ((entry - cur) / entry * 100)

def calc_pnl(side, entry, price, lot) -> float:
    if entry <= 0:
        return 0.0
    diff = price - entry if side == 'LONG' else entry - price
    return round(diff * lot, 2)

# ── market detection via API ─────────────────────────────────

def detect_market_from_candles(candles) -> bool:
    """Если возраст последней свечи ≤ 10 мин — рынок активен."""
    if not candles:
        return False
    last = candles[-1]
    age = (datetime.now(timezone.utc) - last.time).total_seconds()
    return age <= 600

# ── main ──────────────────────────────────────────────────────

async def main():
    sys.stdout.reconfigure(line_buffering=True)
    sys.stderr.reconfigure(line_buffering=True)

    if state.running:
        print("[BOT] Already running.")
        return

    token = SANDBOX_TOKEN = os.getenv("TINKOFF_SANDBOX_TOKEN")
    if not token:
        token = os.getenv("TINKOFF_TOKEN")
    if not token:
        print("ERROR: no token in .env")
        return

    print(f"[BOT] Start CCM6 | SANDBOX={SANDBOX} | SDK gRPC", flush=True)

    state.raw_candles = []
    stats = load_stats_from_logs()
    for k, v in stats.items():
        setattr(state, k, v)
    print(f"[BOT] Logs: {state.trade_count} trades, P/L={state.total_pnl:+.2f}", flush=True)

    state.last_error = None

    async with AsyncClient(token, target=SDK_TARGET, app_name="CCM6Bot") as client:
        # Resolve instrument
        instr = await client.instruments.future_by(
            id_type=2, class_code="SPBFUT", id=TICKER
        )
        figi = instr.instrument.figi
        uid = instr.instrument.uid
        print(f"[BOT] {TICKER} → FIGI={figi} UID={uid}", flush=True)
        state.current_figi = figi

        # Account
        aid = ACCOUNT_ID or os.getenv("TINKOFF_ACCOUNT_ID") or ""
        if not aid:
            accs = await client.users.get_accounts()
            if accs.accounts:
                aid = accs.accounts[0].id
        if not aid:
            print("ERROR: no account ID")
            return
        client._account_id = aid
        print(f"[BOT] Account: {aid}", flush=True)

        # Sandbox payin
        if SANDBOX and AUTO_PAYIN:
            try:
                await client.sandbox.sandbox_pay_in(
                    account_id=aid,
                    amount=MoneyValue(currency="rub", units=int(AUTO_PAYIN), nano=0)
                )
                print(f"[BOT] PayIn {AUTO_PAYIN} RUB", flush=True)
            except Exception as e:
                print(f"[BOT] PayIn warning: {e}", flush=True)

        # Preload candles
        now_utc = datetime.now(timezone.utc)
        from_utc = now_utc - timedelta(hours=PRELOAD_HOURS)
        print(f"[BOT] Loading {PRELOAD_HOURS}h history...", flush=True)
        candles = []
        async for c in client.get_all_candles(
            figi=figi, from_=from_utc, to=now_utc, interval=1
        ):
            candles.append(c)

        if not candles:
            print("ERROR: no candle data", flush=True)
            return

        print(f"[BOT] Loaded {len(candles)} candles, last={candles[-1].time}", flush=True)
        state.raw_candles = candles

        # Resume position (sandbox)
        position = Position()
        position.lot = 10
        if SANDBOX:
            try:
                pf = await client.operations.get_portfolio(account_id=aid)
                for p in pf.positions:
                    if p.figi == figi and p.balance != 0:
                        qty = int(abs(p.balance))
                        ep = qfloat(p.average_position_price) if p.average_position_price else 0
                        position.side = 'LONG' if p.balance > 0 else 'SHORT'
                        position.lot = qty
                        position.entry_price = ep
                        position.peak_price = ep
                        position.entry_time = datetime.now(timezone.utc)
                        print(f"[RESUME] {position.side} {qty} @ {ep:.4f}", flush=True)
                        break
                bal = qfloat(pf.total_amount_currencies or pf.total_amount_futures or MoneyValue())
                state.portfolio_balance = bal
            except Exception as e:
                print(f"[RESUME] portfolio error: {e}", flush=True)

        state.position.side = position.side
        state.position.entry_price = position.entry_price
        state.position.lot = position.lot
        state.position.peak_price = position.peak_price

        # Print config
        print(f"\n{'='*50}", flush=True)
        print(f"BOT READY | {TICKER} | {'SANDBOX' if SANDBOX else 'PROD'}", flush=True)
        print(f"EMA:{EMA_FAST}/{EMA_SLOW} RSI:{RSI_PERIOD} ADX>={ADX_MIN}", flush=True)
        if position.side != 'NONE':
            print(f"Position: {position.side} @ {position.entry_price:.4f}", flush=True)
        print(f"{'='*50}\n", flush=True)

        # ── Startup briefing ──
        try:
            print("[BOT] Generating startup briefing...", flush=True)
            await _briefing.main()
            print("[BOT] Startup briefing done.", flush=True)
        except Exception as e:
            print(f"[BOT] Briefing start error: {e}", flush=True)

        # ── Market data stream setup ──
        candle_queue = asyncio.Queue(maxsize=100)
        stream_open = asyncio.Event()
        stream_error = None
        stream_ref = None

        async def stream_worker():
            """Background: consume market data stream → push to queue."""
            nonlocal stream_error, stream_ref
            try:
                stream = client.create_market_data_stream()
                stream_ref = stream
                stream.candles.waiting_close().subscribe([
                    CandleInstrument(figi=figi, interval=SubscriptionInterval.SUBSCRIPTION_INTERVAL_ONE_MINUTE)
                ])
                stream.info.subscribe([InfoInstrument(figi=figi)])
                stream_open.set()

                async for md in stream:
                    if md.candle:
                        await candle_queue.put(('candle', md.candle))
                    if md.trading_status:
                        await candle_queue.put(('status', md.trading_status))
                    if md.ping:
                        await candle_queue.put(('ping', time.time()))
            except Exception as e:
                stream_error = e
                stream_open.set()

        worker = asyncio.create_task(stream_worker())
        await stream_open.wait()

        if stream_error:
            print(f"[BOT] Stream error: {stream_error}", flush=True)

        # ── Main lifecycle loop ──
        last_candle_minute = None
        market_open = detect_market_from_candles(candles)
        prev_price = qfloat(candles[-1].close) if candles else 0
        last_briefing_ts = time.time()

        while get_lifecycle_event().wait():
            state.running = True
            state.start_time = datetime.now()

            try:
                # Wait for candle event or timeout fallback
                try:
                    msg_type, msg = await asyncio.wait_for(
                        candle_queue.get(), timeout=60
                    )
                except asyncio.TimeoutError:
                    msg_type, msg = 'tick', None

                now_utc = datetime.now(timezone.utc)
                now_msk = now_utc + timedelta(hours=3)

                # ── Process candle from stream ──
                if msg_type == 'candle':
                    c = msg
                    if candles and candles[-1].time == c.time:
                        candles[-1] = c
                    else:
                        candles.append(c)
                    if len(candles) > 500:
                        candles = candles[-500:]
                    state.raw_candles = candles
                    last_candle_minute = c.time.minute

                # ── Process trading status ──
                if msg_type == 'status':
                    ts = msg
                    market_open = (
                        ts.trading_status == SecurityTradingStatus.SECURITY_TRADING_STATUS_NORMAL_TRADING
                        or ts.market_order_available_flag
                        or ts.limit_order_available_flag
                    )

                # ── Update market detection ──
                if msg_type in ('tick', 'ping'):
                    market_open = detect_market_from_candles(candles)

                # ── Compute indicators ──
                price = qfloat(candles[-1].close) if candles else 0
                indicators = compute_indicators(candles)
                state.ind_ema = indicators.get('ema_fast') or 0.0
                state.ind_ema_slow = indicators.get('ema_slow') or 0.0
                state.ind_rsi = indicators.get('rsi') or 0.0
                state.ind_adx = indicators.get('adx') or 0.0
                state.ind_momentum = indicators.get('momentum') or 0.0
                if indicators.get('vol_avg'):
                    state.ind_volume_mult = round(
                        indicators['volume'] / indicators['vol_avg'], 2
                    )
                signal = analyze_signal(indicators)

                # ── Level break detection for briefing ──
                now_ts = time.time()
                if now_ts - last_briefing_ts > BRIEFING_COOLDOWN and market_open:
                    bb_l = indicators.get('bb_lower')
                    bb_u = indicators.get('bb_upper')
                    if bb_l and bb_u:
                        if price <= bb_l * 1.002 or price >= bb_u * 0.998:
                            print(f"[BOT] Level break (price={price:.2f}, BB={bb_l:.2f}/{bb_u:.2f}), triggering briefing", flush=True)
                            asyncio.create_task(_briefing.main())
                            last_briefing_ts = now_ts
                    # Also trigger on large price moves
                    if prev_price and abs(price - prev_price) / prev_price > 0.012:
                        print(f"[BOT] Price move {abs(price-prev_price)/prev_price*100:.2f}%, triggering briefing", flush=True)
                        asyncio.create_task(_briefing.main())
                        last_briefing_ts = now_ts
                prev_price = price

                if DEBUG and msg_type == 'candle':
                    print(
                        f"[{now_msk.strftime('%H:%M')}] "
                        f"p={price:.2f} EMA={indicators['ema_fast'] or 0:.2f}/{indicators['ema_slow'] or 0:.2f} "
                        f"RSI={indicators['rsi'] or 0:.1f} ADX={indicators['adx'] or 0:.1f} "
                        f"MOM={indicators['momentum'] or 0:+.2f} V={indicators['volume']}/{indicators['vol_avg'] or 0:.0f} "
                        f">>> {signal} | pos={position.side} | market={'OPEN' if market_open else 'CLOSED'}"
                    )

                if signal != 'NEUTRAL' and now_msk.hour >= TIME_FILTER_HOUR:
                    signal = 'NEUTRAL'

                # ── Close logic ──
                if state.force_close:
                    print(f"[FORCE_CLOSE] {position.side}", flush=True)
                    state.force_close = False
                    try:
                        await client.orders.post_order(
                            figi=figi, quantity=position.lot,
                            direction=OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY,
                            account_id=aid, order_type=OrderType.ORDER_TYPE_MARKET,
                            order_id=str(uuid.uuid4()), instrument_id=uid
                        )
                        pnl = calc_pnl(position.side, position.entry_price, price, position.lot)
                        log_trade("CLOSE (MANUAL)", figi, TICKER, position.lot, price, pnl)
                        print(f"  >> CLOSE (MANUAL) @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                        state.record_trade(pnl)
                    except Exception as e:
                        print(f"  >> Force close error: {e}", flush=True)
                        state.record_error(str(e))
                    position.side = 'NONE'
                    position.entry_price = 0.0
                    position.peak_price = 0.0
                    position.trailing_active = False
                    position.entry_time = None
                    state.position.side = 'NONE'
                    state.portfolio_blocked = 0.0

                elif position.side != 'NONE' and market_open:
                    pp = pnl_pct_for(position.side, position.entry_price, price)

                    # Trailing activation
                    if pp >= TRAILING_ACTIVATE and not position.trailing_active:
                        position.trailing_active = True
                        position.peak_price = price
                        state.position.trailing_active = True
                        if DEBUG:
                            print(f"  >> TRAIL ACTIVE @ {price:.4f} (+{pp:.2f}%)", flush=True)

                    # Trailing close
                    if position.trailing_active:
                        is_long = position.side == 'LONG'
                        if is_long:
                            if price > position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 - TRAILING_DISTANCE / 100)
                            triggered = price <= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_SELL
                        else:
                            if price < position.peak_price:
                                position.peak_price = price
                            trail_level = position.peak_price * (1 + TRAILING_DISTANCE / 100)
                            triggered = price >= trail_level
                            close_dir = OrderDirection.ORDER_DIRECTION_BUY

                        if triggered:
                            try:
                                await client.orders.post_order(
                                    figi=figi, quantity=position.lot, direction=close_dir,
                                    account_id=aid, order_type=OrderType.ORDER_TYPE_MARKET,
                                    order_id=str(uuid.uuid4()), instrument_id=uid
                                )
                                pnl = calc_pnl(position.side, position.entry_price, price, position.lot)
                                log_trade(f"CLOSE (TRAIL @ {trail_level:.4f})", figi, TICKER, position.lot, price, pnl)
                                print(f"  >> TRAIL CLOSE @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                                state.record_trade(pnl)
                            except Exception as e:
                                print(f"  >> Trailing close error: {e}", flush=True)
                                state.record_error(str(e))
                            position.reset()

                    # Stop-Loss
                    if position.side != 'NONE' and pp <= -STOP_LOSS_PCT:
                        close_dir = OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
                        try:
                            await client.orders.post_order(
                                figi=figi, quantity=position.lot, direction=close_dir,
                                account_id=aid, order_type=OrderType.ORDER_TYPE_MARKET,
                                order_id=str(uuid.uuid4()), instrument_id=uid
                            )
                            pnl = calc_pnl(position.side, position.entry_price, price, position.lot)
                            log_trade("CLOSE (SL)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> SL @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            state.record_trade(pnl)
                        except Exception as e:
                            print(f"  >> SL error: {e}", flush=True)
                            state.record_error(str(e))
                        position.reset()

                    # Take-Profit
                    if position.side != 'NONE' and pp >= TAKE_PROFIT_PCT:
                        close_dir = OrderDirection.ORDER_DIRECTION_SELL if position.side == 'LONG' else OrderDirection.ORDER_DIRECTION_BUY
                        try:
                            await client.orders.post_order(
                                figi=figi, quantity=position.lot, direction=close_dir,
                                account_id=aid, order_type=OrderType.ORDER_TYPE_MARKET,
                                order_id=str(uuid.uuid4()), instrument_id=uid
                            )
                            pnl = calc_pnl(position.side, position.entry_price, price, position.lot)
                            log_trade("CLOSE (TP)", figi, TICKER, position.lot, price, pnl)
                            print(f"  >> TP @ {price:.4f} | P/L: {pnl:+.2f} RUB", flush=True)
                            state.record_trade(pnl)
                        except Exception as e:
                            print(f"  >> TP error: {e}", flush=True)
                            state.record_error(str(e))
                        position.reset()

                    state.position.entry_price = position.entry_price
                    state.position.peak_price = position.peak_price
                    state.position.trailing_active = position.trailing_active
                    state.position.lot = position.lot

                # ── Open logic ──
                manual_side = state.manual_entry_side
                state.manual_entry_side = ""
                if manual_side:
                    signal = manual_side

                if position.side == 'NONE' and signal != 'NEUTRAL' and market_open:
                    try:
                        order_lot = 10 if manual_side else position.lot
                        direction = OrderDirection.ORDER_DIRECTION_BUY if signal == 'LONG' else OrderDirection.ORDER_DIRECTION_SELL
                        await client.orders.post_order(
                            figi=figi, quantity=order_lot, direction=direction,
                            account_id=aid, order_type=OrderType.ORDER_TYPE_MARKET,
                            order_id=str(uuid.uuid4()), instrument_id=uid
                        )
                        position.side = signal
                        position.entry_price = price
                        position.entry_bar = len(candles)
                        position.lot = order_lot
                        position.entry_time = now_utc
                        position.peak_price = price
                        position.trailing_active = False
                        log_trade(f"{'[MANUAL] ' if manual_side else ''}OPEN {signal}", figi, TICKER, order_lot, price)
                        state.position.side = signal
                        state.position.entry_price = price
                        state.position.entry_bar = len(candles)
                        state.position.entry_time = now_utc
                        state.position.peak_price = price
                        state.position.lot = order_lot
                        state.portfolio_blocked = round(price * order_lot, 2) if SANDBOX else 0.0
                        print(f"  >> OPEN {signal} @ {price:.4f}", flush=True)
                    except Exception as e:
                        print(f"  >> Open error: {e}", flush=True)
                        state.record_error(str(e))

                # Clear stale errors
                if state.last_error and 'Cannot connect' in str(state.last_error):
                    state.last_error = None

            except asyncio.CancelledError:
                print("\nBot cancelled.", flush=True)
                break
            except Exception as e:
                import traceback
                print(f"[BOT] Error: {e}", flush=True)
                traceback.print_exc()
                state.record_error(str(e))
                await asyncio.sleep(5)

        worker.cancel()
        if stream_ref:
            stream_ref.stop()
        print("[BOT] Stopped.", flush=True)


# Helper: reset position
def _pos_reset(pos):
    pos.side = 'NONE'
    pos.entry_price = 0.0
    pos.peak_price = 0.0
    pos.trailing_active = False
    pos.entry_time = None
    pos.lot = 0
    state.position.side = 'NONE'
    state.portfolio_blocked = 0.0

Position.reset = lambda self: _pos_reset(self)

if __name__ == "__main__":
    asyncio.run(main())
